<?php

class Jcan_Tidy extends tidy
{
	//存储要返回的结果
	public $html;

	/**
	 * 规范用户提交的HTML语言,并且可有效的阻止javascript等脚本(包括style)
	 *
	 * @param string $html
	 * @param array[optional] $config = null
	 * @param string[optional] $encoding = utf8
	 * @return string
	 * @see self::tidyNode()
	 */
	public function tidyHtml($html, $config=null, $encoding='utf8')
	{
//		$tidy = new self();
//		if ($config === null) {
//			$config = array(
//					'output-xhtml' => true,
//			                'drop-empty-paras' => false,
//			                'join-classes' => true,
//			                'show-body-only' => true,
//			                'indent' => false,
////			                'indent-spaces' => 2,
//			                'drop-font-tags' => true,
//			                'wrap' => 400,
//			);
//		}
//
//		$tidy->parseString($html, $config, $encoding);
//		$node = $tidy->body();
//		return $this->tidyNode($node);

		if ($config === null) {
			$config = array(
					'output-xhtml' => true,
			                'drop-empty-paras' => false,
			                'join-classes' => true,
			                'show-body-only' => true,
			                'indent' => false,
//			                'indent-spaces' => 2,
			                'drop-font-tags' => true,
			                'wrap' => 400,
			);
		}

		$this->parseString($html, $config, $encoding);
		$node = $this->body();
		return $this->tidyNode($node);
	}

	/**
	 * 规范用户提交的HTML语言,并且可有效的阻止javascript等脚本(包括style)
	 *
	 * @param TidyNode &$node
	 * @return string
	 * @see self::tidyHtml()
	 */
	public function tidyNode(&$node)
	{

		//如果该节点无孩子
		if (empty($node->child)) {

			//如果该节点无名称,则为text类型,应该直接输出
			if (empty($node->name)) {
				//? 每个值之后都会多一个\r(不知道为啥,有点郁闷)
				$node->value = preg_replace('!\r$!', '', $node->value);
				$this->html .= $node->value;
			}
			//如果节点有名称,则为单标签
			else {
				switch ($node->name) {
					//限制javascript,style标签
					case 'script':
					case 'style':
						break;
					default:
						$this->html .= '<' . $node->name;
						//遍历单标签的所有属性
						if (!empty($node->attribute)) {
							foreach ($node->attribute as $attr=>$value) {
								//限制onmouseover等事件,及javascript等敏感语言
								if ($attr=='style' || stripos($attr, 'on')===0 || stripos(trim($value), 'javascript')===0)
									continue;

								$value = htmlspecialchars($value);
								$this->html .= " $attr=\"$value\"";
							}
						}

						//区分<script src="xxx.js"></script>与<hr />两种标签
						if (strpos($node->value, '/>')===false) {
							$this->html .= "></{$node->name}>";
						} else {
							$this->html .= ' />';
						}
						break;
				}
			}
		}

		//如果该节点有孩子
		else {
			switch ($node->name) {
				//限制javascript,style标签
				case 'script':
				case 'style':
					break;
				default:
					//输出该节点的开始标签
					if ($node->name != 'body') $this->html .= '<' . $node->name;

					//遍历该节点的所有属性
					if (!empty($node->attribute)) {
						foreach ($node->attribute as $attr=>$value) {
							//限制onmouseover等事件,及javascript等敏感语言
							if ($attr=='style' || stripos($attr, 'on')===0 || stripos(trim($value), 'javascript')===0)
								continue;

							$value = htmlspecialchars($value);
							$this->html .= " $attr=\"$value\"";
						}
					}
					if ($node->name != 'body') $this->html .= '>';

					//递归该节点的所有孩子
					foreach ($node->child as $child) {
						$this->tidyNode($child);
					}

					//输出该节点的结束标签
					if ($node->name != 'body') $this->html .= '</' . $node->name . '>';

					break;
			}
		}

		//最终返回该静态变量
		return $this->html;
	}
}
