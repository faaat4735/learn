<?php

class Jcan_Math
{
	/**
	 * convert any base value to any other base value
	 *
	 * @param string $value
	 * @param int $srcBase
	 * @param int $dstBase
	 * @return string
	 * @example self::base2base($base64, 64, 62)
	 */
	public static function base2base($value, $srcBase, $dstBase)
	{
		if ($srcBase == $dstBase) {
			return $value;
		}

		if ($srcBase != 10) {
			$value = self::base2dec($value, $srcBase);
		}
		if ($dstBase != 10) {
			$value = self::dec2base($value, $dstBase);
		}
		return $value;
	}

	/**
	 * convert a decimal value to any other base value
	 *
	 * @param string $dec
	 * @param int $base
	 * @param string $digits [optional]
	 * @return string
	 * @example self::dec2base('4321432...43214', 62)
	 */
	public static function dec2base($dec, $base, $digits=false)
	{
		if ($base<2 || $base>256) die("Invalid Base: " . $base);

		bcscale(0);
		$value = '';
		if (!$digits) $digits = self::getBaseDigits($base);
		while ($dec > $base - 1) {
			$rest = bcmod($dec, $base);
			$dec = bcdiv($dec, $base);
			$value = $digits[$rest] . $value;
		}
		$value = $digits{intval($dec)} . $value;
		return strval($value);
	}

	/**
	 * convert another base value to its decimal value
	 *
	 * @param string $value
	 * @param int $base
	 * @param string $digits [optional]
	 * @return string
	 * @example self::base2dec('F032...sEKD', 64)
	 */
	public static function base2dec($value, $base, $digits=false)
	{
		if ($base<2 || $base>256) die("Invalid Base: " . $base);

		bcscale(0);
		if ($base < 37) $value = strtolower($value);
		if (!$digits) $digits = self::getBaseDigits($base);

		$dec = '0';
		for ($loop=0, $size=strlen($value); $loop<$size; $loop++) {
			$element = strpos($digits, $value{$loop});
			$power = bcpow($base, $size-$loop-1);
			$dec = bcadd($dec, bcmul($element, $power));
		}
		return strval($dec);
	}

	/**
	 * The purpose of digits() function is to supply the characters that
	 * will be used as digits for the base you want.
	 *
	 * @param int $base
	 * @return string
	 */
	public static function getBaseDigits($base)
	{
		if ($base > 64) {
			$digits = '';
			for ($loop=0; $loop<256; $loop++) {
				$digits .= chr($loop);
			}
		}
		else $digits = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/';

		$digits = substr($digits, 0, $base);
		return strval($digits);
	}
}
