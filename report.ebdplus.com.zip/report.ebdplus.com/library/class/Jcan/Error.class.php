<?php

/**
 * 对三种不同错误类型的客户端的显示方式
 * 用户需要扩展该配置文件, 扩展类的名称必须为Error
 */
class Jcan_Error implements Jcan_Error_Interface
{
	/**
	 * E_ERROR 的错误回调
	 */
	public static function eErrorCallback()
	{
		die("We are sorry, too many connections, please wait to try.");
	}

	/**
	 * E_NOTICE 的错误回调
	 */
	public static function eNoticeCallback()
	{
		self::eErrorCallback();
	}

	/**
	 * E_WARNING 的错误回调
	 */
	public static function eWarningCallback()
	{
		self::eErrorCallback();
	}
}