<?php
/**
 * 上传后返回一个数组，数组结构为：
 * $result = 	[
 * 			[
 * 				postName	POST过来的名称
 * 				fileType	文件类型
 * 				postError	POST过来的错误类型(int)
 * 				fileSize	文件大小
 * 				tmpName		上传的文件实体
 *
 *				checkError	检察出的错误类型:
 *							Jcan_File_Upload::SIZE_TOO_SMALL 文件太小
 *							Jcan_File_Upload::SIZE_TOO_LARGE 文件太大
 *							Jcan_File_Upload::TYPE_FORBIDDEN 文件类型被禁止
 *
 * 				uploadName	上传的名称
 * 			]
 * 		]
 * @example
 * 	$upload = new Jcan_File_Upload($_FILES['pics'], UPLOAD_DIR, 2*1024*1024, 1)
 * 	[$upload->checkFiles()]
 * 	$upload->execute(1);
 * 	print_r($upload->getUploadedFiles)
 * 	echo $upload->implode(',')
 */
class Jcan_File_Upload extends Jcan_File
{
	//几个错误常量
	const POST_ERROR = 1;
	const TYPE_FORBIDDEN = 2;
	const SIZE_TOO_SMALL = 3;
	const SIZE_TOO_LARGE = 4;

	//待上传的文件
	public $files = array();
	//要上传到的目录
	public $dir;

	//允许的文件类型(全部小写)
	public $allowedTypes;
	//被禁止的文件类型(全部小写)
	public $forbiddenTypes;
	//允许的最大尺寸
	public $maxSize;
	//允许的最小尺寸
	public $minSize;

	//最终被上传的文件属性
	public $uploadedFiles = array();

	//files是否被check过
	public $isChecked = 0;

	/**
	 * 如果同时设了allowedType与forbiddenType, 那么allowedTypes比forbiddenTypes优先
	 * @example __construct($areas, UPLOAD_DIR, 2*1024*1024, 1, null, null)
	 */
	public function __construct(&$files, $dir, $maxSize = 2097152, $minSize = 1,
					$allowedTypes = array('gif', 'png', 'jpg', 'jpeg', 'pjpeg', 'bmp', 'image/gif', 'image/png', 'image/x-png', 'image/jpg', 'image/jpeg', 'image/pjpeg', 'image/bmp'),
					$forbiddenTypes = array('php', 'asp', 'jsp', 'html', 'htm')) //$maxSize默认为2M
	{
		//files
		if (!is_array($files)) {
			Jcan_Debug::logError("请选择要上传的文件, 上传的文件需要是POST过来的数组!", E_NOTICE);
		}
		$this->files = $files;

		//dir
		if (!is_dir($dir)) {
			Jcan_Debug::logError("不存在目录: {$dir}", E_ERROR);
		}
		$this->dir = $dir;

		//allowedTypes, forbiddenTypes
		if (empty($allowedTypes)) {
			$this->allowedTypes = array();
			$this->forbiddenTypes = $forbiddenTypes;
		} else {
			$this->allowedTypes = $allowedTypes;
			$this->forbiddenTypes = array();
		}

		//maxSize, minSize
		$this->maxSize = $maxSize;
		$this->minSize = $minSize;
	}


	/**
	 * 对files进行检查，并以数组形式返回、保存检查结果
	 */
	public function checkFiles()
	{
		//如果上传的文件为空返回空数组
		if (empty($this->files) || !isset($this->files['name'])) {
			return array();
		}

		//重新组值数组形式
		$this->_reBuildFiles();

		//在$this->uploadedFiles中加入checkError键值
		$this->_checkError();

		//把isChecked设为1
		$this->isChecked = 1;

		//返回uploadedFiles数组
		return $this->uploadedFiles;
	}

	/**
	 * 可能产生如下几个异常:
	 *	const SIZE_TOO_SMALL = 1
	 *	const SIZE_TOO_LARGE = 2
	 *	const TYPE_FORBIDDEN = 3
	 *	const POST_ERROR = 4
	 */
	private function _checkError()
	{
		//对产生的新数组uploadedFiles进行规则验证
		foreach ($this->uploadedFiles as &$v) {

			//检测postError
			if ($v['postError'] != 0) {
				$v['checkError'] = self::POST_ERROR;
				continue;
			}

			/* 扩展名与文件类型都检验 */
			//检测$this->allowedTypes
			if (!empty($this->allowedTypes)) {
				$extension = Jcan::getExtension($v['postName']);
				if (!in_array($extension, $this->allowedTypes)
						|| !in_array($v['fileType'], $this->allowedTypes)) {
					$v['checkError'] = self::TYPE_FORBIDDEN;
					continue;
				}
			}
			//检测$this->forbiddenTypes
			if (!empty($this->forbiddenTypes)) {
				$extension = Jcan::getExtension($v['postName']);
				if (in_array($extension, $this->forbiddenTypes)
						|| in_array($v['fileType'], $this->forbiddenTypes)) {
					$v['checkError'] = self::TYPE_FORBIDDEN;
					continue;
				}
			}

			//检验文件大小
			if ($v['fileSize'] > $this->maxSize) {
				$v['checkError'] = self::SIZE_TOO_LARGE;
				continue;
			}
			if ($v['fileSize'] < $this->minSize) {
				$v['checkError'] = self::SIZE_TOO_SMALL;
				continue;
			}

			//若无异常返回0
			$v['checkError'] = 0;
		}
	}


	/**
	 * 执行上传
	 *
	 * @param boolean $force
	 * 	(true表示强行上传,即使某个文件发生异常其它文件也不受影响)
	 * 	(如果为false,那么只要有一个文件发生异常就会导致整个上传失败)
	 * 	(这里所说的异常是指:大小不符合规则,或者文件类型与要求不匹配 与move_upload_file异常不相关)
	 * @return boolean (只要有一个文件上传成功都返回true)
	 */
	public function execute($force = true)
	{
		//需要先检验文件
		if(!$this->isChecked) {
			$this->checkFiles();
		}

		//如果force关闭并且验证时发生错误,将导致直接返回false
		if (!$force) {
			foreach ($this->uploadedFiles as $v) {
				if ($v['checkError'] != 0) return false;
			}
		}

		//force打开的情况
		$retvalue = false;
		foreach ($this->uploadedFiles as &$v) {
			//如果验证时发生错误,则返回空的uploadName字符串
			if ($v['checkError'] != 0) {
				$v['uploadName'] = '';
				continue;
			}

			/* 如果验证时未发生异常,则返回上传后的字符串 */
			//extension(扩展名)
			$extension = Jcan::getExtension($v['postName']);
			$extension = empty($extension) ? '' : '.' . $extension;

			//new file name
			$time = microtime();
			$newFileName = substr($time,11) . substr($time,2,8) . $extension;

			//文件应放入的目录
			$prefixMonth = date('ym');
			$prefixDay = date('d');

			$monthDir = $this->dir . $prefixMonth;
			$dayDir = $monthDir . '/' . $prefixDay;

			if (!is_dir($monthDir)) {
				@mkdir($monthDir, 0755) or Jcan_Debug::logError("不存在目录{$monthDir},尝试创建失败!", E_ERROR);
			}
			if (!is_dir($dayDir)) {
				@mkdir($dayDir, 0755) or Jcan_Debug::logError("不存在目录{$dayDir},尝试创建失败!", E_ERROR);
			}

    			$isUploaded =@ move_uploaded_file($v['tmpName'], $dayDir . '/' . $newFileName);
    			if ($isUploaded) {
    				$v['uploadName'] = $prefixMonth . '/' . $prefixDay . '/' . $newFileName;
    				$retvalue = true;
    			} else {
    				$v['uploadName'] = '';
    			}
		}
		return $retvalue;
	}


	/**
	 * 取得被上传文件的状态
	 * [注意]如果调用此函数之前未执行任何操作,则仅返回空数组
	 * @see $this->getFiles()
	 */
	public function getUploadedFiles()
	{
		return $this->uploadedFiles;
	}

	/**
	 * 取得待上传文件(即初始时传入的数组)
	 * @see $this->getUploadedFiles()
	 */
	public function getFiles()
	{
		return $this->files;
	}

	/**
	 * 对$this->files 重新建立数据结构
	 * 新建立的数据结构如下:
	 * $this->uploadFiles =	[ [postName=>上传前的名称, fileType=>文件类型, postError=>POST错误, fileSize=>文件大小, tmpName=>待上传的临时文件], ... ]
	 */
	private function _reBuildFiles()
	{
		//如果仅上传单个文件, 即以<input name="province" type="file" />形式上传
		if (!is_array($this->files['name'])) {
			$this->uploadedFiles[0] = array(
					'postName'	=> $this->files['name'],
					'fileType'	=> $this->files['type'],
					'postError'	=> $this->files['error'],
					'fileSize'	=> $this->files['size'],
					'tmpName'	=> $this->files['tmp_name'],
				);
		}
		//如果上传多个文件，即以<input name="areas[]" type="file" />形式上传
		else {
			foreach ($this->files['name'] as $k => $v) {
				$this->uploadedFiles[$k] = array(
						'postName'	=> $this->files['name'][$k],
						'fileType'	=> $this->files['type'][$k],
						'postError'	=> $this->files['error'][$k],
						'fileSize'	=> $this->files['size'][$k],
						'tmpName'	=> $this->files['tmp_name'][$k],
					);
			}
		}
	}

	/**
	 * 把新的文件名组成字符串以便放入数据库所用
	 * @example $this->getUploadedFileNames('|')
	 */
	public function getUploadedFileNames($sign=null)
	{
		$files = array();
		foreach ($this->uploadedFiles as $v) {
			if (!empty($v['uploadName'])) {
				$files[] = $v['uploadName'];
			}
		}
		if (!is_null($sign)) {
			return implode($sign, $files);
		}

		return $files;
	}
}

?>