<?php

/**
 * Base Observerable class
 * Inspired from http://www.phppatterns.com/index.php/article/articleview/27/1/1/
 *
 * @see Observer
 */
abstract class Jcan_Observable {

	//该对象所有观察者的集合
	private $_observers = array();

	//该对象所发生的事件
	private $_event;

	//该对象传递需要传递的参数(mixed)
	private $_param;


	//构造函数
	public function __construct() {}

	//呼叫观察者开始检测
	public function notifyObservers() {
		foreach ($this->_observers as &$observer) {
			$observer->update();
		}
	}

	//取得发生的动作
	public function getEvent() {
		return $this->_event;
	}

	//设置所发生的动作
	public function setEvent($event) {
		$this->_event = $event;
	}

	//取得要传递的参数
	public function getParam() {
		return $this->_param;
	}

	//设置要传递的参数
	public function setParam($param) {
		$this->_param = $param;
	}


	//取得所有观察者数组, 一般调试时用
	public function getObservers() {
		return $this->_observers;
	}

	//增加观察者
	public function addObserver(Jcan_Observer &$observer) {
		$this->_observers[] = $observer;
	}
}
