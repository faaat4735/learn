<?php

class Jcan_Module_Tools extends Jcan_Module
{
	public function indexAction()
	{
		if (!DEBUG_MODE) return false;

		$pre = ROOT_URL . Jcan_Data::lcfirst($this->tpl->module);

		$html = <<<EOF
<h1>Management Tools</h1>
<ul>
<li><a href="{$pre}-phpinfo/">PHP Info</a></li>
<li><a href="{$pre}-ip/">IP</a></li>
<li><a href="{$pre}-session/">Session</a></li>
<li><a href="{$pre}-cookie/">Cookie</a></li>
<li><a href="{$pre}-server/">Server</a></li>
<li><a href="{$pre}-get/">GET</a></li>
<li><a href="{$pre}-post/">POST</a></li>
<li><a href="{$pre}-request/">Request</a></li>
<li><a href="{$pre}-function/">Functions</a></li>
<li><a href="{$pre}-class/">Class</a></li>
<li><a href="{$pre}-var/">Variables</a></li>
<li><a href="{$pre}-interface/">Interface</a></li>
<li><a href="{$pre}-constant/">Constant</a></li>
<li><a href="{$pre}-packer/" onclick="return confirm('Ensure to pack js files from jsDev folder to js folder?');">Packer JS</a></li>
</ul>
EOF;
		echo $html;
	}

	public function phpinfoAction()
	{
		if (!DEBUG_MODE) return false;
		phpinfo();
	}

	public function ipAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(Jcan_Http::getIpList());
	}

	public function sessionAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_SESSION);
	}

	public function cookieAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_COOKIE);
	}

	public function serverAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_SERVER);
	}

	public function getAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_GET);
	}

	public function postAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_POST);
	}

	public function requestAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump($_REQUEST);
	}

	public function functionAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(get_defined_functions());
	}

	public function classAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(get_declared_classes());
	}

	public function interfaceAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(get_declared_interfaces());
	}

	public function varAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(get_defined_vars());
	}

	public function constantAction()
	{
		if (!DEBUG_MODE) return false;
		Jcan::dump(get_defined_constants(true));
	}

	public function packerAction()
	{
		if (!DEBUG_MODE) return false;

		$retval = Jcan_Js_Packer::packToDir(WWW_DIR . 'jsDev/*.js', WWW_DIR . 'js/');

		echo '<table>';
		if (empty($retval)) {
			echo "<tr><td><em>There is not any js file in the jsDev folder.</em></td></tr>";
		} else {
			foreach ($retval as $file => $bytes) {
				$k = sprintf('%.3f', $bytes / 1024);
				echo "<tr><td>{$file}</td><td><em>{$k} kb</em></td></tr>\n";
			}
		}
		echo '</table>';
	}
}