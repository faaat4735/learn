<?php

/**
 * 验证基类(抽象类)
 * @see Jcan_Validation_Validator
 * @see Jcan_Validation_Rule
 */
abstract class Jcan_Validation
{
	//错误信息,开始无错误信息
	protected $_error = false;

	/**
	 * 构造函数
	 */
	public function __construct()
	{}

	/**
	 * 设置错误信息
	 *
	 * @param string|boolean $error
	 */
	public function setError($error)
	{
		$this->_error = $error;
	}

	/**
	 * 取得错误信息
	 *
	 * @return string|boolean
	 */
	public function getError()
	{
		return $this->_error;
	}

	/**
	 * 开始验证信息 (抽象方法)
	 *
	 * @param  mixed $value
	 * @return boolean
	 */
	abstract function validate($value);
}
