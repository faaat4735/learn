<?php

class Jcan_RegExp
{
	//特殊字符
	const SPECIAL_CHARS = '![　\s\,\;\&\'\"\*\?\(\)\\\%<>]!';

	//用户名. 由3-15个下划线,英文字母或者数字组成(不区分大小写)
	const USERNAME = '!^[a-z0-9\-_]{3,15}$!i';

	//昵称. 由不含特殊字符的3-15个字符组成)
	const NICKNAME = '!^[^　\s\,\;\&\'\"\*\?\(\)\\\%<>]{3,15}$!';

	//汉字,英文,数字,下划线,减号
	const CN_EN = '!^[a-zA-Z\d一-龥\-_]+$!u';

	//汉字
	const CN = '!^[一-龥]+$!u';

	//词汇(2-15位的英文 或者是 2-7个的汉字)
	const WORD = '!^[a-z]{2,20}|[一-龥]{2,7}$!u';

	//标签(可以是字母,数字与汉字的组合形式)
	const TAG = '!^[a-zA-Z\d 一-龥]{2,}$!u';

	//E-mail
	const EMAIL = '/^[0-9a-z\-\_\.]{1,40}@([0-9a-z\-]{1,20}\.){1,4}[a-z]{2,5}$/i';

	//web image extension name
	const IMAGE = '/\.(gif|p?jpe?g|png|bmp)$/i';

	//UTF8
	const UTF8 = '!^([\xe0-\xef][\x80-\xbf]{2}|[\xc0-\xdf][\x80-\xbf]|[\x01-\x7f])*$!';
}
