<?php

class Jcan_Exception extends Exception
{}
