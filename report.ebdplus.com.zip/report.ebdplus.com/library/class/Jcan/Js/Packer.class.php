<?php
/**
 * @example $o = new Jcan_Js_Packer($jsCode); echo $o->pack();
 */
class Jcan_Js_Packer extends JavaScriptPacker
{
	/**
	 * 把JS文件压缩到另一个文件夹
	 *
	 * @param string $srcFile
	 * @param string $dstDir
	 * @return array(filename => bytes)
	 * @example
	 * self::packToDir('/sites/jslib/', '/sites/js/')
	 * self::packToDir('/sites/jquery.*.js', '/sites/js/')
	 */
	public static function packToDir($srcFile, $dstDir)
	{
		if (is_dir($srcFile)) {
			$srcFile = realpath($srcFile) . DIRECTORY_SEPARATOR . '*.js';
		}
		$files = glob($srcFile);

		$retval = array();
		foreach ($files as $file) {
			$_script = file_get_contents($file);
			$o = new self($_script);
			$_script = $o->pack();

			$dstFile = realpath($dstDir) . DIRECTORY_SEPARATOR . basename($file);
			$bytes = @file_put_contents($dstFile, $_script);

			$retval[$dstFile] = $bytes;
		}
		return $retval;
	}
}