<?php

/**
 * 最终应继承于array接口
 */
class Jcan_Array
{
	/**
	 * 思想来自jQuery::extend(settings, options)
	 * <strong>多层扩展, 优先权依次减弱</strong>
	 *
	 * @param array &$customArr 用户自定义配置
	 * @param array $baseArr 默认配置
	 * @example Jcan_Array::extend($optionsArr, $groupSettingsArr, $globalSettingsArr);
	 */
	public static function extend(&$customArr)
	{
		$baseArrs = func_get_args();
		array_shift($baseArrs);

		foreach ($baseArrs as $baseArr) {
			foreach ($baseArr as $k => &$v) {
				if (!isset($customArr[$k])) {
					$customArr[$k] = $v;
				} elseif (is_array($v)) {
					self::extend($customArr[$k], $v);
				}
			}
		}
	}

	/**
	 * array_unique 的扩展, 增加$strict参数
	 *
	 * @param array $array
	 * @param bool $strict 当strict时表示区分大小写
	 * @return array
	 */
	public static function unique($array, $strict)
	{
		if ($strict) return array_unique($array);

		$arrCnt = count($array);
		$a = array();
		for ($i = 0; $i < $arrCnt; $i++) {
			for ($j = 0; $j < $arrCnt; $j++) {
				if (strcasecmp($array[$i], $array[$j]) === 0) {
					$a[$j] = $array[$i];
					break;
				}
			}
		}
		return $a;
	}

	/**
	 * 不区分大小写的 array_search
	 *
	 * @param string $needle
	 * @param array $haystack
	 * @param boolean $strict
	 */
	public static function caseSearch($needle, $haystack, $strict = false)
	{
		$needle = strtolower($needle);
		$haystack = array_map('strtolower', $haystack);
		return array_search($needle, $haystack, $strict);
	}

	/**
	 * 把一个stdClass对象转换为array
	 *
	 * @param array|stdClass $o
	 */
	public static function toArray(&$data)
	{
		if ($data instanceof stdClass) {
			$data = (array)$data;
		}

		foreach ($data as &$v) {
			if (is_array($v) || $v instanceof stdClass) {
				self::toArray($v);
			}
		}
	}

	/**
	 * Function that does the same as shuffle(), but preserves key=>values on $assoc = true.
	 *
	 * @param array &$array
	 * @param bool $assoc
	 * @return bool
	 */
	public static function shuffle(&$array, $assoc = true)
	{
		if (!$assoc) {
			return shuffle($array);
		}

		if (count($array)>1) {
			$new = array();
			$keys = array_rand($array, count($array));

			foreach($keys as $key) {
				$new[$key] = $array[$key];
			}
			$array = $new;
		}
		return true;
	}

	/**
	 * 思想来自PDOStatment->fetchColumn($columnName)
	 *
	 * @param array $arr 第一维必须为数组,第二维可以为数组或者stdClass对象
	 * @param string $key
	 * @return array 一维数组
	 * @example
	 * $data = $db->getAll('xxx');
	 * $arr = self::getColumn($data, 'rating')
	 */
	public static function getColumn($arr, $key)
	{
		$_tmp = array();
		foreach ($arr as $k => $row) {
			//$row => array
			if (is_array($row)) {
				$_tmp[$k] = $row[$key];
			}
			//$row => stdClass
			else {
				$_tmp[$k] = $row->$key;
			}
		}
		return $_tmp;
	}

	/**
	 * 根据数组的某个键对整个外围数组进行正向或反向排序
	 *
	 * @param array &$array
	 * @param string $key
	 * @param bool $assoc
	 * @param bool $reverse
	 * @return void
	 * @example
	 * $arr = array( array('aaa', 'sorting'=>4), array('bbb', 'sorting'=>2), array('ccc', 'sorting'=>3), array('ddd', 'sorting'=>2) );
	 * self::sortByKey($arr, 'sorting', true, true);
	 */
	/**
	 * 用array_multisort()代替
	 * @example
	 * $data = $db->getAll('xxx');
	 * $arr = self::getColumn($data, 'rating');
	 * array_multisort($arr, $data);
	 * print_r($data);
	 */
//	public static function sortByKey(&$array, $key, $assoc = false, $reverse = false)
//	{
//		$_tmp = array();
//
//		//保留键名到数据的关联
//		if ($assoc) {
//			foreach ($array as $k => $v) {
//				$_tmpKey = $v[$key];
//				while (array_key_exists($_tmpKey, $_tmp)) {
//					$_tmpKey++;
//				}
//				$_tmp[$_tmpKey] = array($k, $v);
//			}
//
//			//反序
//			if ($reverse) {
//				krsort($_tmp);
//			}
//			//正序
//			else {
//				ksort($_tmp);
//			}
//
//			$_tmp2 = array();
//			foreach ($_tmp as $v) {
//				$_tmp2[$v[0]] = $v[1];
//			}
//			$array = $_tmp2;
//			return;
//		}
//
//		//不保留键名到数据的关联
//		foreach ($array as $k => $v) {
//			$_tmpKey = $v[$key];
//			while (array_key_exists($_tmpKey, $_tmp)) {
//				$_tmpKey++;
//			}
//
//			$_tmp[$_tmpKey] = $v;
//		}
//		//反序
//		if ($reverse) {
//			krsort($_tmp);
//		}
//		//正序
//		else {
//			ksort($_tmp);
//		}
//		$array = $_tmp;
//		return;
//	}
}