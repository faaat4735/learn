<?php
/**
 * 图象处理基类
 * @author  Jcan
 * @version 1.1
 */

class Jcan_Image
{
	//图片名称
	protected $_imageName;
	//图片宽度
	protected $_imageWidth;
	//图片高度
	protected $_imageHeight;

	//背景色 - 红色
	protected $_bgColorRed = 255;
	//背景色 - 绿色
	protected $_bgColorGreen = 255;
	//背景色 - 蓝色
	protected $_bgColorBlue = 255;

	//字体颜色 - 红色
	protected $_fontColorRed = 0;
	//字体颜色 - 绿色
	protected $_fontColorGreen = 0;
	//字体颜色 - 蓝色
	protected $_fontColorBlue = 0;

	//字体大小
	protected $_fontSize = 4;

	//图片类型, 四种可能值： image/gif, image/x-png, image/pjpeg, image/bmp (image/png, image/jpg, image/jpeg)
	protected $_imageType;

	/**
	 * 构造函数
	 */
	public function __construct($imageName = null)
	{
		if (!is_null) {
			$this->_imageName = $imageName;
			$this->_imageInfo = @getImageSize($this->_imageName);
			if (isset($this->_imageInfo[2]) && in_array(
					$this->_imageInfo[2], array(IMG_GIF,IMG_JPG,IMG_PNG,IMG_WBMP))) {
				$this->_imageWidth	= $this->_imageInfo[0];
				$this->_imageHeight	= $this->_imageInfo[1];
				$this->_imageType	= $this->_imageInfo['mime'];
			}
		}
	}

	/**
	 * 设置背景色
	 *
	 * @param int $red
	 * @param int $green
	 * @param int $blue
	 */
	public function setBgColor($red, $green, $blue)
	{
		$this->_bgColorRed   = $red;
		$this->_bgColorGreen = $green;
		$this->_bgColorBlue  = $blue;
	}

	/**
	 * 设置字体颜色
	 *
	 * @param int $red
	 * @param int $green
	 * @param int $blue
	 */
	public function setFontColor($red, $green, $blue)
	{
		$this->_fontColorRed      = $red;
		$this->_fontColorGreen    = $green;
		$this->_fontColorBlue     = $blue;
	}

	/**
	* 设置字体大小
	*
	* @param int $size (0-5)
	*/
	public function setFontSize($size)
	{
		$this->_fontSize = $size;
	}

	/**
	 * 设置图片尺寸
	 *
	 * @param int $width
	 * @param int $height
	 */
	public function setImageSize($width, $height) {
		$this->_imageWidth   = $width;
		$this->_imageHeight  = $height;
	}


	/**
	 * 改变图片大小(生成缩略图)(以函数只压缩与裁切,不会拉伸)
	 *
	 * @param string    	$srcImage   图片地址及图片名
	 * @param string    	$dstImage   生成的图片地址及图片名(null表示覆盖srcImage)
	 * @param boolean	$cut	    true表示以最小边为基准进行裁切, false表示以最大边为基准进行缩小
	 * @param int       	$dstWidth   目标宽度
	 * @param int       	$dstHeight  目标高度
	 * @param string	$bgColors   #fff形式 或者 #ffffff形式 或者null(表示无填充)
	 * @param int       	$brightness 亮度(范围: -100~100)
	 * @param int       	$contrast   对比度(范围: -100~100)
	 */
	public static function resize($srcImage, $dstImage,
						$dstWidth = null, $dstHeight = null,
						$cut = true,
						$bgColors = '#ffffff',
						$brightness = 0, $contrast = 0)
	{
		//得到源图相关信息
		$srcInfo =@ getImageSize($srcImage);
		$srcWidth	= $srcInfo[0];
		$srcHeight	= $srcInfo[1];
		$srcType	= $srcInfo['mime'];

		//防止内存溢出
		if ($srcWidth > 6000) {
			return false;
		}

		// 载入原图
		switch ($srcType) {
			case 'image/jpg':
			case 'image/jpeg':
			case 'image/pjpeg':
			case 'image/pjpg':
				$oSrcImage = @imageCreateFromJpeg($srcImage);
				break;
			case 'image/gif':
				$oSrcImage = @imageCreateFromGif($srcImage);
				break;
			case 'image/png':
			case 'image/x-png':
				$oSrcImage = @imageCreateFromPng($srcImage);
				break;
			case 'image/bmp':
				$oSrcImage = @imageCreateFromBmp($srcImage);
				break;
			default:
				return false;
				break;
		}

		//判断是否用颜色填充, 并把十六进制背景色转换为三元色
		$fill = true;
		if (empty($bgColors)) {
			$fill = false;
		} elseif (!is_array($bgColors)) {
			$bgColors = self::parseHexColor($bgColors);
			if (!$bgColors) {
				$fill = false;
			}
		}

		if ($fill) {
			list($bgColorRed, $bgColorGreen, $bgColorBlue) = $bgColors;
		} else {
			$bgColorRed = $bgColorGreen = $bgColorBlue = 255;
		}


		/* 根据不同切割类型计算切割参数 */

		//自适应缩略图(仅设置宽度或仅设置高度,无切割)
		if (empty($dstHeight) || empty($dstWidth)) {
			if (empty($dstHeight) && empty($dstWidth)) {
				$dstTrueWidth = $srcWidth;
				$dstTrueHeight = $srcHeight;
			}
			elseif (empty($dstHeight)) {
				$dstTrueWidth = min($srcWidth, $dstWidth);
				$dstTrueHeight = round($srcHeight * $dstTrueWidth / $srcWidth);
			}
			elseif (empty($dstWidth)) {
				$dstTrueHeight = min($srcHeight, $dstHeight);
				$dstTrueWidth = round($srcWidth * $dstTrueHeight / $srcHeight);
			}
			$srcCutX = 0;
			$srcCutY = 0;
			$dstCutX = 0;
			$dstCutY = 0;
			$srcTrueWidth = $srcWidth;
			$srcTrueHeight = $srcHeight;

			$dstWidth = $dstTrueWidth;
			$dstHeight = $dstTrueHeight;
		}

		//宽与高都达不到要求
		elseif ($dstWidth > $srcWidth && $dstHeight > $srcHeight) {
			if (!$fill) {
				$dstWidth = $srcWidth;
				$dstHeight = $srcHeight;
			}

			$srcTrueWidth = $srcWidth;
			$srcTrueHeight = $srcHeight;
			$dstTrueWidth = $srcWidth;
			$dstTrueHeight = $srcHeight;

			$srcCutX = 0;
			$srcCutY = 0;
			$dstCutX = round(($dstWidth - $srcWidth) / 2);
			$dstCutY = round(($dstHeight - $srcHeight) / 2);
		}

		//宽与高至少有一个能达到要求
		else {

			//不填充空白处
			if (!$fill) {
				if ($srcWidth/$srcHeight > $dstWidth/$dstHeight) {
					$dstHeight = round($dstWidth*$srcHeight / $srcWidth);
				} else {
					$dstWidth = round($srcWidth*$dstHeight / $srcHeight);
				}
			}

			//无论如何都不切割图片
			if (!$cut) {
				$srcTrueWidth = $srcWidth;
				$srcTrueHeight = $srcHeight;
				$srcCutX = 0;
				$srcCutY = 0;

				//源图太宽
				if ($srcWidth/$srcHeight > $dstWidth/$dstHeight) {
					//以源图宽为准
					$dstTrueWidth = $dstWidth;
					$dstTrueHeight = round(($srcHeight/$srcWidth) * $dstWidth);

					$dstCutX = 0;
					$dstCutY = round(($dstHeight - $dstTrueHeight) / 2);
				}
				//源图太高
				else {
					//以源图高为准
					$dstTrueHeight = $dstHeight;
					$dstTrueWidth = round(($srcWidth/$srcHeight) * $dstHeight);

					$dstCutY = 0;
					$dstCutX = round(($dstWidth - $dstTrueWidth) / 2);
				}
			}

			//无论如何都切割图片, 或正好不切割
			else {
				//目标宽度大于源图宽度
				if ($dstWidth > $srcWidth) {
					$srcTrueWidth = $srcWidth;
					$dstTrueWidth = $srcWidth;
					$srcTrueHeight =$dstHeight;
					$dstTrueHeight = $dstHeight;

					$srcCutX = 0;
					$srcCutY = round(($srcHeight - $dstHeight) / 2);
					$dstCutX = round(($dstWidth - $srcWidth) / 2);
					$dstCutY = 0;
				}
				//目标高度大于源图高度
				elseif ($dstHeight > $srcHeight) {
					$srcTrueWidth = $dstWidth;
					$dstTrueWidth = $dstWidth;
					$srcTrueHeight = $srcHeight;
					$dstTrueHeight = $srcHeight;

					$srcCutX = round(($srcWidth - $dstWidth) / 2);
					$srcCutY = 0;
					$dstCutX = 0;
					$dstCutY = round(($dstHeight - $srcHeight) / 2);
				} else {
					/* 目标的宽与高均小于源图 */
					$dstTrueWidth = $dstWidth;
					$dstTrueHeight = $dstHeight;
					$dstCutX = 0;
					$dstCutY = 0;
					//源图太宽,以高为准
					if ($srcWidth/$srcHeight > $dstWidth/$dstHeight) {
						$srcTrueHeight = $srcHeight;
						$srcTrueWidth = round(($dstWidth/$dstHeight) * $srcHeight);

						$srcCutX = round(($srcWidth - $srcTrueWidth) / 2);
						$srcCutY = 0;
					}
					//源图太高,以宽为准
					else {
						$srcTrueWidth = $srcWidth;
						$srcTrueHeight = round(($dstHeight/$dstWidth) * $srcWidth);

						$srcCutX = 0;
						$srcCutY = round(($srcHeight - $srcTrueHeight) / 2);
					}
				}
			}
		}

/* 调试用 */
//print <<< EOF
//srcWidth	$srcWidth
//srcHeigh	$srcHeight
//dstWidth	$dstWidth
//dstHeight	$dstHeight
//
//srcTrueWidth	$srcTrueWidth
//srcTrueHeight	$srcTrueHeight
//dstTrueWidth	$dstTrueWidth
//dstTrueHeight	$dstTrueHeight
//
//srcCutX		$srcCutX
//srcCutY		$srcCutY
//dstCutX		$dstCutX
//dstCutY		$dstCutY
//
//srcType		$srcType
//EOF;

		//创建目标图
		$oDstImage = imageCreateTrueColor($dstWidth, $dstHeight);

		// 填充背景色
		$back = imageColorAllocate($oDstImage, $bgColorRed, $bgColorGreen, $bgColorBlue);
		imageFill($oDstImage, 0, 0, $back);

		// 对源图进行裁切
		$retval = @imageCopyResampled($oDstImage, $oSrcImage, $dstCutX, $dstCutY, $srcCutX, $srcCutY, $dstTrueWidth, $dstTrueHeight, $srcTrueWidth, $srcTrueHeight);
		if (!$retval) return false;

		// 调整图片的亮度, 范围-100-100
		if (!empty($brightness)) {
			@imageFilter($oDstImage, IMG_FILTER_BRIGHTNESS, $brightness);
		}

		// 调整图片的对比度, 范围-100-100
		if (!empty($contrast)) {
			@imageFilter($oDstImage, IMG_FILTER_CONTRAST, -$contrast);
		}

		// 创建图片, 第三个参数表示生成图片的质量， 范围0-100
		if (empty($dstImage)) $dstImage = $srcImage;
		$retval = @imageJpeg($oDstImage, $dstImage, 100);
		if (!$retval) return false;

		// 释放资源
		@imageDestroy($oSrcImage);
		@imageDestroy($oDstImage);
		return true;
	}


	/**
	 * 把十六进制的颜色转换为由三元色组成的数组,失败返回假
	 *
	 * @param string $hexColor (十六进制颜色, 格式为:#fff或#f3f3f4
	 * @return array|boolean 返回的一个可能值为:array(255, 22, 0) 顺序为:红绿蓝
	 */
	public static function parseHexColor($hexColor)
	{
		if (strlen($hexColor) == 4) {
			$hexColor = preg_replace('!\#([\da-z])([\da-z])([\da-z])!', "#\${1}\${1}\${2}\${2}\${3}\${3}", $hexColor);
		}

		if (strlen($hexColor) != 7) {
			return false;
		}

		if($hexColor{0} != "#") return false;
		$hexColor = substr($hexColor, 1);
		$decColor = hexdec($hexColor);

		$colors = array();
		$colors[]	= (($decColor & 0xFF0000) >> 16); //red
		$colors[]	= (($decColor & 0x00FF00) >>  8); //green
		$colors[]	=  ($decColor & 0x0000FF); //blue
		return $colors;
	}
}


/**
 * 给资源im分配颜色与透明度
 *
 * @param im $im
 * @param string $hexColor (十六进制颜色)
 * @param string $alpha (0-127)
 * @return $oColor
 * @example imageColorAllocateHex($im, '#cde')
 * @example imageColorAllocateHex($im, '#fefefe', 110)
 */
function imageColorAllocateHex(&$im, $hexColor, $alpha=0)
{
	$colors = Jcan_Image::parseHexColor($hexColor);
	if (!$colors) {
		return false;
	}
	list($red, $green, $blue) = $colors;

	if ($alpha) {
		return imagecolorallocatealpha($im, $red, $green, $blue, $alpha);
	}

	return imagecolorallocate($im, $red, $green, $blue);
}


/**
 * ImageCreateFromBmp
 *
 * @param $string $filename
 * @return im
 */
function imageCreateFromBmp($filename)
{
	//Ouverture du fichier en mode binaire
	if (! $f1 = fopen($filename,"rb")) return false;

	//1 : Chargement des ent?s FICHIER
	$FILE = unpack("vfile_type/Vfile_size/Vreserved/Vbitmap_offset", fread($f1,14));
	if ($FILE['file_type'] != 19778) return false;

	//2 : Chargement des ent?s BMP
	$BMP = unpack('Vheader_size/Vwidth/Vheight/vplanes/vbits_per_pixel'.
		'/Vcompression/Vsize_bitmap/Vhoriz_resolution'.
		'/Vvert_resolution/Vcolors_used/Vcolors_important', fread($f1,40));
	$BMP['colors'] = pow(2,$BMP['bits_per_pixel']);
	if ($BMP['size_bitmap'] == 0) $BMP['size_bitmap'] = $FILE['file_size'] - $FILE['bitmap_offset'];
	$BMP['bytes_per_pixel'] = $BMP['bits_per_pixel']/8;
	$BMP['bytes_per_pixel2'] = ceil($BMP['bytes_per_pixel']);
	$BMP['decal'] = ($BMP['width']*$BMP['bytes_per_pixel']/4);
	$BMP['decal'] -= floor($BMP['width']*$BMP['bytes_per_pixel']/4);
	$BMP['decal'] = 4-(4*$BMP['decal']);
	if ($BMP['decal'] == 4) $BMP['decal'] = 0;

	//3 : Chargement des couleurs de la palette
	$PALETTE = array();
	if ($BMP['colors'] < 16777216) {
		$PALETTE = unpack('V'.$BMP['colors'], fread($f1,$BMP['colors']*4));
	}

	//4 : Cr顴ion de l'image
	$IMG = fread($f1,$BMP['size_bitmap']);
	$VIDE = chr(0);

	$res = imagecreatetruecolor($BMP['width'],$BMP['height']);
	$P = 0;
	$Y = $BMP['height']-1;
	while ($Y >= 0) {
		$X=0;
		while ($X < $BMP['width']) {
			if ($BMP['bits_per_pixel'] == 32 || $BMP['bits_per_pixel'] == 24) {
				$COLOR = unpack("V",substr($IMG,$P,3).$VIDE);
			} elseif ($BMP['bits_per_pixel'] == 16) {
				$COLOR = unpack("n",substr($IMG,$P,2));
				$COLOR[1] = $PALETTE[$COLOR[1]+1];
			} elseif ($BMP['bits_per_pixel'] == 8) {
				$COLOR = unpack("n",$VIDE.substr($IMG,$P,1));
				$COLOR[1] = $PALETTE[$COLOR[1]+1];
			} elseif ($BMP['bits_per_pixel'] == 4) {
				$COLOR = unpack("n",$VIDE.substr($IMG,floor($P),1));
				if (($P*2)%2 == 0) $COLOR[1] = ($COLOR[1] >> 4) ; else $COLOR[1] = ($COLOR[1] & 0x0F);
				$COLOR[1] = $PALETTE[$COLOR[1]+1];
			} elseif ($BMP['bits_per_pixel'] == 1) {
				$COLOR = unpack("n",$VIDE.substr($IMG,floor($P),1));
				if    (($P*8)%8 == 0) $COLOR[1] =  $COLOR[1]        >>7;
				elseif (($P*8)%8 == 1) $COLOR[1] = ($COLOR[1] & 0x40)>>6;
				elseif (($P*8)%8 == 2) $COLOR[1] = ($COLOR[1] & 0x20)>>5;
				elseif (($P*8)%8 == 3) $COLOR[1] = ($COLOR[1] & 0x10)>>4;
				elseif (($P*8)%8 == 4) $COLOR[1] = ($COLOR[1] & 0x8)>>3;
				elseif (($P*8)%8 == 5) $COLOR[1] = ($COLOR[1] & 0x4)>>2;
				elseif (($P*8)%8 == 6) $COLOR[1] = ($COLOR[1] & 0x2)>>1;
				elseif (($P*8)%8 == 7) $COLOR[1] = ($COLOR[1] & 0x1);
				$COLOR[1] = $PALETTE[$COLOR[1]+1];
			} else
				return FALSE;
			imagesetpixel($res,$X,$Y,$COLOR[1]);
			$X++;
			$P += $BMP['bytes_per_pixel'];
		}
		$Y--;
		$P+=$BMP['decal'];
	}

	//Fermeture du fichier
	fclose($f1);

	return $res;
}

?>