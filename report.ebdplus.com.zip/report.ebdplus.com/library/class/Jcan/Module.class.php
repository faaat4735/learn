<?php

abstract class Jcan_Module extends Jcan_Observable
{
	/**
	 * 每个模块都拥有如下四个属性(模版对象,标题,关键字,描述)
	 */
	public $tpl;
	public $title;
	public $keywords;
	public $description;

	/**
	 * 构造函数,这儿的主要作用是把常用变量应用到模块的模板里
	 *
	 * @param Jcan_Tpl $tpl
	 */
	public function __construct($tpl)
	{
		$this->tpl =& $tpl;

		/**
		 * 自动把模块拥有的"模板,标题,关键字,描述"引入模板变量
		 * 这样做的好处是: 1.方便模板程序调用, 2.简化操作
		 */
		$this->tpl->view['title'] =& $this->title;
		$this->tpl->view['keywords'] =& $this->keywords;
		$this->tpl->view['description'] =& $this->description;
	}

	/**
	 * 析构函数(触发监视器)
	 */
	public function __destruct()
	{
		$this->notifyObservers();
	}

	/**
	 * 模块对不安全数据的处理
	 * 子模块最好针对不同情况进行重写
	 * @return false
	 */
	public function unsafe()
	{
		//这儿可根据$this->module与$this->action的不同采取不同的处理措施
		return false;
	}

	/**
	 * 显示模板
	 * @param string $file optional,要显示的模板文件
	 */
	public function display($file = null, $cache_id = null, $compile_id = null)
	{
		if (!isset($file)) {
			$file = $this->tpl->channel . '/' . $this->tpl->module . '_' . $this->tpl->action . '.tpl';
		}
		$this->tpl->display($file, $cache_id, $compile_id);
	}

	/**
	 * 在同一模块中转向另一个动作
	 *
	 * @param string $action
	 * @return mixed
	 * @example $this->redirect('register', 'param1', 'param2')
	 */
	public function redirect($action)
	{
		$actionName = $action . 'Action';
		$this->tpl->action = $action;

		$params = func_get_args();
		array_shift($params);
		return call_user_func_array(array($this, $actionName), $params);
	}

	/**
	 * 反射到不同模块的不同动作
	 *
	 * @param string $module
	 * @param string $action
	 * @example $this->reflect('User', 'login', 'param1', 'param2', ...)
	 */
	public function reflect($module, $action)
	{
		$className = get_class($this);
		$className = preg_replace('/\_[^_]+$/', '_' . $module, $className);
		$actionName = $action . 'Action';

		$oModule = new $className($this->tpl);
		$oModule->tpl->module = $module;
		$oModule->tpl->action = $action;

		$params = func_get_args();
		$params = array_slice($params, 2);
		return call_user_func_array(array($oModule, $actionName), $params);
	}
}