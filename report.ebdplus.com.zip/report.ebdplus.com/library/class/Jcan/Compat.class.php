<?php

/**
 * 解决不种环境下的兼容性问题
 */
class Jcan_Compat
{
	public static function magicQuotes()
	{
		//防止 magic_quotes_gpc 被打开
		if (function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc()) {
			$in = array(&$_GET, &$_POST, &$_COOKIE);
			while (list($k,$v) = each($in)) {
				foreach ($v as $key => $val) {
					if (!is_array($val)) {
						$in[$k][$key] = stripslashes($val);
						continue;
					}
					$in[] =& $in[$k][$key];
				}
			}
			unset($in);
		}
	}
}