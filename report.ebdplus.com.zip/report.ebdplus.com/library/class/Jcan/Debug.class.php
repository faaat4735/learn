<?php

class Jcan_Debug
{
	/**
	 * Debug helper function.  This is a wrapper for var_dump() that adds
	 * the <pre /> tags, cleans up newlines and indents, and runs
	 * htmlentities() before output.
	 *
	 * @param  mixed  $var The variable to dump.
	 * @param  string $label An optional label.
	 * @return string
	 */
	public static function dump($var, $label=null, $echo=true)
	{
		// format the label
		$label = ($label===null) ? '' : rtrim($label) . ' ';

		// var_dump the variable into a buffer and keep the output
		ob_start();
		var_dump($var);
		$output = ob_get_clean();

		// neaten the newlines and indents
		$output = preg_replace("/\]\=\>\n(\s+)/m", "] => ", $output);
		if (PHP_SAPI == 'cli') {
			$output = PHP_EOL . $label
				. PHP_EOL . $output
				. PHP_EOL;
		} else {
			$output = '<pre style="text-align:left !important; background:#f3f3f3; color:#333; border:1px dotted #000; padding:5px; margin:5px; font-family:\'Courier New\'; font-size:12px;">'
				. '<strong>' . $label . '</strong>'
				. htmlspecialchars($output)
				. '</pre>';
			$output = preg_replace_callback(
				'/^ +/um',
				create_function('$matches', 'return str_replace(" ", "  ", $matches[0]);'),
				$output);
		}

		if ($echo) {
			echo($output);
		}
		return $output;
	}

	public static function printr($var, $label=null, $echo=true)
	{
		// format the label
		$label = ($label===null) ? '' : rtrim($label) . ' ';

		// var_dump the variable into a buffer and keep the output
		ob_start();
		print_r($var);
		$output = ob_get_clean();

		// neaten the newlines and indents
		$output = preg_replace("/\]\=\>\n(\s+)/m", "] => ", $output);
		if (PHP_SAPI == 'cli') {
			$output = PHP_EOL . $label
				. PHP_EOL . $output
				. PHP_EOL;
		} else {
			$output = '<pre style="text-align:left !important; background:#f3f3f3; color:#333; border:1px dotted #000; padding:5px; margin:5px; font-family:\'Courier New\'; font-size:12px;">'
				. '<strong>' . $label . '</strong>'
				. htmlspecialchars($output)
				. '</pre>';
		}

		if ($echo) {
			echo($output);
		}
		return $output;
	}

	public static function export($var, $label=null, $echo=true)
	{
		// format the label
		$label = ($label===null) ? '' : rtrim($label) . ' ';

		// var_dump the variable into a buffer and keep the output
		ob_start();
		var_export($var);
		$output = ob_get_clean();

		// neaten the newlines and indents
		$output = preg_replace("/\]\=\>\n(\s+)/m", "] => ", $output);
		if (PHP_SAPI == 'cli') {
			$output = PHP_EOL . $label
				. PHP_EOL . $output
				. PHP_EOL;
		} else {
			$output = '<pre style="text-align:left !important; background:#f3f3f3; color:#333; border:1px dotted #000; padding:5px; margin:5px; font-family:\'Courier New\'; font-size:12px;">'
				. '<strong>' . $label . '</strong>'
				. htmlspecialchars($output)
				. '</pre>';
			$output = preg_replace_callback(
				'/^ +/um',
				create_function('$matches', 'return str_replace("  ", "\t", $matches[0]);'),
				$output);
		}

		if ($echo) {
			echo($output);
		}
		return $output;
	}

	/**
	 * 根据不同错误类型、不同调试模式来记录错误
	 *
	 * @param string $errorInfo	错误信息
	 * @param const $errorType	错误类型(E_ERROR, E_NOTICE, E_WARNING)
	 * @param string $errorFile	错误文件
	 * @param int $errorLine	错误行号
	 */
	public static function logError($errorInfo, $errorType = E_ERROR, $errorFile = null, $errorLine = null)
	{
		switch ($errorType) {
			case E_NOTICE :
			case E_WARNING :
			case E_ERROR :
			default:
				$errorInfo = "ERROR:\t{$errorInfo}";

				switch ($errorType) {

					case E_NOTICE:
						$type = 'E_NOTICE';
						$callback = 'eNoticeCallback';
						break;

					case E_WARNING:
						$type = 'E_WARNING';
						$callback = 'eWarningCallback';
						break;

					case E_ERROR:
					default:
						$type = 'E_ERROR';
						$callback = 'eErrorCallback';
						break;
				}
				$errorInfo .= "\nTYPE:\t{$type}";

				if (!empty($errorFile)) {
					$errorInfo .= "\nFILE:\t{$errorFile} : {$errorLine}";
				}

				if (DEBUG_MODE) {
					printf("<div style='background:#ffe; color:#f00; border:1px dotted #000; padding:8px; margin:4px; font-family:Courier New; font-size:13px; font-weight:bold;'>%s</div>",
							nl2br(str_replace("\n", "\n\n", $errorInfo)));
					die;
				}

				$errorInfo	.= "\nTIME:\t" . date('Y-m-d H:i:s')
						. "\nIP:\t" . Jcan_Http::getIpList()
						. "\nURL:\t" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
						. "\n----------------------------------------------------------------------\n\n";
				file_put_contents(ERROR_LOG, $errorInfo, FILE_APPEND);

				if (!defined('ERROR_HANDLER_CLASS')) {
					define('ERROR_HANDLER_CLASS', 'Jcan_Error');
				}
				call_user_func(array(ERROR_HANDLER_CLASS, $callback));
				break;
		}
	}

	/**
	 * 取得被调用的函数对象, 相当于JS中的 arguments.caller
	 *
	 * @param string $key 可为:file, line, function, class, object, type, args
	 * @return mixed
	 */
	public static function caller($key = null)
	{
		$_arr = debug_backtrace();
		if (!isset($_arr[2])) {
			return false;
		}
		$caller = $_arr[2];

		return isset($key) ? $caller[$key] : $caller;
	}

	/**
	 * 被简化返回字段的debug_backtrace()函数
	 *
	 * @param bool $echo 是否输出
	 * @return array
	 */
	public static function simpleBacktrace($echo = false)
	{
		$_arr = debug_backtrace();
		foreach ($_arr as &$_v) {
			unset($_v['object']);
			unset($_v['args']);
		}

		if ($echo) {
			Jcan_Debug::dump($_arr);
		}
		return $_arr;
	}

	/**
	 * 分析类结构
	 *
	 * @example self::parseClass('Jcan_Db', 'query')
	 * @example self::parseClass('Jcan')
	 * @param String $className
	 * @return echo
	 */
	public static function parseClass($className, $methodName = null)
	{
		ob_start();
		$class = new ReflectionClass($className);

		if ($methodName === null) {
			$methods = $class->getMethods();
		} else {
			$method = $class->getMethod($methodName);
			$methods = (array)$method;
		}

		//ReflectionClass::export($className);

		foreach ($methods as $method) {
			$methodName = $method->getName();

			ReflectionMethod::export($className, $methodName);

			echo "-------------------------------------------------\n";
		}

		$output = ob_get_clean();
		echo '<pre>' . htmlspecialchars(str_replace("\t", '', $output)) . '</pre>';
	}

	/**
	 * @return void
	 * @see self::sprintln()
	 * @example self::println($key, $value, "<br />")
	 */
	public static function println()
	{
		$params = func_get_args();
		$str = call_user_func_array(array('self', 'sprintln'), $params);
		echo $str;
	}

	/**
	 * @return string
	 * @see self::println()
	 * @example echo self::sprintln($key, $value)
	 */
	public static function sprintln()
	{
		$params = func_get_args();
		$str = implode("\t", $params) . "\n";
		return $str;
	}
}