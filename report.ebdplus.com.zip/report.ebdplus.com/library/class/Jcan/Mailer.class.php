<?php

class Jcan_Mailer extends PHPMailer
{

}