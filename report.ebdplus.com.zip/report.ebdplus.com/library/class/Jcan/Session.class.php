<?php
/**
 * Ddo session (2006.10.28)
 * @author Jcan (yuanjie.zhong@gmail.com)
 * @version 1.0
 */
class Jcan_Session
{
	private $db;
	private $_session_table = 'utf_19dog.session';
	private $_session_id_field = 'sess_id';
	private $_session_value_field = 'sess_value';
	private $_session_time_field = 'sess_time';
	private $_session_username_field = 'user_name';

	public function __construct(&$db, $maxlifetime = 1440, $divisor = 1000, $cookieDomain = null)
	{
		$this->db = $db;
		ini_set('session.save_handler', 'user');
		ini_set('session.cookie_lifetime', 0);
		ini_set('session.gc_divisor', $divisor);
		ini_set('session.gc_maxlifetime', $maxlifetime);
		if (!is_null($cookieDomain)) {
			ini_set('session.cookie_domain', $cookieDomain);
		}
//		ini_set('session.cookie_path', '/');

		session_set_save_handler(
			array(&$this, '_open'),
			array(&$this, '_close'),
			array(&$this, '_read'),
			array(&$this, '_write'),
			array(&$this, '_destroy'),
			array(&$this, '_gc'));
		session_start();
	}

	public function _open($path, $sessIdKey)
	{
		return true;
	}

	public function _close()
	{
		return true;
	}

	public function _read($sessId)
	{
		$rs = $this->db->prepare("SELECT {$this->_session_value_field} FROM {$this->_session_table} WHERE {$this->_session_id_field} = ?");
		$rs->bindParam(1, $sessId, PDO::PARAM_STR);
		$rs->execute();
		return $rs->fetchColumn();
	}

	public function _write($sessId, $sessValue)
	{
//		if (WINDOWS) {
//			$rs = $this->db->prepare("INSERT INTO {$this->_session_table} ({$this->_session_id_field}, {$this->_session_value_field}) VALUES (:sessId, :sessValue)
//						ON DUPLICATE KEY UPDATE {$this->_session_value_field} = :sessValue");
//			$rs->bindParam(':sessId', $sessId, PDO::PARAM_STR);
//			$rs->bindParam(':sessValue', $sessValue, PDO::PARAM_STR);
//			$rs->execute();
//		} else {
			$rs = $this->db->prepare("SELECT count(*) FROM {$this->_session_table}
						WHERE {$this->_session_id_field} = :sessId");
			$rs->bindParam(':sessId', $sessId, PDO::PARAM_STR);
			$rs->execute();
			$has =$rs->fetchColumn();
			$rs->closeCursor();

			$username = isset($_SESSION['userInfo']->username) ? $_SESSION['userInfo']->username : Jcan::getIp();
			if ($has) {
				$rs = $this->db->prepare("UPDATE {$this->_session_table} SET {$this->_session_value_field} = :sessValue, {$this->_session_username_field} = :username
							WHERE {$this->_session_id_field} = :sessId");

			} else {
				$rs = $this->db->prepare("INSERT {$this->_session_table} ({$this->_session_id_field}, {$this->_session_value_field}, {$this->_session_username_field})
							VALUES (:sessId, :sessValue, :username)");
			}

			$rs->bindParam(':sessValue', $sessValue, PDO::PARAM_STR);
			$rs->bindParam(':sessId', $sessId, PDO::PARAM_STR);
			$rs->bindParam(':username', $username, PDO::PARAM_STR);
			$rs->execute();
//		}

		return true;
	}

	public function _destroy($sessId)
	{
		$rs = $this->db->prepare("DELETE FROM {$this->_session_table} WHERE {$this->_session_id_field} = ?");
		$rs->bindParam(1, $sessId, PDO::PARAM_STR);
		$rs->execute();
		return true;
	}

	public function _gc($lifeTime)
	{
		$rs = $this->db->prepare("DELETE FROM {$this->_session_table} WHERE {$this->_session_time_field} < now() - interval ? second");
		$rs->bindParam(1, $lifeTime, PDO::PARAM_INT);
		$rs->execute();
		return true;
	}
}
