<?php

class Jcan_Encrypt
{
	/**
	 * 用自己的规则改写md5
	 *
	 * @param string $str
	 * @param bool $rawOutput
	 * @return string
	 */
	public static function md5($str, $rawOutput = false)
	{
		return strrev(md5($str, $rawOutput));
	}

	/**
	 * 得到字符串的16位md5
	 *
	 * @param string $str
	 * @param bool $rawOutput
	 * @return string
	 */
	public static function md5_16($str, $rawOutput = false)
	{
		return substr(self::md5($str, $rawOutput), 8, 16);
	}

	/**
	 * 得到字符串的8位md5
	 *
	 * @param string $str
	 * @param bool $rawOutput
	 * @return string
	 */
	public static function md5_8($str, $rawOutput = false)
	{
		return substr(self::md5($str, $rawOutput), 12, 8);
	}

	/**
	 * 得到32位或16位或8位随机字符串(默认为32位)
	 *
	 * @param enum $length 32,16,8
	 * @return string 16进制
	 */
	public static function getUniqueId($length = 32)
	{
		$uniqueId = uniqid(rand(), true);

		switch ($length) {
			case 16:
				return self::md5_16($uniqueId);
				break;
			case 8:
				return self::md5_8($uniqueId);
				break;
			case 32:
			default:
				return self::md5($uniqueId);
				break;

		}
	}

	/**
	 * 得到22位随机字符串(如果不够22位将用0在前面补全22位)
	 *
	 * @return string 22位的62进制
	 */
	public static function getUniqueId_22()
	{
		$uniqueId_32 = self::getUniqueId(32);
		$uniqueId_22 = Jcan_Math::base2base($uniqueId_32, 16, 62);
		$uniqueId_22 = str_pad($uniqueId_22, 22, '0', STR_PAD_LEFT);
		return $uniqueId_22;
	}

	/**
	 * 得到11位随机字符串(如果不够11位将用0在前面补全11位)
	 *
	 * @return string 11位的62进制
	 */
	public static function getUniqueId_11()
	{
		$uniqeId_16 = self::getUniqueId(16);
		$uniqeId_11 = Jcan_Math::base2base($uniqeId_16, 16, 62);
		$uniqeId_11 = str_pad($uniqeId_11, 11, '0', STR_PAD_LEFT);
		return $uniqeId_11;
	}

	/**
	 * 得到6位随机字符串(如果不够11位将用0在前面补全11位)
	 *
	 * @return string 11位的62进制
	 */
	public static function getUniqueId_6()
	{
		$uniqeId_8 = self::getUniqueId(8);
		$uniqeId_6 = Jcan_Math::base2base($uniqeId_8, 16, 62);
		$uniqeId_6 = str_pad($uniqeId_6, 6, '0', STR_PAD_LEFT);
		return $uniqeId_6;
	}


	/**
	 * 扩展的base64_encode
	 *
	 * @param string $str 待编码的字符串
	 * @param string $key 密钥
	 * @param array $map 编码转换时映射表, 如:array('/'=>'_', '+'=>'-')
	 * @return string 编码后的字符串(去掉了末尾可能存在的=)
	 */
	public static function base64Encode($str, $key = null, $map = null)
	{
		if (empty($key)) {
			$str = base64_encode($str);
		} else {
			$tmp = '';
			$keycnt = strlen($key);
			for ($i=0, $cnt=strlen($str); $i<$cnt; $i++) {
				$char = substr($str, $i, 1);
				$keychar = substr($key, ($i%$keycnt)-1, 1);
				$char = chr(ord($char)+ord($keychar));
				$tmp .= $char;
			}
			$str = base64_encode($tmp);
		}

		if (!empty($map)) {
			$from = array_keys($map);
			$to = array_values($map);
			$str = str_replace($from, $to, $str);
		}
		return rtrim($str, '=');
	}

	/**
	 * 扩展的base64_decode
	 *
	 * @param string $str 待解码的字符串
	 * @param string $key 密钥
	 * @param array $map 解码转换时映射表, 如:array('/'=>'_', '+'=>'-')
	 * @return string 解码后的字符串
	 */
	public static function base64Decode($str, $key = null, $map = null)
	{
		if (!empty($map)) {
			$from = array_values($map);
			$to = array_keys($map);
			$str = str_replace($from, $to, $str);
		}
		$str = base64_decode($str);

		if (empty($key)) {
			return $str;
		}

		$tmp = '';
		$keycnt = strlen($key);
		for ($i=0, $cnt=strlen($str); $i<$cnt; $i++) {
			$char = substr($str, $i, 1);
			$keychar = substr($key, ($i%$keycnt)-1, 1);
			$char = chr(ord($char)-ord($keychar));
			$tmp .= $char;
		}
		return $tmp;
	}

	/**
	 * 把字符串转化为base62编码, 可通过key作为干扰达到混淆作用
	 *
	 * @param string $str
	 * @param string $key
	 * @return string
	 */
	public static function base62Encode($str, $key = null)
	{
		$base64 = self::base64Encode($str, $key, null);
		$base62 = Jcan_Math::base2base($base64, 64, 62);
		return $base62;
	}

	/**
	 * 把base62编码还原, 还原时需要key
	 *
	 * @param string $base62
	 * @param string $key
	 * @return string
	 */
	public static function base62Decode($base62, $key = null)
	{
		$base64 = Jcan_Math::base2base($base62, 62, 64);
		$str = self::base64Decode($base64, $key, null);
		return $str;
	}

	/**
	 * 对密码进行加密解密
	 *
	 * @param string $string
	 * @param enum $operation ENCODE, DECODE
	 * @param string $key
	 * @param int $expiry
	 * @param int $ckey_length
	 * @return string
	 */
	public static function authcode($string, $operation = 'DECODE', $key = SECURITY_KEY, $expiry = 0, $ckey_length = 4)
	{
		// 随机密钥长度ckey_length 取值 0-32;
		// 加入随机密钥，可以令密文无任何规律，即便是原文和密钥完全相同，加密结果也会每次不同，增大破解难度。
		// 取值越大，密文变动规律越大，密文变化 = 16 的 $ckey_length 次方
		// 当此值为 0 时，则不产生随机密钥

		$key = md5($key);
		$keya = md5(substr($key, 0, 16));
		$keyb = md5(substr($key, 16, 16));
		$keyc = $ckey_length
				? ($operation == 'DECODE'
					? substr($string, 0, $ckey_length)
					: substr(md5(microtime()), -$ckey_length))
				: '';

		$cryptkey = $keya . md5($keya . $keyc);
		$key_length = strlen($cryptkey);

		$string = $operation == 'DECODE'
				? base64_decode(substr($string, $ckey_length))
				: sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string.$keyb), 0, 16) . $string;
		$string_length = strlen($string);

		$result = '';
		$box = range(0, 255);

		$rndkey = array();
		for ($i = 0; $i < 256; $i++) {
			$rndkey[$i] = ord($cryptkey[$i % $key_length]);
		}

		for ($j = $i = 0; $i < 256; $i++) {
			$j = ($j + $box[$i] + $rndkey[$i]) % 256;
			$tmp = $box[$i];
			$box[$i] = $box[$j];
			$box[$j] = $tmp;
		}

		for ($a = $j = $i = 0; $i < $string_length; $i++) {
			$a = ($a + 1) % 256;
			$j = ($j + $box[$a]) % 256;
			$tmp = $box[$a];
			$box[$a] = $box[$j];
			$box[$j] = $tmp;
			$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
		}

		if ($operation == 'DECODE') {
			if ((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0)
				&& substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
				return substr($result, 26);
			} else {
				return '';
			}
		} else {
			return $keyc . rtrim(base64_encode($result), '=');
		}
	}
}