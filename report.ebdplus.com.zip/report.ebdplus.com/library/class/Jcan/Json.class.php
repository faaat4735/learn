<?php
/**
 * Json基类
 *
 */
class Jcan_Json
{
	/**
	 * 对json数据格式进行缩进
	 * 调试用，主要是方便查看json数据的结构
	 *
	 * @param string $jsonData
	 * @return 格式化后的string
	 */
	public static function indent($jsonData)
	{
		$strOut = '';
		$identPos = 0;

		for ($loop = 0; $loop<= strlen($jsonData); $loop++) {
			$_char = substr($jsonData, $loop, 1);
			//part 1
			if($_char == '}' || $_char == ']') {
				$strOut .= chr(13);
				$identPos--;
				$strOut .= str_repeat(chr(9), $identPos);
			}
			//part 2
			$strOut .= $_char;
			//part 3
			if ($_char == ',' || $_char == '{' || $_char == '[') {
				$strOut .= chr(13);
				if ($_char == '{' || $_char == '[') {
					$identPos++;
				}
				$strOut .= str_repeat(chr(9), $identPos);
			}
		}
		return $strOut;
	}
}

?>