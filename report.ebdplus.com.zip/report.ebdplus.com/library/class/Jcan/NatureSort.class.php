<?php

class Jcan_NatureSort implements Jcan_NatureSort_Interface
{
	public $db;
	public $bits = array(3, 3, 3);
	public $tableName = 't_areas';
	public $fieldIdName = 'area_id';
	public $prefix = true;

	/**
	 * 初始化
	 *
	 * @param Jcan_Db $db
	 */
	public function __construct(Jcan_Db $db = null)
	{
		$this->db = $db;
	}

	/**
	 * 取得范围字符串
	 *
	 * @param int $id
	 * @param string $field
	 * @return string
	 * @example
	 * 	$this->getScopeString(101000000) => BETWEEN 101000000 AND 101999999
	 * 	$this->getScopeString(101001300) => = 101001300
	 */
	public function getScopeString($id)
	{
		if (empty($id)) return false;

		$end = $this->_getNextId($id) - 1;
		if ($id == $end) {
			$scopeString = sprintf('= %d', $id);
		} else {
			$scopeString = sprintf('BETWEEN %d AND %d', $id, $end);
		}
		return $scopeString;
	}

	/**
	 * get next sub id by parent id
	 *
	 * @param int $id
	 * @param int $subLevel
	 * @return int
	 * @example
	 * 	$this->getNextSubId(101000000);
	 * 	$this->getNextSubId(null);
	 */
	public function getNextSubId($id, $subLevel = null)
	{
		if (!$this->db instanceof Jcan_Db) {
			throw new Exception('Please set database handler in constructor.');
			return false;
		}
		$level = $this->getLevel($id);

		if ($level == 0) {
			$sql = sprintf("SELECT MAX(%s) FROM %s",
				$this->fieldIdName,
				$this->tableName);
			$maxSubId = $this->db->getOne($sql);
		}
		else {
			$sql = sprintf("SELECT MAX(%s) FROM %s WHERE %s BETWEEN ? AND ?",
					$this->fieldIdName,
					$this->tableName,
					$this->fieldIdName);
			$maxSubId = $this->db->getOne($sql, $id+1, $this->_getNextId($id)-1);
		}

		if ($maxSubId === null) {
			$subId = $this->_getFirstSubId($id, $subLevel);
		} else {
			$subId = $this->_getNextId((int)$maxSubId, $level + 1);
		}
		return $subId;
	}

	/**
	 * 根据ID返回该ID所属级别
	 *
	 * @param int $id
	 * @return int
	 * @example
	 * 	$this->getLevel(101000000) => 1
	 * 	$this->getLevel(0) => 1
	 * 	$this->getLevel(null) => 0
	 */
	public function getLevel($id)
	{
		if ($id === null) return 0;
		if (empty($id)) return 1;

		$reverseBits = array_reverse($this->bits);
		$bit = 0;
		foreach ($reverseBits as $k => $v) {
			$bit += $v;
			if ($id % pow(10, $bit) != 0) {
				return count($this->bits) - $k;
			}
		}

		throw new Jcan_Exception('ID: ' . $id . ' 溢出');
	}

	/**
	 * 取得某级别的ID
	 *
	 * @param int $id
	 * @param int $level
	 * @return int
	 */
	public function getLevelId($id, $level)
	{
		if ($level === 0) {
			return null;
		}

		$e = array_sum(array_slice($this->bits, $level));
		$dividend = pow(10, $e);
		return intval($id / $dividend) * $dividend;
	}

	/**
	 * 取得父ID
	 *
	 * @param int $id
	 * @return int
	 */
	public function getParentId($id)
	{
		$level = $this->getLevel($id);
		if ($level < 1) {
			throw new Jcan_Exception('There isnot parent id');
		}

		return $this->getLevelId($id, $level -1);
	}

	/**
	 * 取得ID前缀部分
	 *
	 * @param int $id
	 * @param int $level
	 * @return int
	 * @example
	 * 	$this->_getIdPrefix(101002000) => 101002
	 * 	$this->_getIdPrefix(0) => 0
	 * 	$this->_getIdPrefix(101001001, 2) => 101001
	 * 	$this->_getIdPrefix(null) => null
	 */
	protected function _getIdPrefix($id, $level = null)
	{
		if ($level === null) {
			$level = $this->getLevel($id);
		}
		if ($level == 0) {
			return null;
		}

		$e = array_sum(array_slice($this->bits, $level));

		$prefix = intval($id / pow(10, $e));
		return $prefix;
	}

	/**
	 * 取得同一级的增加1的ID
	 *
	 * @param int $id
	 * @param int $level
	 * @return int
	 * @example
	 * 	$this->_getNextId(102001000) => 102002000
	 * 	$this->_getNextId(0) => 101000000
	 * 	$this->_getNextId(101001001, 1) => 102000000
	 * 	$this->_getNextId(null) => error
	 */
	protected function _getNextId($id, $level = null)
	{
		if ($level === null) {
			$level = $this->getLevel($id);
		}

		if ($level == 0) {
			throw new Exception('Get next id failure.');
			return false;
		}

		$prefix = $this->_getIdPrefix($id, $level);
		if (empty($prefix)) {
			$prefix = $this->prefix ? pow(10, $this->bits[0] -1) : 0;
		}

		if (++$prefix % pow(10, $this->bits[$level-1]) == 0) {
			throw new Jcan_Exception($id . ' get next id failure.');
			return false;
		}

		$e = array_sum(array_slice($this->bits, $level));
		return $prefix * pow(10, $e);
	}

	/**
	 * 取得第一个子ID
	 *
	 * @param int $id
	 * @param int $subLevel
	 * @return int
	 * @example
	 * 	$this->_getFirstSubId(101000000) => 101001000
	 * 	$this->_getFirstSubId(0) => 101000000
	 */
	protected function _getFirstSubId($id, $subLevel = null)
	{
		$level = $subLevel === null ? $this->getLevel($id) : $subLevel - 1;

		if ($level == 0) {
			return $this->_getStartId();
		}
		if ($level >= count($this->bits)) {
			throw new Jcan_Exception('ID: ' . $id . ' hasnot sub node.');
			return false;
		}

		$prefix = $this->_getIdPrefix($id, $level);
		$subPrefix = $prefix * pow(10, $this->bits[$level]) + 1;
		$subId = $subPrefix * pow(10, array_sum(array_slice($this->bits, $level+1)));
		return $subId;
	}

	/**
	 * 取得开始ID
	 *
	 * @return int
	 */
	protected function _getStartId()
	{
		$prefixNumber = $this->prefix ? pow(10, $this->bits[0] -1) : 0;
		$startId = ($prefixNumber + 1) * pow(10, array_sum(array_slice($this->bits, 1)));
		return $startId;
	}
}