<?php

/**
 * Base Observer class
 * Inspired from http://www.phppatterns.com/index.php/article/articleview/27/1/1/
 *
 * @see Observable
 */
abstract class Jcan_Observer {

	//要监视的对象
	public $observable;

	//构造函数
	public function __construct(Jcan_Observable &$observable) {
		$this->observable = $observable;

		//让自己添加进$subject的观察者列表
		$this->observable->addObserver($this);
	}

	//根据事件类型进行更新
	abstract public function update();
}