<?php

class Jcan_Mail
{
	/**
	 * 发送邮件
	 *
	 * @param string $to		收件人,格式可为: abc@163.com, zhiin <aa@163.com>, 家蚕 <bb@163.com>
	 * @param string $subject	邮件标题
	 * @param string $body		邮件正文
	 * @param string $from		发件人名称
	 * @param string $fromEmail	发件人邮箱
	 * @param string $isHtmlContent	是否为HTML信件
	 * @param string $charset	邮件编码
	 * @return boolean 成功返回true,失败返回false
	 */
	public static function send($to, $subject, $body, $from, $fromEmail, $isHtmlContent=true, $charset='UTF-8')
	{
		$eol = "\r\n";

		$to = ',' . $to;
		$to = preg_replace("/,([^<,]+)</ue", "', =?{$charset}?B?' . base64_encode(trim('\${1}')) . '?= <'", $to);
		$to = ltrim($to, ', ');

		$from = '=?' . $charset . '?B?' . base64_encode($from) . '?=';
		$subject = '=?' . $charset . '?B?' . base64_encode($subject) . '?=';

		$headers  = "MIME-Version: 1.0" . $eol ;
		$headers .= "From: $from <$fromEmail>" . $eol;

////////
$headers .= "To: " . $to . $eol;
$headers .= "Date: " . date("r") . $eol;
//$headers .= "Content-Transfer-Encoding: 8-bit" . $eol;
////////

		//These two to set reply address
		$headers .= "Return-Path: $from <$fromEmail>" . $eol;
		$headers .= "Reply-To: $from <$fromEmail>" . $eol;
		//These two to help avoid spam-filters
		$headers .= "Message-ID: <" . time() . "-" . $fromEmail . ">" . $eol;
		$headers .= "X-Mailer: PHP/" . phpversion() . $eol;

		if ($isHtmlContent) {
			$headers .= "Content-Type: text/html; charset={$charset}" . $eol;
			if (!function_exists('mb_convert_encoding')) {
				$body = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset={$charset}\" />\n" . $body;
			}
		} else {
			$headers .= "Content-Type: text/plain; charset={$charset}" . $eol;
		}

		if (function_exists('mb_convert_encoding')) {
			$body = mb_convert_encoding($body, 'HTML-ENTITIES', $charset);
		}
		// set any sendmail params, optional ...
		$sendmail_params  = '-f' . $fromEmail;

		return @mail($to, $subject, $body, $headers, $sendmail_params);
	}
}