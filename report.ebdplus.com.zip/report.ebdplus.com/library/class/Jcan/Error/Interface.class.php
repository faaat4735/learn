<?php

/**
 * 对三种不同错误类型的客户端的显示方式
 * 用户需要扩展该配置文件, 扩展类的名称必须为Error
 */
interface Jcan_Error_Interface
{
	/**
	 * E_ERROR 的错误回调
	 */
	public static function eErrorCallback();

	/**
	 * E_NOTICE 的错误回调
	 */
	public static function eNoticeCallback();

	/**
	 * E_WARNING 的错误回调
	 */
	public static function eWarningCallback();
}