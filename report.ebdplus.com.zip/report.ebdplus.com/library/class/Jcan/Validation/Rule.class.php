<?php

/**
 * 规则的基类
 * @see Jcan_Validation
 * @see Jcan_Validation_Validator
 *
 */
abstract class Jcan_Validation_Rule extends Jcan_Validation
{
	/**
	 * 构造方法
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * 父类的抽象方法
	 *
	 * @param mixed $value
	 * @return boolean
	 */
//	abstract function validate($value);
}

?>