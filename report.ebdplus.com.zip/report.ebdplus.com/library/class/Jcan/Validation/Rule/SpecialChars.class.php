<?php

class Jcan_Validation_Rule_SpecialChars extends Jcan_Validation_Rule
{
	public $specialChars = array
			(
			',', ';', '&', '"', '\'', "\n", "\r", ' ', '　', '*', '\\', '?', '(', ')',
			);
	public static $hasSpecialChars = '含有特殊字符';

	public function __construct($specialChars = null)
	{
		parent::__construct();
		if (!is_null($specialChars)) {
			$this->specialChars = $specialChars;
		}
	}

	public function validate($value)
	{
		$re = '![' . addslashes(implode('', $this->specialChars)) . ']!';
		if (preg_match($re, $value)) {
			$this->setError(self::$hasSpecialChars);
			return false;
		}

		$this->setError(false);
		return true;
	}
}

?>