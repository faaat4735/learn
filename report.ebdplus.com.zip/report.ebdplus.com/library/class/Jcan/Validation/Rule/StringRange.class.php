<?php

class Jcan_Validation_Rule_StringRange extends Jcan_Validation_Rule
{
	public $minValue;
	public $maxValue;

	public static $stringTooShort = '字符串长度太短';
	public static $stringTooLength = '字符串太长';

	public function __construct($minValue, $maxValue)
	{
		parent::__construct();
		$this->minValue = $minValue;
		$this->maxValue = $maxValue;
	}

	public function validate($value)
	{
		$len = Jcan_Data::strWidth($value);

		if ($len < $this->minValue) {
			$this->setError(self::$stringTooShort);
			return false;
		} else if ($this->maxValue != 0 && $len > $this->maxValue) {
			$this->setError(self::$stringTooLength);
			return false;
		} else {
			$this->setError(false);
			return true;
		}
	}
}

?>