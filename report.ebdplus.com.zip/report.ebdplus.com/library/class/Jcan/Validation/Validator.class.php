<?php

/**
 * 验证器的基类
 * @see Jcan_Validation
 * @see Jcan_Validation_Rule
 */
class Jcan_Validation_Validator extends Jcan_Validation
{
	//验证器内规则的集合
	public $rules = array();

	/**
	 * 构造函数
	 *
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * 为该验证器增加规则
	 *
	 * @param Jcan_Validation_Rule $rule
	 */
	public function addRule(Jcan_Validation_Rule &$rule)
	{
		$this->rules[] = $rule;
	}

	/**
	 * 引用另一验证器里的所有规则
	 *
	 * @param Jcan_Validation_Validator $validator
	 */
	public function addValidator(Jcan_Validation_Validator &$validator)
	{
		foreach ($validator->rules as &$rule) {
			$this->addRule($rule);
		}
	}

	/**
	 * 执行验证(实现父类的抽象接口)
	 *
	 * @param mixed $value
	 * @return boolean
	 */
	public function validate($value)
	{
		foreach ($this->rules as $rule) {
			if (!$rule->validate($value)) {
				$this->setError($rule->getError());
				return false;
			}
		}

		return true;
	}
}

?>