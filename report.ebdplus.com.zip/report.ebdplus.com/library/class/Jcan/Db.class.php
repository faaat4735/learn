<?php

class Jcan_Db extends PDO implements Jcan_Db_Interface
{
	public $foundRows;

	/**
	 * 构造函数, 参数比父类增加了$charset
	 */
	public function __construct($dsn, $user, $password, $charset = null, $options = array(PDO::ATTR_PERSISTENT => true))
	{
		try {
			//parent's constructor
			parent::__construct($dsn, $user, $password, $options);

			//PDO::ATTR_STATEMENT_CLASS: Set user-supplied statement class derived from PDOStatement.
			//Cannot be used with persistent PDO instances.
			//Requires array(string classname, array(mixed constructor_args)).
//			$this->setAttribute(PDO::ATTR_STATEMENT_CLASS, array('Jcan_Db_Statement', array()));

			//默认用异常处理错误
			$this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			//default fetch mode
			$this->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

			/////////
			$this->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);

			//set SQL charset
			if ($charset) $this->query("SET NAMES '{$charset}'");

		} catch (PDOException $e) {
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 扩展PDO::exec(), 增加异常处理, 并集成prepare形式输入
	 *
	 * @param string $sql
	 * @param ...
	 * @param int|bool 成功返回影响的行数,失败返回false
	 */
	public function exec($sql)
	{
		try {
			if (func_num_args() == 1) {
				return parent::exec($sql);
			}

			$rs = $this->prepare($sql);
			$params = func_get_args();
			$paramsCnt = count($params);
			for ($i=1; $i<$paramsCnt; $i++) {
				$rs->bindParam($i, $params[$i]);
			}
			$retval = $rs->execute();
			if ($retval === false) {
				return false;
			}
			return $rs->rowCount();

		} catch (PDOException $e) {
			$e = "SQL: " . $sql . "\n" . $e;
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 扩展PDO::query(), 增加异常处理, 并集成prepare形式输入
	 *
	 * @param string $sql
	 * @param const[optional] $fetchMode
	 * @param ...
	 * @return PDOStatement|bool 成功返回rs, 失败返回false
	 *
	 * @example Db::getInstance()->query("SELECT id, ?, ?", PDO::FETCH_ASSOC, $username, 123);
	 */
	public function query($sql, $fetchMode = null) {
		try {
			if (func_num_args() < 3) {
				if (empty($fetchMode)) {
					$fetchMode = PDO::FETCH_OBJ;
				}
				return parent::query($sql, $fetchMode);
			}

			$rs = $this->prepare($sql);
			if ($fetchMode) {
				$rs->setFetchMode($fetchMode);
			}
			$params = func_get_args();
			$paramsCnt = count($params);
			for ($i=2; $i<$paramsCnt; $i++) {
//				$rs->bindParam($i-1, $params[$i], self::getType($params[$i]));
				$rs->bindParam($i-1, $params[$i]);
			}
			$retval = $rs->execute();
			if ($retval === false) {
				return false;
			}
			return $rs;

		} catch (PDOException $e) {
			$e = "SQL: " . $sql . "\n" . $e;
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 返回被前面语句更新的、插入的或删除的行数。 {@see mysql中的row_count函数}
	 * 调用之前需要: $rs->closeCousor()
	 * @return int row_count()
	 */
	public function rowCount()
	{
		$rs = $this->query('SELECT row_count()');
		return $rs->fetchColumn();
	}

	/**
	 * 相当于mysql中的found_rows()
	 * SELECT SQL_CALC_FOUND_ROWS * FROM ...; SELECT FOUND_ROWS;
	 */
	public function foundRows()
	{
		$rs = $this->query('SELECT found_rows()');
		return $rs->fetchColumn();
	}

	/**
	 * 仅取得一个值(第一行第一列的值)
	 * @param string $sql
	 * @param ...
	 * @return mixed
	 *
	 * @example getOne("select count(*) from test")
	 * @example getOne("select count(*) from test where username=? and grade=?", $username, $grade);
	 */
	public function getOne($sql)
	{
		try {
			$rs = $this->prepare($sql);
			$params = func_get_args();
			$paramsCnt = count($params);
			for ($i=1; $i<$paramsCnt; $i++) {
				$rs->bindParam($i, $params[$i]);
			}
			$rs->execute();
			$value =$rs->fetchColumn();
			//比closeCursor占用更少的内存,而且用unset不需要$rs->closeCursor()了
			unset($rs);

			return $value;

		} catch (PDOException $e) {
			$e = "SQL: " . $sql . "\n" . $e;
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 仅取得第一行的值
	 * @example getRow("select * from test")
	 * @example getRow("select * from test", PDO::FETCH_LAZY)
	 * @example getRow("select * from test where id=? and user=?", null, 2, 'jcan')
	 */
	public function getRow($sql, $how = null)
	{
		try {
			$rs = $this->prepare($sql);

			$params = func_get_args();
			$paramsCnt = count($params);
			for ($i=2; $i<$paramsCnt; $i++) {
				$rs->bindParam($i-1, $params[$i]);
			}

			$rs->execute();

			if ($how) {
				$row = $rs->fetch($how);
			} else {
				$row = $rs->fetch();
			}
			unset($rs);

			return $row;

		} catch (PDOException $e) {
			$e = "SQL: " . $sql . "\n" . $e;
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 取得所有数据
	 * @example getAll("select * from test")
	 * @example getAll("select * from test", PDO::FETCH_UNIQUE, PDO::FETCH_NUM)
	 * @example getAll("select * from test", null, PDO::FETCH_OBJ)
	 * @example getAll("select * from test", PDO::FETCH_COLUMN, PDO::FETCH_OBJ)
	 * @example getAll("select * from test", PDO::FETCH_KEY_PAIR, PDO::FETCH_OBJ)
	 * @example getAll("select * from test", array(PDO::FETCH_COLUMN,1), PDO::FETCH_OBJ)
	 * @return array
	 */
	public function getAll($sql, $howGet = null, $howFetch = null)
	{
		try {
			$rs = $this->prepare($sql);

			$params = func_get_args();
			$paramsCnt = count($params);
			for ($i=3; $i<$paramsCnt; $i++) {
				$rs->bindParam($i-2, $params[$i]);
			}
			$rs->execute();

			if ($howFetch) {
				$rs->setFetchMode($howFetch);
			}

			if ($howGet) {
				//fetchAll ( [int $fetch_style [, int $column_index]] )
				if ($howGet == PDO::FETCH_COLUMN) {
					$all = $rs->fetchAll(PDO::FETCH_COLUMN, 0);
				} elseif (is_array($howGet)) {
					$all = $rs->fetchAll($howGet[0], $howGet[1]);
				} else {
					$all = $rs->fetchAll($howGet);
				}
			} else {
				$all = $rs->fetchAll();
			}

			//比closeCursor占用更少的内存,而且用unset不需要$rs->closeCursor()了
			//即使$rs的指针已经指向结尾了,但是$rs所占的内存并没有释放
			unset($rs);

			return $all;

		} catch (PDOException $e) {
			$e = "SQL: " . $sql . "\n" . $e;
			Jcan_Debug::logError($e, E_ERROR, __FILE__, __LINE__);
		}
	}

	/**
	 * 由于PDO本身问题,暂时不支持多个结果集
	 * @see Jcan_Db_Statement::printTable()
	 * @param String $sql
	 * @see Jcan_Db_Statement::printTable()
	 */
	public function printTable($sql)
	{
		$args = func_get_args();
		array_splice($args, 1, 0, array(null));
		$rs = call_user_func_array(array($this, 'query'), $args);

		$i = 1;
//		do {
			$all = $rs->fetchAll(PDO::FETCH_NUM);

			$cols = $rs->columnCount();

			echo "<table cellspacing='1' cellpadding='5' border='0' style='font-size:12px; background:#ccc; border:3px solid #fff'>\n";

			echo "<colgroup>";
			for ($j=0; $j<$cols; $j++) {
				if ($j%2) {
					echo "<col style='background:#fff' />";
				} else {
					echo "<col style='background:#f6f6f6' />";
				}
			}
			echo "</colgroup>\n";

			echo "<caption style='text-align:left; font-weight:bold'>Result set {$i}:</caption>\n";

			echo "<tr style='background:#666; color:#fff'>";
			for ($j=0; $j<$cols; $j++) {
				$colName = $rs->getColumnMeta($j);
				echo "<th>{$colName['name']}</th>";
			}
			echo "</tr>\n";

			if ($all) {
				foreach ($all as $row) {
					echo "<tr>";
					for ($j=0; $j<$cols; $j++) {
						$td = trim($row[$j]) == '' ? '&nbsp;' : $row[$j];
						echo "<td>{$td}</td>";
					}
					echo "</tr>\n";
				}
			} else {
				echo "<tr><td colspan='{$cols}'>No item.</td></tr>";
			}

			echo "</table>\n\n";

			$i++;
//		} while ($rs->nextRowset());
		$rs->closeCursor();
	}

	/**
	 * 根据变量类型得到PDO类型
	 *
	 * @param mixed $val
	 * @return const
	 */
	public static function getType($val)
	{
		switch (strtolower(gettype($val))) {
			case "boolean":
				$type = PDO::PARAM_BOOL;
				break;
			case "integer":
				$type = PDO::PARAM_INT;
				break;
			case "string":
				$type = PDO::PARAM_STR;
				break;
			case "null":
				$type = PDO::PARAM_NULL;
				break;
			default:
				$type = PDO::PARAM_STR;
				break;
		}
		return $type;
	}
//  [0] => object(stdClass)#6 (6) {
//    ["Field"] => string(11) "client_code"
//    ["Type"] => string(7) "char(8)"
//    ["Null"] => string(2) "NO"
//    ["Key"] => string(3) "PRI"
//    ["Default"] => string(0) ""
//    ["Extra"] => string(0) ""
//  }
//
	/**
	 * 包含如下信息: Field, Type, Null, Key, Default, Extra
	 *
	 * @param string $table
	 * @param string $field
	 * @return stdClass 不存在返回false
	 */
	public function getFieldInfo($table, $field)
	{
		$sql = "SHOW FIELDS FROM {$table} LIKE ?";
		$field = $this->getRow($sql, null, $field);
		return $field;
	}

	/**
	 * 包含如下信息的数组: Field, Type, Null, Key, Default, Extra
	 *
	 * @param string $table
	 * @return array
	 */
	public function getFieldsInfo($table)
	{
		$sql = "SHOW FIELDS FROM {$table}";
		return $this->getAll($sql);
	}

	/**
	 * 取得所有字段名
	 *
	 * @param string $table
	 * @return array
	 */
	public function getFields($table)
	{
		$sql = "SHOW FIELDS FROM {$table}";
		$arr = $this->getAll($sql, array(PDO::FETCH_COLUMN, 0));
		return $arr;
	}

	/**
	 * 把ENUM或者SET类型的字段转化为数组形式返回
	 *
	 * @param string $table
	 * @param string $field
	 * @return false|array
	 */
	public function getFieldValues($table, $field)
	{
		$fieldInfo = $this->getFieldInfo($table, $field);

   		if (!$fieldInfo || !preg_match('/^(set|enum)\((.+)\)$/i', $fieldInfo->Type, $tmp)) {
   			return false;
   		}

		$tmp[2] = substr(preg_replace('/([^,])\'\'/u', '${1}\\\'', ',' . $tmp[2]), 1);
		$arrStr = 'array(' . $tmp[2] . ')';
		$arr = eval('return ' . $arrStr . ';');
		return $arr;
	}

	/**
	 * @param string $field
	 * @param string|array $arr
	 * @param boolean $numeric
	 * @return string|false
	 * @example
	 * $this->buildInCondition('news_cid', array('news,biz,dynamic'), false)
	 * => news_cid IN ('news','biz','dynamic')
	 */
	public function buildInCondition($field, $arr, $numeric = true)
	{
		if (empty($arr)) return false;

		if (is_array($arr) && count($arr) == 1) {
			$arr = $arr[0];
		}

		if (!is_array($arr)) {
			if ($numeric) {
				return sprintf("{$field} = %d", $arr);
			} else {
				return sprintf("{$field} = %s", $this->quote($arr));
			}
		}

		if (!$numeric) {
			$arr = array_map(array($this, 'quote'), $arr);
		}
		return sprintf("{$field} IN (%s)", implode(', ', $arr));
	}

	/**
	 * 建立查询条件
	 *
	 * @param array $conditions
	 * @param string $prefix[optional]
	 * @param string $relation[optional]
	 * @return string
	 * @example
	 * 	$conditions = array(
	 * 			array(!empty($user), 'user_name=%s', $user),
	 * 			array(isset($state), 'user_state=%d', $state),
	 * 			);
	 *	self::buildQueryCondition($conditions, 'HAVING', 'OR');
	 *
	 * 	$conditions = array(!empty($user), 'user_name=%s', $user);
	 *	self::buildQueryCondition($conditions, 'HAVING', 'OR');
	 */
	public function buildQueryCondition($conditions, $prefix = 'WHERE', $relation = 'AND')
	{
		if (!is_array($conditions[0])) {
			$conditions = array($conditions);
		}

		$wheres = array();
		foreach ($conditions as $condition) {
			if ($condition[0]) {
				$_arr = array_slice($condition, 1);

				$_arr[0] = preg_replace('/(%\d*\$?s)/', '\'${1}\'', $_arr[0]);
				for ($i=1, $cnt=count($_arr); $i<$cnt; $i++) {
					$_arr[$i] = addslashes($_arr[$i]);
				}
				$wheres[] = call_user_func_array('sprintf', $_arr);
			}
		}

		$wheres = implode(" $relation ", $wheres);
		if (empty($prefix)) return $wheres;

		return empty($wheres) ? '' : ($prefix . ' ' . $wheres);
	}
}
