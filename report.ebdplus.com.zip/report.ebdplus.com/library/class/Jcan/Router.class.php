<?php

/**
 * 路由器
 */
class Jcan_Router
{
	//控制器将要处理的频道
	public $channel;
	//控制器将要处理的模块
	public $module;
	//控制器将要处理的动作
	public $action;

	//默认频道
	protected $_defaultChannel = 'Index';
	//默认模块
	protected $_defaultModule = 'Index';
	//默认动作
	protected $_defaultAction = 'index';

	/**
	 * 把控制器需要处理的模块与动作传入
	 *
	 * @param string $module
	 * @param string $action
	 */
	public function __construct($channel, $module, $action)
	{
		$this->channel = $channel ? $channel : $this->_defaultChannel;
		$this->module = $module ? $module : $this->_defaultModule;
		$this->action = $action ? $action : $this->_defaultAction;
	}

	/**
	 * Enter description here...
	 *
	 * @param Jcan_Tpl $tpl
	 * @return unknown
	 */
	public function dispatch($tpl)
	{
		//把真实的channel, module,action赋给$tpl对象
		$tpl->channel =& $this->channel;
                $tpl->module =& $this->module;
                $tpl->action =& $this->action;
                $tpl->view['channel'] =& $tpl->channel;
                $tpl->view['module'] =& $tpl->module;
                $tpl->view['action'] =& $tpl->action;

		$moduleClassName = $this->_getModuleClassName($this->module);

		//存在指定模块
		if (class_exists($moduleClassName)) {

			$oModule = new $moduleClassName($tpl);
			$actionMethodName = $this->_getActionMethodName($this->action);

			//存在指定模块的指定动作
			if (method_exists($oModule, $actionMethodName)) {

				$retval = $oModule->$actionMethodName();

				//存在指定模块的指定动作但执行失败
				if ($retval === false) {

					//指定的动作恰好是指定模块的默认动作
				 	if ($this->action == $this->_defaultAction) {

				 		//指定模块恰好为默认模块
				 		if ($this->module == $this->_defaultModule) {
				 			Jcan_Debug::logError("默认模块{$moduleClassName}默认动作{$actionMethodName}执行失败", E_ERROR, __FILE__, __LINE__);
							return false;
				 		}

						//指定模块不是默认模块
			 			return $this->_goDefaultModule($tpl);
				 	}

		 			//指定的动作不是指定模块的默认动作
					return $this->_goDefaultAction($tpl);
				}

				//存在指定模块的指定动作并成功执行
				return true;
			}

			//指定模块的指定动作不存在
			else {
				//指定模块指定的动作恰好为默认动作
				if ($this->action == $this->_defaultAction) {

					//指定模块恰好为默认模块
					if ($this->module == $this->_defaultModule) {
						Jcan_Debug::logError("默认模块{$moduleClassName}不存在默认动作{$actionMethodName}", E_ERROR, __FILE__, __LINE__);
						return false;
					}

					//指定模块不是默认模块
			 		return $this->_goDefaultModule($tpl);
				}

				//指定模块指定的动作不是默认动作
				return $this->_goDefaultAction($tpl);
			}
		}

		//指定模块不存在
		else {

			//指定模块恰好为默认模块
			if ($this->module == $this->_defaultModule) {
				Jcan_Debug::logError("不存在默认模块{$moduleClassName}", E_ERROR, __FILE__, __LINE__);
				return false;
			}

			//指定模块不是默认模块
	 		return $this->_goDefaultModule($tpl);
		}
	}

	/**
	 * 由其它模块转向默认的模块
	 *
	 * @param Jcan_Tpl $tpl
	 * @return bool
	 */
	protected function _goDefaultModule($tpl)
	{
		//尝试把模块设为默认模块的动作
		$this->action = $this->module;
		$this->action{0} = strtolower($this->action{0});
		$actionMethodName = $this->_getActionMethodName($this->action);

		//设默认模块
		$this->module = $this->_defaultModule;
		$moduleClassName = $this->_getModuleClassName($this->module);

		//存在默认模块
		if (class_exists($moduleClassName)) {

			$oModule = new $moduleClassName($tpl);

			//"尝试把模块设为默认模块的动作"
			if ($this->action != $this->_defaultAction && method_exists($oModule, $actionMethodName)) {
				$retval = $oModule->$actionMethodName();
				if ($retval !== false) {
					return true;
				}
			}

			//"尝试把模块设为默认模块的动作"失败
			$this->action = $this->_defaultAction;
			$actionMethodName = $this->_getActionMethodName($this->action);

			//默认模块存在默认动作
			if (method_exists($oModule, $actionMethodName)) {

				$retval = $oModule->$actionMethodName();

				//默认模块的默认动作执行失败
				if ($retval === false) {
					Jcan_Debug::logError("默认模块{$moduleClassName}默认动作{$actionMethodName}执行失败", E_ERROR, __FILE__, __LINE__);
					return false;
				}

				//默认模块的默认动作成功执行
				return true;
			}

			//默认模块不存在默认动作
			Jcan_Debug::logError("默认模块{$moduleClassName}不存在默认动作{$actionMethodName}", E_ERROR, __FILE__, __LINE__);
			return false;
		}

		//不存在默认模块
		Jcan_Debug::logError("不存在默认模块{$moduleClassName}", E_ERROR, __FILE__, __LINE__);
		return false;
	}

	/**
	 * 由其他动作转向默认动作
	 *
	 * @param Jcan_Tpl $tpl
	 * @return bool
	 */
	protected function _goDefaultAction($tpl)
	{
		$this->action = $this->_defaultAction;
		$actionMethodName = $this->_getActionMethodName($this->action);

		$moduleClassName = $this->_getModuleClassName($this->module);
		$oModule = new $moduleClassName($tpl);

		//指定模块存在默认动作
		if (method_exists($oModule, $actionMethodName)) {

			$retval = $oModule->$actionMethodName();

			//指定模块的默认动作返回失败
			if ($retval === false) {

 				//指定模块恰好为默认模块
 				if ($this->module == $this->_defaultModule) {
					Jcan_Debug::logError("默认模块{$moduleClassName}默认动作{$actionMethodName}执行失败", E_ERROR, __FILE__, __LINE__);
					return false;
 				}

 				//指定模块不是默认模块
 				return $this->_goDefaultModule($tpl);
			}

 			//指定模块的默认动作成功返回
 			return true;
		}

		//指定模块不存在默认动作
 		else {
 			//指定模块恰好为默认模块
 			if ($this->module == $this->_defaultModule) {
	 			Jcan_Debug::logError("默认模块{$moduleClassName}不存在默认动作{$actionMethodName}", E_ERROR, __FILE__, __LINE__);
				return false;
 			}

			//指定模块不是默认模块
			return $this->_goDefaultModule($tpl);
 		}
	}

	/**
	 * 取得指定模块的类名
	 *
	 * @param string $module
	 * @return string
	 */
	protected function _getModuleClassName($module)
	{
		$className = 'Jcan_Module_' . $this->channel . '_' . $module;
		return $className;
	}

	/**
	 * 取得指定动作的方法名
	 *
	 * @param string $action
	 * @return string
	 */
	protected function _getActionMethodName($action)
	{
		$actionName = $action . 'Action';
		return $actionName;
	}
}
