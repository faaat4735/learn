<?php

class Jcan_Data
{
	/**
	 * 把 text 转为 html 格式
	 *
	 * @param string &$data 要转换的字符串
	 * @param bool $entSpace 是否转化空格为&nbsp;
	 * @param string $startFunc 转换前调用该函数(一般用：null, trim, ltrim, rtrim)
	 * @return string 返回转换后的字符串
	 *
	 * @example Jcan_Data::textToHtml($data, true, null)
	 * @see Jcan_Data::htmlToText() & Jcan_Data::htmlToTextArea()
	 */
	public static function textToHtml(&$data, $entSpace = false, $startFunc = 'trim')
	{
		if (!empty($startFunc)) $data = $startFunc($data);
		$data = htmlspecialchars($data, ENT_QUOTES);
		if ($entSpace) $data = str_replace(' ', '&nbsp;', $data);
		$data = nl2br($data);

		return $data;
	}

	/**
	 * textToHtml的反函数
	 *
	 * @param string &$data
	 * @return string
	 *
	 * @see Jcan_Data::textToHtml() & Jcan_Data::htmlToTextArea()
	 */
	public static function htmlToText(&$data)
	{
		$data = str_replace(array('<br />', '&nbsp;'), array('', ' '), $data);
		$data = htmlspecialchars_decode($data, ENT_QUOTES);
		return $data;
	}

	/**
	 * 转换Input输入框的数据为单行安全数据
	 *
	 * @param string &$data
	 * @return string
	 */
	public static function toInputData(&$data)
	{
		$data = preg_replace('/\s+/u', ' ', $data);
		$data = htmlspecialchars($data, ENT_QUOTES);
		return $data;
	}

	/**
	 * 由HTML转化为textarea的格式, 仅<br />被替换掉
	 * 一般用在用户编辑文章时
	 *
	 * @param string $data
	 * @return string
	 *
	 * @see Jcan_Data::textToHtml() & Jcan_Data::htmlToText()
	 */
	public static function htmlToTextarea(&$data)
	{
		$data = str_replace('<br />', '', $data);
		return $data;
	}

	/**
	 * 完美的字符串截取函数, 考虑了unicode编码的情况(参数同: mb_strimwidth)
	 *
	 * @param string &$str
	 * @param int $start
	 * @param int $width
	 * @param string $trimmarker
	 * @param string $encoding
	 * @return string 返回截取后的字符串
	 */
	public static function truncate(&$str, $start, $width, $trimmarker = '..', $encoding = 'utf-8')
	{
		$str = html_entity_decode($str, ENT_QUOTES, $encoding);
		$str = mb_strimwidth($str, $start, $width, $trimmarker, $encoding);
		$str = htmlentities($str, ENT_QUOTES, $encoding);
		return $str;
	}

	/**
	 * 截取英文字符串
	 * From smarty_modifier_truncate()
	 *
	 * @param string $string
	 * @param int $length
	 * @param string $etc
	 * @param bool $break_words
	 * @param bool $middle
	 * @return string
	 */
	public static function truncateEn($string, $length = 80, $etc = '...', $break_words = false, $middle = false)
	{
		if ($length == 0) return '';

		if (strlen($string) > $length) {
			$length -= min($length, strlen($etc));

			if (!$break_words && !$middle) {
				$string = preg_replace('/\s+?(\S+)?$/', '', substr($string, 0, $length+1));
			}

			if(!$middle) {
				return substr($string, 0, $length) . $etc;
			}
			return substr($string, 0, $length/2) . $etc . substr($string, -$length/2);
		}

		return $string;
	}

	/**
	 * 取得字符串的长度(一个汉字占两位长度)
	 *
	 * @param string $str
	 * @param bool $entity 为真时把unicode代码转化为UTF-8再计算字符所占宽度
	 * @param string $encoding 字符编码
	 * @return int 字符串宽度
	 *
	 * @see self::strLen
	 */
	public static function strWidth($str, $entity = true, $encoding = 'utf-8')
	{
		if ($entity) {
			$str = html_entity_decode($str, ENT_QUOTES, $encoding);
		}
		return mb_strwidth($str, $encoding);
	}

	/**
	 * 取得字符串的长度(汉字与英文字母一样,占一位长度. 此函数与javascript里的str.length是等效的)
	 *
	 * @param string $str
	 * @param bool $entity 为真时把unicode代码转化为UTF-8再计算字符长度
	 * @param string $encoding 字符编码
	 * @return int 字符串长度(相当于字符个数)
	 *
	 * @see self::strWidth
	 */
	public static function strLen($str, $entity = true, $encoding = 'utf-8')
	{
		if ($entity) {
			$str = html_entity_decode($str, ENT_QUOTES, $encoding);
		}
		return mb_strlen($str, $encoding);
	}

	/**
	 * [SEO] title最大长度在65个左右(33个汉字)
	 * description最大长度一般在240个(120个汉字)左右
	 *
	 * @param string $str 要截取为description的字符串
	 * @param string $encoding 编码
	 * @param string $str 截取后的description
	 */
	public static function truncateDescription($str, $encoding = 'utf-8')
	{
		$str = html_entity_decode($str, ENT_QUOTES, $encoding);
		$str = trim(preg_replace('/[\s　]+/u', ' ', strip_tags($str)));
		$str = mb_strimwidth($str, 0, 240, '', $encoding);
		$str = htmlentities($str, ENT_QUOTES, $encoding);
		return $str;
	}

	public static function ltrim($str)
	{
		return preg_replace('/^[\s　]+/u', '', $str);
	}

	public static function rtrim($str)
	{
		return preg_replace('/[\s　]+$/u', '', $str);
	}

	public static function trim($str)
	{
		return preg_replace('/^[\s　]+|[\s　]+$/u', '', $str);
	}

	/**
	 * left replace
	 *
	 * @param string $str
	 * @param string|array $search
	 * @param boolean $strict
	 * @param boolean $once
	 * @return string
	 * @see self::rreplace
	 * @example
	 * 	self::rreplace('DDeeFFabc', array('dd', 'ee', 'ff'), false, false);
	 */
	public static function lreplace($str, $search, $strict = true, $once = true)
	{
		//modifiers
		$modfiers = 'u';
		if (!$strict) {
			$modfiers .= 'i';
		}

		//search regexp
		$search = (array)$search;
		$searchRegs = array();
		foreach ($search as $_s) {
			$searchRegs[] = preg_quote($_s, '/');
		}
		$searchRegs = '(' . implode('|', $searchRegs) . ')';
		if (!$once) {
			$searchRegs .= '+';
		}

		//replace
		$str = preg_replace('/^' . $searchRegs . '/' . $modfiers, '', $str);
		return $str;
	}

	/**
	 * right replace
	 *
	 * @param string $str
	 * @param string|array $search
	 * @param boolean $strict
	 * @param boolean $once
	 * @return string
	 * @see self::lreplace
	 * @example
	 * 	self::rreplace('/user-login.html', '.HTML', false);
	 */
	public static function rreplace($str, $search, $strict = true, $once = true)
	{
		//modifiers
		$modfiers = 'u';
		if (!$strict) {
			$modfiers .= 'i';
		}

		//search regexp
		$search = (array)$search;
		$searchRegs = array();
		foreach ($search as $_s) {
			$searchRegs[] = preg_quote($_s, '/');
		}
		$searchRegs = '(' . implode('|', $searchRegs) . ')';
		if (!$once) {
			$searchRegs .= '+';
		}

		//replace
		$str = preg_replace('/' . $searchRegs . '$/' . $modfiers, '', $str);
		return $str;
	}

	/**
	 * 返回符合规则的标签
	 *
	 * @param string $tagStr 标签字符串
	 * @param string $separator 连接字符串
	 * @param string $limit 最多支持的标签数
	 * @return array|string 如果未设置separator返回array,否则返回string
	 */
	public static function filterTags($tagStr, $separator = null, $limit = null)
	{
		//把所有可能的分隔符作为分隔符进行分隔
//		$tagStr = trim(preg_replace("/([\s,;\|\(\)]|，|；|　|｜|、)+/u", ",", $tagStr), ',');
		$tagStr = trim(preg_replace(
			array('/[\s　]+/u', '/ ?[,;\|，；｜] ?\s*/u', '/,+/u'),
			array(' ', ',', ','),
			$tagStr), ',');

		//解析成数组,并且去掉重复项
		$tags = Jcan_Array::unique(explode(',', $tagStr), false);
		//去掉不符合标签规则的项
		foreach ($tags as $k => $v) {
			//标签必须小于等于7个汉字宽度 且 不是全数字 且 必须是词汇
			if (Jcan_Data::strWidth($v) > 15 || preg_match('!^\d*$!', $v) || !preg_match(Jcan_RegExp::TAG, $v)) {
				unset($tags[$k]);
			}
		}

		//限制允许的标签个数
		if (!empty($limit)) {
			$tags = array_slice($tags, 0, $limit);
		}

		//如果设置separator则用此连接数组
		if (!empty($separator)) {
			return implode($separator, $tags);
		}

		//如果未设置separator,直接返回标签数组
		return $tags;
	}

	/**
	 * 根据文件名取得扩展名,并转换为小写
	 * @param string $fileName
	 * @return string string 小写的扩展名
	 */
	public static function getExtension($fileName)
	{
		return strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
	}

	/**
	 * explode的扩展
	 *
	 * @param string $separator
	 * @param string $str
	 * @param int $limit
	 * @return array
	 * @example
	 * 	explode(',', '') => array(0=>)
	 * 	self::explode(',', '') => array()
	 */
	public static function explode($separator, $str, $limit = null)
	{
		if (empty($str)) return array();

		if (!isset($limit)) {
			return explode($separator, $str);
		}
		return explode($separator, $str, $limit);
	}

	/**
	 * 把由指定分隔符分隔的字符串转化为数组集合
	 *
	 * @param string $str
	 * @param char $separator
	 * @return array
	 * @example self::getSet('assign, type , limit') => array('assign', 'type', 'limit')
	 */
	public static function getSet($str, $separator = ',')
	{
		if (empty($str)) return array();

		$separator = preg_quote($separator, '/');
		return preg_split("/\s*{$separator}\s*/u", $str);
	}

	/**
	 * 在指定分隔符分隔的字符串里寻找子串
	 *
	 * @param string $needle 要寻找的子串
	 * @param string $str 被分隔符分隔的字符串
	 * @param char $separator 分隔符
	 * @return bool
	 */
	public static function findInSet($needle, $str, $separator = ',')
	{
		return in_array($needle, self::getSet($str, $separator));
	}

	/**
	 * 与ucfirst相反,即第一个字母转化为小写,其它字母不变
	 *
	 * @param string $str
	 */
	public static function lcfirst($str)
	{
		if (isset($str{0})) {
			$str{0} = strtolower($str);
		}
		return $str;
	}

	public static function uriTitle($title, $default='index')
	{
		$title = strtolower(str_replace(array('-', ' ', '/', '\\'), '_', $title));
		if (empty($title)) $title = $default;

		return rawurlencode($title);
	}
}