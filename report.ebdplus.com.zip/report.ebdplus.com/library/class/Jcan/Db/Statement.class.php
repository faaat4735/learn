<?php

class Jcan_Db_Statement extends PDOStatement
{
	/**
	 * 父类无constructor
	 * 默认采取PDO::FETCH_OBJ方式取数据
	 */
	protected function __construct()
	{
		//默认采取PDO::FETCH_OBJ方式取数据
		$this->setFetchMode(PDO::FETCH_OBJ);
	}

	/**
	 * 继承父类 自动处理了异常
	 *
	 * @return unknown
	 */
	public function execute()
	{
		try {
			return parent::execute();
		} catch (PDOException $e) {
			//如果是重复则返回假
			if ($e->getCode() != 23000) {
				$e = "SQL: " . $this->queryString . "\n" . $e;
				Jcan_Debug::logError($e, E_ERROR);
			} else {
				return false;
			}
		}
	}

	/**
	 * Bind array parameter
	 *
	 * @example bindArray( array('id'=>null, 'text'=>$text) );
	 * @example bindArray( array(null, $text) );
	 * @param Array $data
	 */
	public function bindArray($data)
	{
		foreach($data as $key => $val) {
			$type = Jcan_Db::getType($val);

			if (is_numeric($key)) {
				$this->bindParam($key+1, $data[$key], $type);
			} else {
				$this->bindParam(':' . $key, $data[$key], $type);
			}
		}
	}

	/**
	 * 调试用
	 * 由于PDO本身问题,暂时不支持多个结果集
	 * @see Jcan_Db::printTable(sql)
	 */
	public function printTable()
	{
		$i = 1;
//		do {
			$rowset = $this->fetchAll(PDO::FETCH_NUM);

			if ($rowset) {
				$cols = $this->columnCount();

				echo "<table cellspacing='1' cellpadding='5' border='0' style='font-size:12px; background:#ccc; border:3px solid #fff'>\n";

				echo "<colgroup>";
				for ($j=0; $j<$cols; $j++) {
					if ($j%2) {
						echo "<col style='background:#fff' />";
					} else {
						echo "<col style='background:#eef3ff' />";
					}
				}
				echo "</colgroup>\n";

				echo "<caption>Result set {$i}:</caption>\n";

				echo "<tr>";
				for ($j=0; $j<$cols; $j++) {
					$colName = $this->getColumnMeta($j);
					echo "<th>{$colName['name']}</th>";
				}
				echo "</tr>\n";

				foreach ($rowset as $row) {
					echo "<tr>";
					for ($j=0; $j<$cols; $j++) {
						$td = trim($row[$j]) == '' ? '&nbsp;' : $row[$j];
						echo "<td>{$td}</td>";
					}
					echo "</tr>\n";
				}

				echo "</table>\n\n";
			}
			$i++;
//		} while ($this->nextRowset());
		$this->closeCursor();
	}
}
