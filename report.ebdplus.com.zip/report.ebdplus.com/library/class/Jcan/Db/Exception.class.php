<?php

class Jcan_Db_Exception extends Jcan_Exception
{}
