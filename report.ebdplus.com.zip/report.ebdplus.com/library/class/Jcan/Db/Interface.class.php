<?php

interface Jcan_Db_Interface
{
	/**
	 * 扩展PDO::exec(), 增加异常处理, 并集成prepare形式输入
	 *
	 * @param string $sql
	 * @param ...
	 * @param int|bool 成功返回影响的行数,失败返回false
	 */
	public function exec($sql);

	/**
	 * 扩展PDO::query(), 增加异常处理, 并集成prepare形式输入
	 *
	 * @param string $sql
	 * @param const[optional] $fetchMode
	 * @param ...
	 * @return PDOStatement|bool 成功返回rs, 失败返回false
	 *
	 * @example Db::getInstance()->query("SELECT id, ?, ?", PDO::FETCH_ASSOC, $username, 123);
	 */
	public function query($sql, $fetchMode = null);

	/**
	 * 仅取得一个值(第一行第一列的值)
	 * @param string $sql
	 * @param ...
	 * @return mixed
	 *
	 * @example getOne("select count(*) from test")
	 * @example getOne("select count(*) from test where username=? and grade=?", $username, $grade);
	 */
	public function getOne($sql);

	/**
	 * 仅取得第一行的值
	 * @example getRow("select * from test")
	 * @example getRow("select * from test", PDO::FETCH_LAZY)
	 * @example getRow("select * from test where id=? and user=?", null, 2, 'jcan')
	 */
	public function getRow($sql, $how = null);

	/**
	 * 取得所有数据
	 * @example getAll("select * from test")
	 * @example getAll("select * from test", PDO::FETCH_UNIQUE, PDO::FETCH_NUM)
	 * @example getAll("select * from test", null, PDO::FETCH_OBJ)
	 * @example getAll("select * from test", PDO::FETCH_COLUMN, PDO::FETCH_OBJ)
	 * @example getAll("select * from test", array(PDO::FETCH_COLUMN,1), PDO::FETCH_OBJ)
	 * @return array
	 */
	public function getAll($sql, $howGet = null, $howFetch = null);

	/**
	 * 返回被前面语句更新的、插入的或删除的行数。 {@see mysql中的row_count函数}
	 * 调用之前需要: $rs->closeCousor()
	 * @return int row_count()
	 */
	public function rowCount();

	/**
	 * 相当于mysql中的found_rows()
	 * SELECT SQL_CALC_FOUND_ROWS * FROM ...; SELECT FOUND_ROWS;
	 */
	public function foundRows();

	/**
	 * 根据变量类型得到PDO类型
	 *
	 * @param mixed $val
	 * @return const
	 */
	public static function getType($val);

	/**
	 * 包含如下信息: Field, Type, Null, Key, Default, Extra
	 *
	 * @param string $table
	 * @param string $field
	 * @return stdClass 不存在返回false
	 */
	public function getFieldInfo($table, $field);

	/**
	 * 包含如下信息的数组: Field, Type, Null, Key, Default, Extra
	 *
	 * @param string $table
	 * @return array
	 */
	public function getFieldsInfo($table);

	/**
	 * 把ENUM或者SET类型的字段转化为数组形式返回
	 *
	 * @param string $table
	 * @param string $field
	 * @return false|array
	 */
	public function getFieldValues($table, $field);

	/**
	 * 取得所有字段名
	 *
	 * @param string $table
	 * @return array
	 */
	public function getFields($table);

	/**
	 * @param string $field
	 * @param string|array $arr
	 * @param boolean $numeric
	 * @return string|false
	 * @example
	 * $this->buildInCondition('news_cid', array('news,biz,dynamic'), false)
	 * => news_cid IN ('news','biz','dynamic')
	 */
	public function buildInCondition($field, $arr, $numeric = true);

	/**
	 * 建立查询条件
	 *
	 * @param array $conditions
	 * @param string $prefix[optional]
	 * @param string $relation[optional]
	 * @return string
	 * @example
	 * 	$conditions = array(
	 * 			array(!empty($user), 'user_name=%s', $user),
	 * 			array(isset($state), 'user_state=%d', $state),
	 * 			);
	 *	self::buildQueryCondition($conditions, 'HAVING', 'OR');
	 *
	 * 	$conditions = array(!empty($user), 'user_name=%s', $user);
	 *	self::buildQueryCondition($conditions, 'HAVING', 'OR');
	 */
	public function buildQueryCondition($conditions, $prefix = 'WHERE', $relation = 'AND');


	/**
	 * 由于PDO本身问题,暂时不支持多个结果集
	 * @see Jcan_Db_Statement::printTable()
	 * @param String $sql
	 * @see Jcan_Db_Statement::printTable()
	 * @example $this->printTable('SELECT * FROM t_users WHERE user_name = ?', 'jcan')
	 */
	public function printTable($sql);
}