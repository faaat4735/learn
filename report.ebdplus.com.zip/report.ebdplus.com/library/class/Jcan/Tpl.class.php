<?php

/**
 * @author Jcan
 * @version 1.1
 * @desc smarty的扩展类
 */

require_once SMARTY_DIR . 'Smarty.class.php';

class Jcan_Tpl extends Smarty
{
	//view [channel, module, action, title, keywords, description, ......]
	public $view;

	public $channel;
	public $module;
	public $action;

	public function __construct()
	{
		parent::Smarty();

		//设置模板目录
		$this->template_dir	= TPL_DIR . 'templates';
		$this->compile_dir	= TPL_DIR . 'templates_c';
		$this->config_dir	= TPL_DIR . 'configs';
		$this->cache_dir	= TPL_DIR . 'cache';

		$this->plugins_dir = array(SMARTY_DIR . 'plugins', TPL_DIR . 'plugins', LIB_DIR . 'plugins');

		//设置模板是否可创建子目录
		$this->use_sub_dirs = true;

		//设置缓存时间
		$this->cache_lifetime = 7200;

		//设置左边界符
		$this->left_delimiter = '{';

		//设置右边界符
		$this->right_delimiter = '}';

		//是否强制编译
		$this->force_compile = false;

		//是否编译检查
		$this->compile_check = true;

		//设置缓存方式(0,1,2)
		$this->caching = false;

		//query string调试 (SMARTY_DEBUG)
		$this->debugging_ctrl = DEBUG_MODE ? 'URL' : 'NONE';

		//注册动态块
		$this->register_block('nocache', array($this, 'smarty_block_nocache'), false);

		//assign $view by ref
		$this->assign_by_ref('view', $this->view);

		//security
		if (defined('SMARTY_SECURITY') && SMARTY_SECURITY) {
			$this->security = true;
			$this->security_settings['IF_FUNCS'] = array(
								'array', 'list',
								'isset', 'empty',
								'count', 'sizeof',
								'in_array', 'is_array',
								'true', 'false', 'null',
								'intval', 'is_numeric', 'ucfirst',
								);
			$this->security_settings['MODIFIER_FUNCS'] = array(
								'count', 'htmlspecialchars', 'htmlspecialchars_decode',
								'rawurlencode', 'rawurldecode', 'urlencode', 'urldecode',
								'nl2br', 'intval',
								'json_encode', 'json_decode',
								'strtoupper', 'strtolower', 'ucfirst', 'ucword',
								'addslashes',
								);
			$this->security_settings['ALLOW_CONSTANTS'] = true;
		}
	}

	/**
	 * 动态加载块
	 */
	public function smarty_block_nocache($params, $content, &$smarty, &$repeat)
	{
		return $content;
	}

	/**
	 * smarty错误处理
	 * @see Jcan_Debug::logError
	 */
	public function triggerError($errorInfo, $errorType = E_ERROR, $errorFile = null, $errorLine = null)
	{
		Jcan_Debug::logError($errorInfo, $errorType, $errorFile, $errorLine);
	}


	/**
	 * 确少参数提示
	 *
	 * @param string $param
	 */
	public function missingParam($paramter, $func = null)
	{
		if (!isset($func)) {
			$func = Jcan_Debug::caller('function');
		}
		$_arr = $this->_parsePluginFunctionName($func);
		if ($_arr) {
			$error = "<p style='border:1px dotted #f00; padding:10px'><strong>{$_arr[1]}</strong> [{$_arr[0]} plugin]: missing <strong><em>{$paramter}</em></strong> parameter</p>";
			echo $error;
		}

		return null;
	}

	public function ttl($time)
	{
		$this->caching = 2;
		$this->cache_lifetime = $time;
	}

	/**
	 * 解析smarty_block_strip_tag 为 array('block', 'strip_tag')形式
	 *
	 * @param string $func
	 * @return array
	 */
	protected function _parsePluginFunctionName($func)
	{
		$_arr = explode('_', $func, 3);
		if (count($_arr) != 3 && $_arr[0] != 'smarty') {
			return false;
		}

		return array($_arr[1], $_arr[2]);
	}

	/**
	 * test to see if valid cache exists for this template
	 *
	 * @param string $tpl_file name of template file
	 * @param string $cache_id
	 * @param string $compile_id
	 * @return bool results of {@link is_cached()}
	 */
	public function hasCached($tpl_file, $cache_id = null, $compile_id = null)
	{
		if (!$this->caching) {
			$_caching = $this->caching;
			$this->caching = 2;
		}

		$_isCached = $this->is_cached($tpl_file, $cache_id, $compile_id);

		if (isset($_caching)) {
			$this->caching = $_caching;
		}
		return $_isCached;
	}

	/**
	 * 循环block
	 *
	 * @param array $params
	 * @param string $content
	 * @param bool $repeat
	 * @param array $data
	 * @return mixed
	 */
	public function loopBlock(&$params, &$content, &$repeat, &$data, $func = null)
	{
		//indicate loop
		if (!Jcan_Filter::ref($params['assign'], $assign)) {
			if (!$func) {
				$func = Jcan_Debug::caller('function');
			}
			$repeat = false;
			return $this->missingParam('assign', $func);
		}

		$rows =& $data[count($data) - 1];
		if (!is_array($rows)) {
			$rows = array();
		}

		if ($row = current($rows)) {
			$this->assign_by_ref($assign, $row);
			$repeat = true;
			next($rows);
		}
		//release memory
		else {
			array_pop($data);
			$repeat = false;
		}

		//return
		if (isset($params['capture'])) {
			//clear _tpl_vars[$params['capture']]
			if (!isset($content)) {
				$this->_tpl_vars[$params['capture']] = '';
			}
			else {
				$this->_tpl_vars[$params['capture']] .= $content;
			}
		}
		else return $content;
	}
}

