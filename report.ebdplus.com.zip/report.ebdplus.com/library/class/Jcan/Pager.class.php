<?php

class Jcan_Pager
{
	//prev page string
	public static $prev = '<a href="%s" title="Previous Page">&laquo;Prev</a>';
	//next page string
	public static $next = '<a href="%s" title="Next Page">Next&raquo;</a>';

	//记录数
	protected $_rowCnt;
	//用于URI标示页码
	protected $_no;
	//limitCnt
	protected $_limitCnt;
	//limitStart
	protected $_limitStart;
	//当前页码
	protected $_currentPage;

	/**
	 * 构造函数
	 *
	 * @param int $rowCnt 总记录数
	 * @param string $no 用于URI标示页码
	 */
	public function __construct($limitCnt=24, $no='page')
	{
		$this->_limitCnt = $limitCnt;
		$this->_no = $no;

		$this->_initCurrentPage();
		$this->_limitStart = ($this->_currentPage - 1) * $limitCnt;
	}

	/**
	 * 取得当前页码
	 */
	protected function _initCurrentPage()
	{
		if (empty($_REQUEST[$this->_no])) {
			$this->_currentPage = 1;
			return;
		}

		$pageNo = intval($_REQUEST[$this->_no]);
		if ($pageNo < 1) {
			$this->_currentPage = 1;
		} else {
			$this->_currentPage = $pageNo;
		}
	}

	public function getLimitStart()
	{
		return $this->_limitStart;
	}

	public function getLimitCnt()
	{
		return $this->_limitCnt;
	}

	public function split($rowCnt, $rule = '?', $className = 'pager')
	{
		//页码溢出
		$pageCnt = ceil($rowCnt / $this->_limitCnt);
		if ($pageCnt == 0) $pageCnt = 1;
		if ($this->_currentPage > $pageCnt) {
			$firstPage = $this->_getUri(1, $rule);
			Jcan_Http::redirect($firstPage);
		}

		//仅一页
		if ($pageCnt == 1) {
			return '';
		}

		//config
		$minPageCnt = 3;
		$maxPageCnt = 1;
		$leftPageCnt = 2;
		$rightPageCnt = 3;

		//tmp variables
		$showPrev = true;
		$showNext = true;
		$showLeftDot = true;
		$showRightDot = true;

		if ($this->_currentPage == 1) {
			$showPrev = false;
		}
		if ($this->_currentPage == $pageCnt) {
			$showNext = false;
		}
		if ($this->_currentPage - 1 <= $minPageCnt + $leftPageCnt + 1) {
			$showLeftDot = false;
		}
		if ($rightPageCnt + $maxPageCnt + 1 >= $pageCnt - $this->_currentPage) {
			$showRightDot = false;
		}

		//build split string
		$retval = "<table class=\"{$className}\"><tr>";
		if ($showPrev) {
			$retval .= sprintf("<td class=\"prev\">" . self::$prev . "</td>", $this->_getUri($this->_currentPage-1, $rule));
		}

		if (!$showLeftDot) {
			for ($i=1; $i<$this->_currentPage; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($i, $rule), $i);
			}
		} else {
			for ($i=0; $i<$minPageCnt; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($i+1, $rule), $i+1);
			}
			$retval .= '<td class="dots"><span>...</span></td>';
			for ($i=$this->_currentPage-$leftPageCnt; $i<$this->_currentPage; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($i, $rule), $i);
			}
		}

		$retval .= sprintf('<td class="current"><span>%d</span></td>', $this->_currentPage);

		if (!$showRightDot) {
			for ($i=$this->_currentPage+1; $i<=$pageCnt; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($i, $rule), $i);
			}
		} else {
			for ($i=0; $i<$rightPageCnt; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($this->_currentPage+$i+1, $rule), $this->_currentPage+$i+1);
			}
			$retval .= '<td class="dots"><span>...</span></td>';
			for ($i=$pageCnt-$maxPageCnt+1; $i<=$pageCnt; $i++) {
				$retval .= sprintf('<td><a href="%s">%d</a></td>', $this->_getUri($i, $rule), $i);
			}
		}

		if ($showNext) {
			$retval .= sprintf("<td class=\"next\">" . self::$next . "</td>", $this->_getUri($this->_currentPage+1, $rule));
		}
		$retval .= '</tr></table>';
		return $retval;
	}


	/**
	 * 得到某页的链接
	 *
	 * $rule可为下面中的一种
	 * -page-no
	 * /page-no
	 * /page/no
	 * /page/no.html
	 * --page-no.phtml
	 * ?page=
	 * ?
	 */
	protected function _getUri($pageNo, $rule = '?')
	{
		//declare $requestUri
		$requestUri = str_replace(array('&amp;', '&'), array('&', '&amp;'), $_SERVER['REQUEST_URI']);

		//传统模式(即无URLWrite模式)
		if (strpos($rule, '?') === 0) {
			//declare $pagePair
			$pagePair = "{$this->_no}={$pageNo}";

			//URI中存在页码
			if (preg_match("!(\?|;|&){$this->_no}=!u", $requestUri)) {
				$uri = preg_replace("!(\?|;|&){$this->_no}=[^&]*!u", "\${1}{$pagePair}", $requestUri);
				return $uri;
			}

			//页面中不存在页面
			if (strpos($requestUri, '?') === false) {
				$uri = $requestUri . '?' . $pagePair;
			} else {
				$uri = $requestUri . '&amp;' . $pagePair;
			}
			return $uri;
		}


		//RegExp
		$re = preg_quote(str_replace('page', $this->_no, $rule), '!');
		$re = '!(' . str_replace('no', ')[a-z\d]*(', $re) . ')!ui';

		//URI中存在页码
		if (preg_match($re, $requestUri)) {
			$uri = preg_replace($re, "\${1}{$pageNo}\${2}", $requestUri);
			return $uri;
		}

		//URI中不存在页码
		$paths = explode('?', $requestUri, 2);
		$requestUri = $paths[0];
		$left = preg_replace('!page.+$!u', '', $rule);
		$leftRe = preg_quote($left, '!');
		$uri = preg_replace("!({$leftRe})?(\.[a-zA-Z]+)?$!u", '', $requestUri);

		$pagePair = str_replace(array('page', 'no'), array($this->_no, $pageNo), $rule);
		$uri = $uri . $pagePair;

		if (!empty($paths[1])) {
			$uri .= '?' . $paths[1];
		}
		return $uri;
	}
}