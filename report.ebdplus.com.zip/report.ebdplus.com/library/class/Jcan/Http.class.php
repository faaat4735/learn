<?php

/**
 * @todo
 * 	header( "HTTP/1.1 301 Moved Permanently");
 * 	header( "Location: http://www.xxx.com");
 */
class Jcan_Http
{
	/**
	 * 发送header status, from Zend Framework
	 *
	 * @param string $status
	 * @example
	 *  self::headerStatus('404 Not Found')
	 *  self::headerStatus('301 Moved Permanently')
	 */
	public static function headerStatus($status)
	{
		// 'cgi', 'cgi-fcgi'
		if (substr(php_sapi_name(), 0, 3) == 'cgi') header('Status: '.$status, true);
		else header($_SERVER['SERVER_PROTOCOL'] . ' ' . $status);
	}

	/**
	 * 取得当前所用的协议(HTTP或者HTTPS)
	 */
	public static function getProtocol()
	{
		if (isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ) {
			$protocol = 'https';
		} else {
			$protocol = 'http';
		}
		return $protocol;
	}

	/**
	 * 取得带协议的HTTP_HOST
	 *
	 * @return string
	 */
	public static function getProtocolHost()
	{
		return self::getProtocol() . '://' . $_SERVER['HTTP_HOST'];
	}

	/**
	 * 取得baseUri
	 * 注意: 得到的是未经URL重写过的真正的脚本网址, 不包括?后面的request部分
	 * @example RewriteRule ^User/login$ https://www.xxx.com/index.php?id=3
	 * 	 -> 得到的是: https://www.xxx.com/index.php
	 */
	public static function getBaseUri()
	{
		return self::getProtocolHost() . $_SERVER['PHP_SELF'];
	}

	/**
	 * 取得当前网址所有部分(如果设置$anchor,则连锚点一起取回)
	 * 注意: 取回的网址未经urldecode
	 * @example
	 * 	网址: https://jcan.lc/Buy/dogs/tag/测试"'/%E6%B4%BB%E6%B3%BC/?id=3&xx=%E6%B4%BB%E6%B3%BC#headss
	 * 	用getFullUri()取回将得到:
	 * 	https://jcan.lc/Buy/dogs/tag/%E6%B5%8B%E8%AF%95"'/%E6%B4%BB%E6%B3%BC/?id=3&xx=%E6%B4%BB%E6%B3%BC
	 */
	public static function getFullUri($anchor = '')
	{
		$fullUri = self::getProtocolHost() . $_SERVER["REQUEST_URI"];
		if (!empty($anchor)) {
			$fullUri .= '#' . $anchor;
		}
		return $fullUri;
	}


	/**
	 * URL跳转(如果头没有被送出用header转向, 否则用js转向
	 * 此处为页面URL跳转,如果需要模块跳转请用Jcan_Module->redirect($module, $action)
	 *
	 * @param string $url 要跳转的URL
	 * @param int[optional=0] 延迟的时间,单位"秒"而不是"毫秒"(如果不设或者设为0表示没有延迟)
	 */
	public static function redirect($url, $delay = 0)
	{
		if ($url == 'back' || $url == -1) {
			$url = Jcan_Http::getReferer();
		}

		if (empty($delay)) {
			if (!headers_sent()) {
				header('Location: ' . $url);
				exit;
			} else {
				Jcan_Js::redirect('redirect', $url);
			}
		} else {
			if (!headers_sent()) {
				header("refresh:{$delay}; url={$url}");
			} else {
				$delay = intval($delay) * 1000;
				printf('<script type="text/javascript">setTimeout(function(){window.location="%s";}, %u); </script>', $url, $delay);
			}
		}
	}

	/**
	 * 取得$_SERVER['HTTP_REFERER'],如果不存在则用默认URL, 优先顺序是: $_REQUEST['referer'] -> $_SERVER['HTTP_REFERER'] -> $defaultUrl
	 * @param string $defaultUrl
	 * @param boolean $local 是否要排除非本域名下的来源地址
	 */
	public static function getReferer($defaultUrl = ROOT_PATH, $local = true)
	{
		$referer = !empty($_REQUEST['referer'])
				?  $_REQUEST['referer']
				: (!empty($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : $defaultUrl);

		if ($local) {
			$arr = parse_url($referer);
			if (!empty($arr['host'])) {
				$fromHost = strtolower($arr['host']);
				$host = strtolower($_SERVER['HTTP_HOST']);

				$arr1 = array_slice(explode('.', $fromHost), -2);
				$arr2 = array_slice(explode('.', $host), -2);

				if ($arr1 != $arr2) {
					$referer = $defaultUrl;
				}
			}
		}

		return $referer;
	}

	/**
	 * 转向Referer页
	 *
	 * @param string $defaultUrl
	 * @param string $local
	 */
	public static function redirectReferer($defaultUrl = ROOT_PATH, $local = true)
	{
		$referer = self::getReferer($defaultUrl, $local);
		self::redirect($referer);
	}

	/**
	 * 浏览器端cache设置
	 *
	 * cache limiter:
	 * 1. nocache 禁止客户端和中间路由器缓存本页
	 * 2. public 允许客户端和中间路由器缓存本页
	 * 3. private 仅允许客户端缓存本页，不允许中间路由器缓存本页
	 * 4. 另外还有一种特殊的模式：private_no_expire。
	 *    由于某些浏览器（例如Mozilla）在private模式下，不能正确处理expire header，
	 *    此时应该使用private_no_expire模式，这样expire header将不会被发送到客户端。
	 *
	 * @param int[optional] $lifeTime (需要缓存的时间, 0表示不缓存)
	 */
	public static function cache($lifeTime = 3600)
	{
		if ($lifeTime) {
			header("Cache-Control: cache"); // HTTP/1.1
			header("Pragma: cache"); // HTTP/1.0
			header("Date: " . gmdate("D, j M Y H:i:s") . ' GMT');
			header("Expires: " . gmdate("D, j M Y H:i:s", time()+$lifeTime) . " GMT");
			//header("Content-Type: text/html");
		} else {
			header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
			header("Pragma: no-cache"); // HTTP/1.0
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
			header("Last-Modified: " . gmdate("D, j M Y H:i:s") . " GMT"); // always modified
		}
	}

	/**
	 * 限制IP操作时最好用此函数
	 * 因为可以得到真实的用户IP或者代理IP, 不可伪造！
	 * @return string IP
	 */
	public static function getIp()
	{
		return $_SERVER['REMOTE_ADDR'];
	}

	/**
	 * sprintf('%u', ip2long('xxx.xxx.xxx.xxx'))
	 * 得到的一个可能值为十位整数: 4294967295
	 * @param string $ip [optioal]
	 * @return int loingIp
	 */
	public static function getLongIp($ip = null)
	{
		if (empty($ip)) {
			$ip = self::getIp();
		}
		return sprintf('%u', ip2long($ip));
	}

	/**
	 * 载入操作日记时最好用此函数
	 * HTTP_CLIENT_IP HTTP_X_FORWARD_FOR 都可伪造, 而REMOTE_ADDR不可伪造
	 * @return string ipList 格式为: REMOTE_ADDR; HTTP_X_FORWARD_FOR; HTTP_CLIENT_IP
	 */
	public static function getIpList()
	{
		$ips = array();

		$ips[] = $_SERVER['REMOTE_ADDR'];
		$ips[] = empty($_SERVER['HTTP_X_FORWARDED_FOR']) ? '' : $_SERVER['HTTP_X_FORWARDED_FOR'];
		$ips[] = empty($_SERVER['HTTP_CLIENT_IP']) ? '' : $_SERVER['HTTP_CLIENT_IP'];

		return rtrim(implode(';', $ips), ';');
	}

	/**
	 * 判断是否为ajax请求
	 *
	 * @return bool
	 */
	public static function isAjax()
	{
		return isset($_SERVER['HTTP_X_REQUESTED_WITH'])
			&& $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'
			|| !empty($_REQUEST['__ajax']);
	}

	/**
	 * 判断是否为POST请求
	 *
	 * @return bool
	 */
	public static function isPost()
	{
		return isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'POST';
	}

	/**
	 * 判断是否被确定
	 *
	 * @return bool
	 */
	public static function isVerified()
	{
		return isset($_POST['__confirm']);
	}

	/**
	 * 取得浏览器信息的hash
	 *
	 * @param bool $useIp
	 * @return string
	 */
	public static function getBrowserHash($useIp = false)
	{
		$str = '';
		$str .= isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

		// AJAX => [HTTP_ACCEPT] => application/json, text/javascript, */*
		// HTML => text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
		//$str .= isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : '';

		$str .= isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
		$str .= isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
		$str .= isset($_SERVER['HTTP_ACCEPT_CHARSET']) ? $_SERVER['HTTP_ACCEPT_CHARSET'] : '';

		if ($useIp) {
			$str .= self::getIpList();
		}
		return md5($str);
	}

	/**
	 * 给URL增加query
	 *
	 * @param string $query
	 * @param string $url
	 * @return string
	 * @example
	 * 	self::addQuery('page=2&user=jcan%20zhong', 'https://jcan.cn/index.php/module/user/?x=1&y=2#top');
	 * 	=> https://jcan.cn/index.php/module/user/?x=1&y=2&page=2&user=jcan%20zhong#top
	 */
	public static function addQuery($query, $url = null)
	{
		if ($url === null) {
			$url = $_SERVER['REQUEST_URI'];
		}
		$parts = parse_url($url);

		$str = '';
		if (isset($parts['scheme'])) {
			$str .= $parts['scheme'] . '://' . $parts['host'];
		}
		if (isset($parts['path'])) {
			$str .= $parts['path'];
		}
		if (isset($parts['query'])) {
			$str .= '?' . $parts['query'];
		}
		$str .= (isset($parts['query']) ? '&' : '?') . $query;
		if (isset($parts['fragment']) && strpos($query, '#') === false) {
			$str .= '#' . $parts['fragment'];
		}
		return $str;
	}

	/**
	 * 给URI增加替换URL
	 *
	 * @param string|array $query
	 * @param string|null $url
	 * @return string
	 */
	public static function replaceQuery($query, $url = null)
	{
		if ($url === null) {
			$url = $_SERVER['REQUEST_URI'];
		}
		$parts = parse_url($url);

		$str = '';
		if (isset($parts['scheme'])) {
			$str .= $parts['scheme'] . '://' . $parts['host'];
		}
		if (isset($parts['path'])) {
			$str .= $parts['path'];
		}

		$queryArr = array();
		if (isset($parts['query'])) {
			parse_str($parts['query'], $queryArr);
		}
		if (is_array($query)) {
			$tmp = $query;
		} else {
			parse_str($query, $tmp);
		}
		$queryArr = array_merge($queryArr, $tmp);
		$query = http_build_query($queryArr);
		if ($query) {
			$str .= '?' . $query;
		}
		if (isset($parts['fragment']) && strpos($query, '#') === false) {
			$str .= '#' . $parts['fragment'];
		}
		return $str;
	}

	public static function getQuery($query = null, $url = null)
	{
		if ($url === null) {
			$url = $_SERVER['REQUEST_URI'];
		}
		$urlQuery = parse_url($url, PHP_URL_QUERY);
		if (!$query) {
			return $urlQuery ? '?' . $urlQuery : '';
		}

		$queryArr = array();
		if ($urlQuery) {
			parse_str($urlQuery, $queryArr);
		}

		if (is_array($query)) {
			$tmp = $query;
		} else {
			parse_str($query, $tmp);
		}

		$queryArr = array_unique(array_merge($queryArr, $tmp));
		$query = http_build_query($queryArr);
		$query = $query ? '?' . $query : '';
		return $query;
	}
}