<?php

class Jcan_Tree
{
	//DomDocument
	public $doc;
	//DomXpath
	public $xpath;
	//xml file
	public $file;
	//RegExp
	public $regexpId = '/^[a-z\_][a-z0-9\.\_]{0,100}$/i';

	//default tag name
	protected $_tagName = 'catalog';
	//id attribute name
	protected $_id = 'xml:id';
	//other attributes
	protected $_attributes = array(
		'name', 'plugin', 'logo', 'editMode', 'disabled',
		'thumbWidth', 'thumbHeight', 'imageMaxWidth', 'description',
		);

	/**
	 * init
	 *
	 * @param string $xmlfile
	 */
	public function __construct($xmlfile)
	{
		$this->file = $xmlfile;

		$this->doc = new DomDocument('1.0', 'utf-8');
		$this->doc->preserveWhiteSpace = false;

		$this->doc->formatOutput = DEBUG_MODE ? true : false;

		if (file_exists($xmlfile)) {
			$this->doc->load($xmlfile);
		}
		else {
			$root = $this->doc->createElement('root');
			$this->doc->appendChild($root);
			$this->doc->save($xmlfile);
		}

		$this->xpath = new DomXpath($this->doc);
		//$this->doc === $this->doc->documentElement->ownerDocument
	}

	/**
	 * 取得属性名
	 */
	public function getAttributeNames()
	{
		return $this->_attributes;
	}

	/**
	 * 把ID或者DOMElement强制为DOMElement
	 *
	 * @param string|DOMElement $node
	 * @return DOMElement|false
	 */
	public function fixNode($node)
	{
		if (empty($node)) return null;

		if (is_string($node)) {
			$node = $this->getElementById($node);
		}
		if ($node) return $node;

		return false;
	}

	/**
	 * 取得某分类下的类型节点
	 */
	public function getTypeNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		if ($status === null) {
			$path = "{$this->_tagName}[@plugin='Type']";
		} elseif ($status) {
			$path = "{$this->_tagName}[@plugin='Type'][not(@disabled='1')]";
		} else {
			$path = "{$this->_tagName}[@plugin='Type'][@disabled='1']";
		}

		$nodes = $this->xpath->query($path, $node);
		return $nodes;
	}

	/**
	 * 取得某分类下的类型节点名
	 * id为键, name为值
	 */
	public function getTypeNames($node, $status = null)
	{
		$retval = array();

		if (!$nodes = $this->getTypeNodes($node, $status)) return $retval;
		foreach ($nodes as $node) {
			$retval[$this->getNodeId($node)] = $node->getAttribute('name');
		}
		return $retval;
	}

	/**
	 * 判断一个节点是否为类型结点
	 *
	 * @param string|DOMElement $node
	 * @return bool
	 */
	public function isTypeNode($node)
	{
		return $this->getPluginName($node) === 'Type';
	}

	/**
	 * 判断一个节点下是否存在type节点
	 *
	 * @param string|DOMElement $node
	 * @return bool
	 */
	public function hasTypeNodes($node)
	{
		$nodes = $this->getTypeNodes($node);
		return $nodes == false ? false : (bool)$nodes->length;
	}

	/**
	 * 判断某节点的plugin属性
	 *
	 * @param string|DOMElement $node
	 * @return string
	 */
	public function getPluginName($node)
	{
		return $this->getNodeAttribute($node, 'plugin');
	}

	/**
	 * 取得节点的某个属性值
	 *
	 * @param string|DOMElement $node
	 * @param string $attribute
	 * @return string
	 */
	public function getNodeAttribute($node, $attribute)
	{
		if (!$node = $this->fixNode($node)) return false;
		return $node->getAttribute($attribute);
	}

	public function getNodeName($node)
	{
		return $this->getNodeAttribute($node, 'name');
	}

	public function getNodeDescription($node)
	{
		return $this->getNodeAttribute($node, 'description');
	}

	public function contains($node, $children)
	{
		$node = $this->fixNode($node);
		$children = $this->fixNode($children);

		if (!$node || !$children) return false;
		if ($node->isSameNode($children)) return true;

		while ($children = $children->parentNode) {
			if ($children && $children->isSameNode($node)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 得到节点ID的值
	 *
	 * @return string
	 */
	public function getNodeId($node)
	{
		return $node->getAttribute($this->_id);
	}

	/**
	 * 解析节点为数组形式,并把_parentId保存也保存进数据
	 *
	 * @param string|DOMElement $node
	 * @return array|false
	 */
	public function parseNode($node)
	{
		if (!$node = $this->fixNode($node)) return false;

		$retval = array();

		$attrs = $node->attributes;
		foreach ($attrs as $k => $v) {
			if ($k == $this->_id) $k = 'id';
			$retval[$k] = $v->nodeValue;
		}

		$retval['_parentId'] = $this->getNodeId($node->parentNode);
		return $retval;
	}

	/**
	 * 在某位置创建一节点
	 *
	 * @param string $id
	 * @param array $attrs
	 * @param string|null|DOMElement $parentNode
	 * @param string|null|DOMElement $nextSibling
	 * @return false|DOMElement
	 */
	public function create($id, $attrs, $parentNode = null, $nextSibling = null)
	{
		if ($this->hasId($id)) {
			return false;
		}

		$node = $this->_createNode($id, $attrs);
		if ($node == false) return false;

		$this->move($node, $parentNode, $nextSibling);
		return $node;
	}

	/**
	 * 修改某节点(不修改ID)
	 *
	 * @param string|DomElement $node
	 * @param array $attrs
	 * @return false|DOMElement
	 */
	public function modify($node, $attrs)
	{
		//fix $node
		if (!$node = $this->fixNode($node)) return false;

		//删除原有节点
		$id = $this->getNodeId($node);
		$attributes = $node->attributes;
		for ($i=0, $cnt=$attributes->length; $i<$cnt; $i++) {
			$node->removeAttributeNode($attributes->item(0));
		}
		$node->setAttribute($this->_id, $id);

		//增加新节点
		foreach ($this->_attributes as $v) {
			if (isset($attrs[$v])) {
				$node->setAttribute($v, $attrs[$v]);
			}
		}

		return $node;
	}

	/**
	 * 修改节点的ID
	 *
	 * @param string|DOMElement $node
	 * @param string $newId
	 * @return bool
	 */
	public function modifyId($node, $newId)
	{
		//$newId需符合规则
		if (!preg_match($this->regexpId, $newId)) return false;

		//fix $node
		$node = $this->fixNode($node);

		//$node, $newId都不可为空
		if (!$node || empty($newId)) return false;

		//$oldId == $newId 时直接返回true
		if ($this->getNodeId($node) == $newId) return true;

		//已经存在$newId时,返回false
		if ($this->hasId($newId)) {
			return false;
		}

		//设置newID
		$node->setAttribute($this->_id, $newId);
		return true;
	}

	/**
	 * 移动某节点
	 *
	 * @param string|DOMElement $node
	 * @param string|null|DOMElement $parentNode
	 * @param string|null|DOMElement $nextSibling
	 * @return boolean
	 */
	public function move($node, $parentNode = null, $nextSibling = null)
	{
		//fix $node
		if (!$node = $this->fixNode($node)) return false;

		//fix $parentNode
		if (!$parentNode = $this->fixNode($parentNode)) {
			$parentNode = $this->doc->documentElement;
		}

		//fix $nextSibling
		$nextSibling = $this->fixNode($nextSibling);

		//$parentNode与$nextSibling->parentNode必须为同一节点
		if ($nextSibling && !$parentNode->isSameNode($nextSibling->parentNode)) {
			return false;
		}

		//$node与$nextSibling不可为同一节点
		if ($nextSibling && $node->isSameNode($nextSibling)) {
			return false;
		}

		//$node不可是$parentNode的祖先结点,也不可为相同结点
		$nodeList = $this->getAncestorOrSelfNodes($parentNode);
		if ($this->inNodeList($node, $nodeList)) {
			return false;
		}

		//Move
		$parentNode->insertBefore($node, $nextSibling);
		return $node;
	}

	/**
	 * 删除某节点,有子节点的节点无法删除
	 *
	 * @param string|DOMElement $node
	 * @return 0|false|true
	 */
	public function remove($node)
	{
		if (!$node = $this->fixNode($node)) return 0;

		if ($node->childNodes->length) {
			return false;
		}

		$node->parentNode->removeChild($node);
		return true;
	}

	/**
	 * 对同级节点进行排序
	 *
	 * @param array $ids
	 * @return bool
	 */
	public function sorting($ids)
	{
		$cnt = count($ids);
		if ($cnt < 2) {
			return true;
		}

		for ($i=$cnt-1; $i>0; $i--) {
			$refNode = $this->getElementById($ids[$i]);
			$newNode = $this->getElementById($ids[$i-1]);

			if (empty($refNode) || empty($newNode)
					|| $refNode->isSameNode($newNode)
					|| $refNode->parentNode->isSameNode($newNode->parentNode) == false) {
				continue;
			}
			$refNode->parentNode->insertBefore($newNode, $refNode);
		}

		return true;
	}

	/**
	 * 保存XML
	 *
	 * @param string $file[optional]
	 */
	public function save($file = null)
	{
		if (empty($file)) {
			$file = $this->file;
		}

		$this->doc->save($file);
	}

	/**
	 * 返回xml文本
	 *
	 * @return string
	 */
	public function saveXml()
	{
		return $this->doc->saveXml();
	}

	/**
	 * 根据ID得到一个节点
	 *
	 * @param string $id
	 * @return DOMElement
	 */
	public function getElementById($id)
	{
		$node = $this->doc->getElementById($id);
		return $node;
	}

	/**
	 * 是否存在某ID的节点
	 *
	 * @param string $id
	 * @return bool
	 */
	public function hasId($id)
	{
		$node = $this->getElementById($id);
		return (bool)$node;
	}

	/**
	 * 返回某节点是否可利用(是否被disabled), 如果父节点不可用, 该节点也不可利用
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status
	 * @return bool
	 */
	public function validateNode($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		$nodes = $this->getAncestorOrSelfNodes($node, $status);

		return (bool)$nodes;
	}

	/**
	 * 得到某节点的祖先节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status null:显示所有节点, true:只显示可视节点,如父节点有一个disabled则返回false
	 * @return DOMElementList | false
	 */
	public function getAncestorNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;
		$nodes = $this->xpath->query("ancestor::{$this->_tagName}", $node);

		if ($status) {
			foreach ($nodes as $n) {
				if ($n->getAttribute('disabled') == '1') {
					return false;
				}
			}
		}
		return $nodes;
	}

	/**
	 * 得到某节点的祖先节点,包括自身节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status null:显示所有节点, true:如本身节点与父节点中有一个disabled则返回false
	 * @return DOMElementList | false
	 */
	public function getAncestorOrSelfNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;
		$nodes = $this->xpath->query("ancestor-or-self::{$this->_tagName}", $node);

		if ($status) {
			foreach ($nodes as $n) {
				if ($n->getAttribute('disabled') == '1') {
					return false;
				}
			}
		}
		return $nodes;
	}

	/**
	 * 得到某节点的子孙节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status null:寻找所有符合条件节点, true:只寻找enable节点, false:只寻找disabled节点
	 * @return DOMElementList
	 */
	public function getDescendantNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		if ($status === null) {
			$path = "descendant::{$this->_tagName}";
		} elseif ($status) {
			$path = "descendant::{$this->_tagName}[not(@disabled='1')]";
		} else {
			$path = "descendant::{$this->_tagName}[@disabled='1']";
		}

		$nodes = $this->xpath->query($path, $node);
		return $nodes;
	}

	/**
	 * 得到某节点的子孙节点,包括自身节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status null:寻找所有符合条件节点, true:只寻找enable节点, false:只寻找disabled节点
	 * @return DOMElementList
	 */
	public function getDescendantOrSelfNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		if ($status === null) {
			$path = "descendant-or-self::{$this->_tagName}";
		} elseif ($status) {
			$path = "descendant-or-self::{$this->_tagName}[not(@disabled='1')]";
		} else {
			$path = "descendant-or-self::{$this->_tagName}[@disabled='1']";
		}

		$nodes = $this->xpath->query($path, $node);
		return $nodes;
	}

	/**
	 * 判断在NodeList中是否存在该节点
	 *
	 * @param string|DOMElement $node
	 * @param DOMElementList $nodeList
	 * @return bool
	 */
	public function inNodeList($node, $nodeList)
	{
		if (!$node = $this->fixNode($node)) return false;

		$len = $nodeList->length;
		for ($i=0; $i<$len; $i++) {
			if ($node->isSameNode($nodeList->item($i))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 取得某ID的父节点
	 *
	 * @param string|DOMElement $node
	 * @return DOMElement
	 */
	public function getParentNode($node)
	{
		if (!$node = $this->fixNode($node)) return false;
		return $node->parentNode;
	}

	/**
	 * 取得某节点的孩子节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status null:所有, true:enable节点, false:disabled节点
	 * @return DOMNodeList
	 */
	public function getChildNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		if ($status === null) {
			return $node->childNodes;
		}

		$path = $status ? "{$this->_tagName}[not(@disabled='1')]" : "{$this->_tagName}[@disabled='1']";
		return $this->xpath->query($path, $node);
	}

	/**
	 * 取得相邻节点
	 *
	 * @param string|DOMElement $node
	 * @param mixed $status
	 * @return DOMNodeList
	 */
	public function getSiblingNodes($node, $status = null)
	{
		if (!$node = $this->fixNode($node)) return false;

		$parentNode = $this->getParentNode($node);
		return $this->getChildNodes($parentNode);
	}

	/**
	 * 把nodeList转换为数据形式,便于smarty进行foreach
	 *
	 * @param DOMElementList $nodeList
	 * @return array
	 */
	public static function makeArray($nodeList)
	{
		$arr = array();
		foreach ($nodeList as $node) {
			$arr[] = $node;
		}
		return $arr;
	}

	/**
	 * 创建一个节点, 未挂载
	 *
	 * @param string $id
	 * @param array $attrs
	 * @return false|DOMElement
	 */
	protected function _createNode($id, $attrs)
	{
		if (!preg_match($this->regexpId, $id)) return false;

		$node = $this->doc->createElement($this->_tagName);
		$node->setAttribute($this->_id, $id);

		foreach ($this->_attributes as $v) {
			if (isset($attrs[$v])) {
				$node->setAttribute($v, $attrs[$v]);
			}
		}
		return $node;
	}
}