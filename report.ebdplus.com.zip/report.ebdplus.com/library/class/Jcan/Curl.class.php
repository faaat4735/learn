<?php
/**
 * 用法:
	$o = new Jcan_Curl('http://framework.lc/server.php?user=仲元杰', array('postuser'=>'仲元杰', 'userid'=>3), 'gbk');
	$o->cookieJar = 'C:\a.cookie';
	$o->exec();
	echo $o->result;
 */
class Jcan_Curl
{
	//代理地理,格式为:"222.35.58.227:8080"
	public $proxy		= null;
	//需要请求的链接,格式为: http://ouk.cn/?id=3
	public $url		= null;
//	public $getFileds;
	//POST字段,格式为:array('id'=>2,'title'=123) 或者 id=2&title=123
	public $postFields	= array();
	//是否为图片类型
	public $isImage		= false;
	//请求链接的编码
	public $charset		= 'utf-8';
	//HTTP HEADER, 格式: array('content-type: text/html;charset=utf-8','client-ip: 222.40.20.20')
	public $header		= array();
	//保存cookie的文件
	public $cookieJar	= null;
	//curl连接句柄
	public $ch		= null;
	//是否输header出头
	public $echoHeader	= false;
	//是否输出正文
	public $echoBody	= true;
	//是否跟踪网址
	public $followLocation	= true;
	//设置连接超时时间
	public $timeout		= 120;
	//是否直接输出, 1表示不输出存储在变量里
	public $returnTransfer	= 1;
	//返回的结果
	public $result		= null;
	//模拟的IP
	public $fakeIp		= '61.212.12.88'; //小日本IP
	//referer
	public $referer		= null;
	//userAgent
	public $useAgent	= 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)';
	//cookiesession
	public $cookie		= null;
	//verbose
	public $verbose		= false;

	/**
	 * 初始化curl_init,及简单的一些设置
	 *
	 */
	public function __construct($url=null, $postFields=null, $charset='utf-8')
	{
		//self::charset
		$this->charset = $charset;

		//self::post
		$this->postFields = $postFields;

		//self::url
		if (!empty($url)) {
			$this->url = $url;
		}

		//referer
//		$arr = parse_url($this->url);
//		if (isset($arr['scheme']) && isset($arr['host'])) {
//			$this->referer = $arr['scheme'] . '://' . $arr['host'];
//		} elseif (isset($arr['path'])) {
//			$this->referer .= $arr['path'];
//		}

		//生成curl连接柄
		$this->ch = curl_init();
	}

	public function __destruct()
	{
		$this->close();
	}

	public function close()
	{
		@curl_close($this->ch);
	}

	/**
	 * 执行操作
	 */
	public function exec($isEcho = false)
	{
		//设置请求URL
		if (empty($this->url)) {
			throw new Exception('Jcan_Curl->$url 尚未设置');
			exit;
		}
		self::_convertEncoding($this->url);
		curl_setopt($this->ch, CURLOPT_URL, $this->url);

		//设置代理
		if (!empty($this->proxy)) {
			curl_setopt($this->ch, CURLOPT_PROXY, $this->proxy);
		}

		//设置要保存的cookie文件
		//设置已保存的cookie文件
		if (!empty($this->cookieJar)) {
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookieJar);
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookieJar);
		}
		if (!empty($this->cookie)) {
			curl_setopt($this->ch, CURLOPT_COOKIE, $this->cookie);
		}

		//userAgent
		if (!empty($this->useAgent)) {
			curl_setopt($this->ch, CURLOPT_USERAGENT, $this->useAgent);
		}

		//referer
		if (!empty($this->referer)) {
			curl_setopt($this->ch, CURLOPT_REFERER, $this->referer);
		} else {
			curl_setopt($this->ch, CURLOPT_AUTOREFERER, true);
		}

		//debug
		curl_setopt($this->ch, CURLOPT_VERBOSE, $this->verbose);
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
//		curl_setopt($this->ch, CURLOPT_UNRESTRICTED_AUTH, true);

		//header
		if (!preg_match('/^https:/i', $this->url) && !empty($this->fakeIp)) {
			$this->header = array_merge($this->header, array(
						'X-Forwarded-For: ' . $this->fakeIp,
						'client-ip: ' . $this->fakeIp,
						'VIA: 1.0 ' . $this->fakeIp . ':80 (squid/2.5.STABLE12)'));
		}
		if (!empty($this->header)) {
			self::_convertEncoding($this->header);
			curl_setopt($this->ch, CURLOPT_HTTPHEADER, $this->header);
		}


		//是否输出头信息
		curl_setopt ($this->ch, CURLOPT_HEADER, $this->echoHeader);

		//是否输出内容
		curl_setopt($this->ch, CURLOPT_NOBODY, !$this->echoBody);

		//是否直接输出, 1表示不输出存储在变量里
		curl_setopt ($this->ch, CURLOPT_RETURNTRANSFER, $this->returnTransfer);

		//TRUE to follow any "Location: " header
		curl_setopt ($this->ch, CURLOPT_FOLLOWLOCATION, $this->followLocation);

		//设置超时时间
		curl_setopt ($this->ch, CURLOPT_TIMEOUT, $this->timeout);

		if (!empty($this->postFields)) {
			//是否POST
			curl_setopt($this->ch, CURLOPT_POST, 1);

			//设置POST参数
			self::_convertEncoding($this->postFields);
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, $this->postFields);
		}

		//开始执行
		$this->result = curl_exec($this->ch);

		//输出结果
		if ($isEcho) {
			header('Content-Type: content/html;charset=' . $this->charset);
			if ($this->isImage) {
				echo $this->result;
			} else {
				$data = preg_replace("!>!", "><base href=\"{$this->url}\" />", $this->result, 1);
				echo $this->result;
			}
		}

		if (curl_errno($this->ch)) {
			die($this->getError());
		} else {
			return $this->result;
		}
	}

	/**
	 * 返回状态
	 */
	public function getHttpStatus()
	{
		if (!$this->echoHeader) {
			throw new ErrorException('请设置Jcan_Curl->header选项为真');
		}

		preg_match('!^HTTP/1.1 (\d+) !', $this->result, $arr);
		if (isset($arr[1])) {
			return $arr[1];
		} else {
			return 0;
		}
	}

	public function getError()
	{
		$error = curl_errno($this->ch) . " - " . curl_error($this->ch);
		return $error;
	}

	/**
	 * 把字符串默认的utf-8编码转化为请求URL的编码
	 */
	protected function _convertEncoding(&$var)
	{
		if (strcasecmp($this->charset, 'utf-8') !== 0) {
			if (is_array($var)) {
				foreach ($var as $key=>$value) {
					$var[$key] = mb_convert_encoding($value, $this->charset, 'utf-8');
				}
			} else {
				$var = mb_convert_encoding($var, $this->charset, 'utf-8');
			}
		}
	}
}

