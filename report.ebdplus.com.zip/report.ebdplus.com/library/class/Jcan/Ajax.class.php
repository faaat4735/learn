<?php

class Jcan_Ajax
{

	/**
	 * 详情请查看jQuery.ajaxAuto
	 * 'status'	=> ok | error | other..
	 * 'msg'	=> string
	 * 'redirect'	=> reload | referer | back | http://xxx
	 * 'delay'	=> 2000
	 * 'data'	=> array() ........ (任意数据)
	 *
	 * @example self::response(array('status'=>'ok', 'msg'=>'操作成功', 'redirect'=>'reload', 'delay'=>3000));
	 * @example self::response('ok', '操作成功', 'reload', 3000);
	 * @example self::response('error', '请填写用户名');
	 */
	public static function response($status = 'ok', $msg = null, $redirect = null, $delay = null, $data = null)
	{
		//非ajax请求
		if (Jcan_Http::isAjax()) {
			if (is_array($status)) {
				exit(json_encode($status));
			}

			$retval = array();
			$retval['status'] = $status;
			if ($msg !== null) {
				$retval['msg'] = $msg;
			}
			if ($redirect !== null) {
				$retval['redirect'] = $redirect;
			}
			if ($delay !== null) {
				$retval['delay'] = $delay;
			}
			if ($data !== null) {
				$retval['data'] = $data;
			}
			exit(json_encode($retval));
		}

		//ajax请求
		else {
			if (is_array($status)) {
				$msg = isset($status['msg']) ? $status['msg'] : null;
				$redirect = isset($status['redirect']) ? $status['redirect'] : null;
				$delay = isset($status['delay']) ? $status['delay'] : null;
				$status = isset($status['status']) ? $status['status'] : null;
			}

			//无转向时
			if (empty($redirect)) {
				$redirect = 'none';
			}

			//有提示信息
			switch ($redirect) {
				//重载提交页
				case 'reload':
					if (empty($_SERVER['HTTP_REFERER'])) {
						Jcan_Js::msg($msg, 'back');
					} else {
						if (empty($msg)) {
							Jcan_Http::redirect($_SERVER['HTTP_REFERER']);
						} else {
							Jcan_Js::msg($msg, 'redirect', $_SERVER['HTTP_REFERER']);
						}
					}
					break;

				//提交页后退
				case 'back':
					Jcan_Js::msg($msg, -2);
					break;

				//提交页转向提交页的referer页
				case 'referer':
					if (empty($_REQUEST['referer'])) {
						Jcan_Js::msg($msg, -2);
					} else {
						if (empty($msg)) {
							self::redirect($_REQUEST['referer']);
						} else {
							Jcan_Js::msg($msg, 'redirect', $_REQUEST['referer']);
						}
					}
					break;

				//无转向时应该后退至提交页
				case 'none':
					Jcan_Js::msg($msg, 'back');
					break;

				//提交页转向其他页
				default:
					if (empty($msg)) {
						Jcan_Http::redirect($redirect);
					} else {
						Jcan_Js::msg($msg, 'redirect', $redirect);
					}
					break;
			}
		}
	}

	/**
	 * 把变量以文本形式返回
	 *
	 * @param mixed $var
	 * @example
	 *  self::responseText(true)	=> true
	 *  self::responseText(null)	=> null
	 *  self::responseText('')	=>
	 *  self::responseText(0)	=> 0
	 *  self::responseText(array(1,2)) => [1,2]
	 */
	public static function responseText($var)
	{
		//header("Content-Type: text/plain; charset=UTF-8");
		if (is_string($var)) {
			$str =& $var;
		} else {
			$str = json_encode($var);
		}
		echo $str;
		exit;
	}

	/**
	 * 返回0, 1, -1三种状态
	 *
	 * @param bool $status enum(true, false, _FAILURE_)
	 */
	public static function responseStatus($status)
	{
		if ($status === true || $status == 1) {
			$text = '1';
		}
		elseif ($status == 0) {
			$text = '0';
		}
		else {
			$text = '-1';
		}

		echo $text;
		exit;
	}
}