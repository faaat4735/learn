<?php

class Jcan_Object
{
	/**
	 * 合并stdClass对象
	 *
	 * @example self::merge($a, $b, $c, $d, ...)
	 * @return stdClass
	 */
	public static function merge() {
		$retval = new stdClass();

		$objs = func_get_args();
		foreach ($objs as &$obj) {
			if (!$obj) continue;

			foreach ($obj as $k => &$v) {
				$retval->$k = $v;
			}
		}
		return $retval;
	}
}