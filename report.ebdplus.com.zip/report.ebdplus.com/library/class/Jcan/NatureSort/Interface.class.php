<?php

interface Jcan_NatureSort_Interface
{
	/**
	 * 初始化
	 *
	 * @param Jcan_Db $db
	 */
	public function __construct(Jcan_Db $db = null);

	/**
	 * 取得范围字符串
	 *
	 * @param int $id
	 * @param string $field
	 * @return string
	 * @example
	 * 	$this->getScopeString(101000000) => BETWEEN 101000000 AND 101999999
	 */
	public function getScopeString($id);

	/**
	 * get next sub id by parent id
	 *
	 * @param int $id
	 * @return int
	 * @example
	 * 	$this->getNextSubId(101000000);
	 * 	$this->getNextSubId(null);
	 */
	public function getNextSubId($id);

	/**
	 * 根据ID返回该ID所属级别
	 *
	 * @param int $id
	 * @return int
	 * @example
	 * 	$this->getLevel(101000000) => 1
	 * 	$this->getLevel(0) => 1
	 * 	$this->getLevel(null) => 0
	 */
	public function getLevel($id);

	/**
	 * 取得某级别的ID
	 *
	 * @param int $id
	 * @param int $level
	 * @return int
	 */
	public function getLevelId($id, $level);

	/**
	 * 取得父ID
	 *
	 * @param int $id
	 * @return int
	 */
	public function getParentId($id);
}