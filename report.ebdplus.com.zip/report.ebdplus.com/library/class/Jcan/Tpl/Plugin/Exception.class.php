<?php

class Jcan_Tpl_Plugin_Exception extends Jcan_Tpl_Exception
{}