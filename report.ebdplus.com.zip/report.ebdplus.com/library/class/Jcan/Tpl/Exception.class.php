<?php

class Jcan_Tpl_Exception extends Jcan_Exception
{}