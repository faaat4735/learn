<?php

/**
 * Table Structure:
 *	CREATE TABLE t_tpls (
 *		tpl_name varchar(80) NOT NULL,
 *		tpl_source text NULL,
 *		tpl_timestamp timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 *		PRIMARY KEY (tpl_name)
 *	) ENGINE=MyISAM DEFAULT CHARSET=utf8;
 *
 * @example
 * 	$smarty->register_resource("db", array(
 *		new Jcan_Smarty_Resource_Db(App_Db::getInstance()),
 *		'getSource',
 *		'getTimestamp',
 *		'getSecure',
 *		'getTrusted',
 *		));
 */
class Jcan_Smarty_Resource_Db implements Jcan_Smarty_Resource_Interface
{
	public $table = 't_tpls';
	public $fieldName = 'tpl_name';
	public $fieldSource = 'tpl_source';
	public $fieldTimestamp = 'tpl_timestamp';

	public $db;
	private $_timestamp;

	public function __construct(Jcan_Db $db)
	{
		$this->db = $db;
	}

	public function getSource($tplName, &$source, &$smarty)
	{
		$sql = "SELECT {$this->fieldSource} tpl_source, UNIX_TIMESTAMP({$this->fieldTimestamp}) tpl_timestamp
			FROM {$this->table}
			WHERE {$this->fieldName} = ?";
		$row = $this->db->getRow($sql, null, $tplName);

		if ($row) {
			$this->_timestamp = $row->tpl_timestamp;
			$source = $row->tpl_source;
			return true;
		}
		return false;
	}

	public function getTimestamp($tplName, &$timestamp, &$smarty)
	{
		if ($this->_timestamp) {
			$timestamp = $this->_timestamp; echo $timestamp;
			return true;
		}

		return false;
	}

	public function getSecure($tplName, &$smarty)
	{
		return true;
	}

	public function getTrusted($tplName, &$smarty)
	{
		return true;
	}
}