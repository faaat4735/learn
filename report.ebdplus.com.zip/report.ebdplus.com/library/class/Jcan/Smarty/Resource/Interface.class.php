<?php

interface Jcan_Smarty_Resource_Interface
{
	/**
	 * Retrieve the resource by template name.
	 *
	 * @param string $tplName
	 * @param string &$source
	 * @param Smarty &$smarty
	 * @param boolean
	 */
	public function getSource($tplName, &$source, &$smarty);

	/**
	 * Retrieve the last modification time of the requested resource (as a UNIX timestamp).
	 *
	 * @param string $tplName
	 * @param int &$timestamp
	 * @param Smarty &$smarty
	 * @return boolean
	 */
	public function getTimestamp($tplName, &$timestamp, &$smarty);

	/**
	 * The function is supposed to return true or false, depending on whether the requested resource is secure or not.
	 * This function is used only for template resources but should still be defined.
	 *
	 * @param string $tplName
	 * @param Smarty &$smarty
	 * @param boolean
	 */
	public function getSecure($tplName, &$smarty);

	/**
	 * The function is supposed to return true or false, depending on whether the requested resource is trusted or not.
	 * This function is used for only for PHP script components requested by {include_php} tag or {insert} tag with src attribute.
	 * However, it should still be defined even for template resources.
	 *
	 * @param string $tplName
	 * @param Smarty &$smarty
	 * @param boolean
	 */
	public function getTrusted($tplName, &$smarty);
}