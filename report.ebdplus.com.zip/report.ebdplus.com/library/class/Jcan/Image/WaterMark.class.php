<?php

class Jcan_Image_WaterMark extends Jcan_Image
{
	/**
	 * GD image mask
	 * @example
	 *	$im = imagecreatefromjpeg("a.jpg");
	 *	imagemask($im, 100, 100, 200, 120, 28);
	 *	imagepng($im);
	 *	imagedestroy($im);
	 * @param resource 	&$im	图片实例
	 * @param int 		$x1	左上角X坐标
	 * @param int		$y1	左上角Y坐标
	 * @param int		$width	马赛克的总宽度
	 * @param int		$height	马赛克的总高度
	 * @param int		$size 	每个马赛克的大小
	 */
	public static function mask(&$im, $x1, $y1, $width, $height, $size)
	{
		$x2 = $x1 + $width;
		$y2 = $y1 + $height;
		for($x = $x1; $x < $x2; $x += $size) {
			for ($y = $y1; $y < $y2; $y += $size) {
				$color = ImageColorAt ($im, $x + round($size / 2), $y + round($size / 2));
				imageFilledRectAngle ($im, $x, $y, $x + $size, $y + $size, $color);
			}
		}
	}


	/**
	 * 在im上添加文字并且描边
	 *
	 * @param im &$im
	 * @param string $text 要加入的文字
	 * @param int $x (文字的X坐标, 即文字的左下角坐标)
	 * @param int $y (文字的Y坐标, 即文字的左下角坐标)
	 * @param int $fontSize 文字大小(默认为9pt)
	 * @param int $fontColor 文字颜色(16进制)
	 * @param int $fontAlpha 文字的透明度(0-127)
	 * @param string $fontFile 字体或字体位置
	 * @param string $outerColor 描边颜色(16进制)
	 * @param int $outerAlpha 描边透明度(0-127)
	 * @param bool $trueOuter (false表示前后左右描点,true表示四周描点,默认为前后左右描点)
	 *
	 * @example
		header("Content-type: image/png");

		$im = imagecreatefromjpeg("/a.jpg");
		Jcan_Image_WaterMark::outerText($im, '邮箱:yuanjie.zhong@gmail.com', 10, 300,
						9, '#000000', 0, "wqy-bsong.ttf",
						'#ffffff', 80, false);
		imagePng($im);
		imageDestroy($im);
	 */
	public static function outerText(&$im, $text, $x=10, $y=10,
					$fontSize=9, $fontColor='#000000', $fontAlpha=0, $fontFile='simsun.ttc',
					$outerColor='#ffffff', $outerAlpha=0, $trueOuter=false)
	{
		$angle = 0;
		$area = imagettfbbox($fontSize, $angle, $fontFile, $text);

		//真正宽度(包括外面描边的两个像素)
		$width  = $area[2] - $area[0] + 1 + 2;
		//真正高度(包括外面描边的两个像素)
		$height = $area[1] - $area[5] + 1 + 2;
		$addedHeight = $height+2;

		//临时用来对比的层
		$im_tmp = imagecreate($width, $addedHeight);
		$white = imagecolorallocate($im_tmp, 255, 255, 255);
		$black = imagecolorallocate($im_tmp, 0, 0, 0);

		//字体颜色
		$fontColor = imageColorAllocateHex($im, $fontColor, $fontAlpha);
		//描边颜色
		$outerColor = imageColorAllocateHex($im, $outerColor, $outerAlpha);

//这儿可设置填充背景色
//$fillColor = imageColorAllocateHex($im,'#ffffff',100);
//imageFilledRectAngle ($im, $x-5, $y-22, $x + $width, $y + $height, $fillColor);

		@imagettftext($im_tmp, $fontSize, $angle, 1, $height - 2, $black, $fontFile, $text);
		@imagettftext($im, $fontSize, $angle, $x, $y, $fontColor, $fontFile, $text);
		$y = $y - $height + 2;
		$x = $x - 1;

		//开始描边
		for ($i = 1; $i < $width-1; $i ++) {
			for ($j = 1; $j < $height-1+2; $j ++) {
				$c = ImageColorAt($im_tmp, $i, $j);
				if ($c === $black) {
					ImageColorAt ($im_tmp, $i, $j - 1) === $black || imagesetpixel($im, $x + $i, $y + $j - 1, $outerColor);
					ImageColorAt ($im_tmp, $i, $j + 1) === $black || imagesetpixel($im, $x + $i, $y + $j + 1, $outerColor);
					ImageColorAt ($im_tmp, $i - 1, $j) === $black || imagesetpixel($im, $x + $i - 1, $y + $j, $outerColor);
					ImageColorAt ($im_tmp, $i + 1, $j) === $black || imagesetpixel($im, $x + $i + 1, $y + $j, $outerColor);

					// 取消注释，与Fireworks的发光效果相同
					if ($trueOuter) {
						ImageColorAt ($im_tmp, $i - 1, $j - 1) != $white || imagesetpixel($im, $x + $i - 1, $y + $j - 1, $outerColor);
						ImageColorAt ($im_tmp, $i + 1, $j - 1) != $white || imagesetpixel($im, $x + $i + 1, $y + $j - 1, $outerColor);
						ImageColorAt ($im_tmp, $i - 1, $j + 1) != $white || imagesetpixel($im, $x + $i - 1, $y + $j + 1, $outerColor);
						ImageColorAt ($im_tmp, $i + 1, $j + 1) != $white || imagesetpixel($im, $x + $i + 1, $y + $j + 1, $outerColor);
					}
				}
			}
		}

		//销毁临时im对象
		imageDestroy($im_tmp);
	}
}