<?php
/**
 * 生成验证码的类
 * 说明: 此类中产生所有的session名称全部以_auth_为前缀
 *
 * @version  1.0
 * @author   Jcan
 * @example
 * 得到sessionSn:
 * $sessionSn = Jcan_Image_AuthCode::getSessionSn()
 *
 * 生成图片:
 * $o = new Jcan_Image_AuthCode();
 * $o->setBgColor(255, 255, 255);
 * $o->setFontColor(0,0,0,255,255,255);
 * $o->setPixelColor(200, 155, 155);
 * $o->setPixelNumber(20);
 * $o->setFontSize(2, 5);
 * $o->setImageSize(70, 18);
 * $o->create($_GET['sessionSn']);
 *
 * 取得验证码:
 * Jcan_Image_AuthCode::getAuthCode($_POST['sessionSn'], true);
 */
class Jcan_Image_AuthCode extends Jcan_Image
{
	//产生的验证码 $_SESSION
	public static $authCodeSessionKey = '_auth';
	public static $authCodeSessionCnt = 20;

	// 骓证码及Session名称
	protected $_authCode;

	// 生成图像的宽度
	protected $_imageWidth  = 70;
	// 生成图像的高度
	protected $_imageHeight = 18;
	// 生成骓证码的位数
	protected $_authLength  = 4;
	// 干扰素大小（即干扰像素的数目）
	protected $_pixelNumber    = 5;

	// 背景红，绿，蓝三个通道的最小值与最大值 范围0-255
	protected $_bgColorRedMin    = 60;
	protected $_bgColorGreenMin  = 96;
	protected $_bgColorBlueMin   = 162;

	protected $_bgColorRedMax    = 60;
	protected $_bgColorGreenMax  = 96;
	protected $_bgColorBlueMax   = 162;

	// 干扰素红，绿，蓝三个通道的最小值与最大值 范围0-255
	protected $_pixelColorRedMin     = 211;
	protected $_pixelColorGreenMin   = 211;
	protected $_pixelColorBlueMin    = 211;

	protected $_pixelColorRedMax     = 211;
	protected $_pixelColorGreenMax   = 211;
	protected $_pixelColorBlueMax    = 211;

	// 文字红，绿，蓝三个通道的最小值与最大值 范围0-255
	protected $_fontColorRedMin     = 255;
	protected $_fontColorGreenMin   = 255;
	protected $_fontColorBlueMin    = 255;

	protected $_fontColorRedMax     = 255;
	protected $_fontColorGreenMax   = 255;
	protected $_fontColorBlueMax    = 255;

	// 字体最大尺寸与最小尺寸 （范围1-5）
	protected $_fontSizeMin = 2;
	protected $_fontSizeMax = 5;



	/**
	 * session名称可在创建时设定
	 *
	 * @param String $sessionName = null
	 */
	public function __construct()
	{
		//确保存在 $_SESSIOn[self::$authCodeSessionKey]
		if (!isset($_SESSION[self::$authCodeSessionKey])) {
			$_SESSION[self::$authCodeSessionKey] = array();
		}
	}

	/**
	 * 设置背景色 (各个参数的范围都是0-255)
	 *
	 * @param int $redMin
	 * @param int $greenMin
	 * @param int $blueMin
	 * @param int $redMax
	 * @param int $greenMax
	 * @param int $blueMax
	 */
	public function setBgColor($redMin, $greenMin, $blueMin, $redMax = null, $greenMax = null, $blueMax = null) {
		$this->_bgColorRedMin   = $redMin;
		$this->_bgColorGreenMin = $greenMin;
		$this->_bgColorBlueMin  = $blueMin;

		if ($redMax === null) {
			$this->_bgColorRedMax = $redMin;
		} else {
			$this->_bgColorRedMax = $redMax;
		}

		if ($greenMax === null) {
			$this->_bgColorGreenMax = $greenMin;
		} else {
			$this->_bgColorGreenMax = $greenMax;
		}

		if ($blueMax === null) {
			$this->_bgColorBlueMax = $blueMin;
		} else {
			$this->_bgColorBlueMax = $blueMax;
		}
	}

	/**
	 * 设置字体颜色 (各个参数的范围都是0-255)
	 *
	 * @param int $redMin
	 * @param int $greenMin
	 * @param int $blueMin
	 * @param int $redMax
	 * @param int $greenMax
	 * @param int $blueMax
	 */
	public function setFontColor($redMin, $greenMin, $blueMin, $redMax = null, $greenMax = null, $blueMax = null) {
		$this->_fontColorRedMin      = $redMin;
		$this->_fontColorGreenMin    = $greenMin;
		$this->_fontColorBlueMin     = $blueMin;

		if ($redMax === null) {
			$this->_fontColorRedMax = $redMin;
		} else {
			$this->_fontColorRedMax = $redMax;
		}

		if ($greenMax === null) {
			$this->_fontColorGreenMax = $greenMin;
		} else {
			$this->_fontColorGreenMax = $greenMax;
		}

		if ($blueMax === null) {
			$this->_fontColorBlueMax = $blueMin;
		} else {
			$this->_fontColorBlueMax = $blueMax;
		}
	}

	/**
	 * 设置干扰素的颜色 (各个参数的范围都是0-255)
	 *
	 * @param int $redMin
	 * @param int $greenMin
	 * @param int $blueMin
	 * @param int $redMax
	 * @param int $greenMax
	 * @param int $blue
	 */
	public function setPixelColor($redMin, $greenMin, $blueMin, $redMax = null, $greenMax = null, $blueMax = null) {
		$this->_pixelColorRedMin    = $redMin;
		$this->_pixelColorGreenMin  = $greenMin;
		$this->_pixelColorBlueMin   = $blueMin;

		if ($redMax === null) {
			$this->_pixelColorRedMax = $redMin;
		} else {
			$this->_pixelColorRedMax = $redMax;
		}

		if ($greenMax === null) {
			$this->_pixelColorGreenMax = $greenMin;
		} else {
			$this->_pixelColorGreenMax = $greenMax;
		}

		if ($blueMax === null) {
			$this->_pixelColorBlueMax = $blueMin;
		} else {
			$this->_pixelColorBlueMax = $blueMax;
		}
	}

	/**
	 * 设置验证码字体大小的范围 (范围是1-5)
	 *
	 * @param int $sizeMin
	 * @param int $sizeMax
	 */
	public function setFontSize($sizeMin, $sizeMax = null) {
		$this->_fontSizeMin = $sizeMin;

		if ($sizeMax === null) {
			$this->_fontSizeMax = $sizeMin;
		}
	}

	/**
	 * 设置生成的图像尺寸
	 *
	 * @param int $width
	 * @param int $height
	 */
	public function setImageSize($width, $height) {
		$this->_imageWidth   = $width;
		$this->_imageHeight  = $height;
	}

	/**
	 * 设置生成验证码的长度
	 *
	 * @param int $length
	 */
	public function setAuthLength($length) {
		$this->_authLength = $length;
	}

	/**
	 * 设置干扰像素的数目
	 *
	 * @param int $number
	 */
	public function setPixelNumber($number) {
		$this->_pixelNumber = $number;
	}

	/**
	 * @return 验证码的session值
	 */
	public static function getAuthCode($sessionSn, $clearSession=true) {
		if (!preg_match('!^\d{1,4}$!', $sessionSn)) {
			Jcan_Js::msg("传入了非法的sessionSn", 'back');
		}

		if (!isset($_SESSION[self::$authCodeSessionKey][$sessionSn])) {
			return false;
		}

		//取出验证码之后清除该验证码
		$retval = $_SESSION[self::$authCodeSessionKey][$sessionSn];
		if ($clearSession) {
			unset($_SESSION[self::$authCodeSessionKey][$sessionSn]);
		}
		return $retval;
	}

	/**
	 * 创建图像
	 *
	 * @param String $sessionName
	 */
	public function create($sessionSn)
	{
		//sessionSn的基本类型判断
		if (!preg_match('!^\d{1,4}$!', $sessionSn)) {
			Jcan_Js::msg("传入了非法的sessionSn", 'back');
		}

		//如果SESSION超过指定数目则删除最早的一个
		if (count($_SESSION[self::$authCodeSessionKey]) >= self::$authCodeSessionCnt) {
			reset($_SESSION[self::$authCodeSessionKey]);
			$expiredKey = key($_SESSION[self::$authCodeSessionKey]);
			unset($_SESSION[self::$authCodeSessionKey][$expiredKey]);
		}

		// 产生随机数并写入session
		$chars = array(2,3,4,5,6,7,8,9,'a','b','c','d','e','f','g','h','i','j','k','m','n',
					'p','q','r','s','t','u','v','w','x','y','z');

		for ($i = 0, $auth = ''; $i < $this->_authLength; $i++) {
			$k = array_rand($chars);
			$auth .= $chars[$k];
		}
		$this->_authCode = $auth;
		$_SESSION[self::$authCodeSessionKey][$sessionSn] = $this->_authCode;

		// 随机生成背景色
		$bgColorRed     = mt_rand($this->_bgColorRedMin, $this->_bgColorRedMax);
		$bgColorGreen   = mt_rand($this->_bgColorGreenMin, $this->_bgColorGreenMax);
		$bgColorBlue    = mt_rand($this->_bgColorBlueMin, $this->_bgColorBlueMax);

		// 创建图像载体
		$image = imageCreate($this->_imageWidth, $this->_imageHeight);
		ImageColorAllocate($image, $bgColorRed, $bgColorGreen, $bgColorBlue);

		// 设置字符的宽度
		$letterWidth = round($this->_imageWidth / $this->_authLength);

		// 加入干扰素
		for ($i = 1; $i <= $this->_pixelNumber; $i++) {
			//随机生成干扰素颜色
			$pixelColorRed  = mt_rand($this->_pixelColorRedMin, $this->_pixelColorRedMax);
			$pixelColorGreen= mt_rand($this->_pixelColorGreenMin, $this->_pixelColorGreenMax);
			$pixelColorBlue = mt_rand($this->_pixelColorBlueMin, $this->_pixelColorBlueMax);

//			imageString($image,
//				1,
//				mt_rand(1, $this->_imageWidth),
//				mt_rand(1, $this->_imageHeight),
//				"*",
//				imageColorAllocate($image, $pixelColorRed, $pixelColorGreen, $pixelColorBlue));
			//也可用上面一行来加入一些与背景色相近的size=1的"*"字符来达到干扰效果

			imagesetpixel($image,
				rand() % $this->_imageWidth ,
				rand() % $this->_imageHeight ,
				ImageColorAllocate($image, $pixelColorRed, $pixelColorGreen, $pixelColorBlue));
		}

		// 写入验证码
		for ($i = 0; $i < $this->_authLength; $i++) {
			$fontSize       = mt_rand($this->_fontSizeMin, $this->_fontSizeMax);

			// 随机生成字体颜色
			$fontColorRed   = mt_rand($this->_fontColorRedMin, $this->_fontColorRedMax);
			$fontColorGreen = mt_rand($this->_fontColorGreenMin, $this->_fontColorGreenMax);
			$fontColorBlue  = mt_rand($this->_fontColorBlueMin, $this->_fontColorBlueMax);

			imageString($image,
				$fontSize,
				$i * $letterWidth + $letterWidth / 2 - 5 + mt_rand(0, 4),
				mt_rand(1, $this->_imageHeight/4),
				$auth[$i],
				imageColorAllocate($image, $fontColorRed, $fontColorGreen, $fontColorBlue));
		}

		// 创建并输出图像
		header("Content-type: image/png");
		ImagePng($image);
		ImageDestroy($image);
	}

	/**
	 * 取得下一个验证码的键值
	 *
	 * @return int (下一个验证码的键值)
	 */
	public static function getSessionSn()
	{
		//不存在或者为空
		if (empty($_SESSION[self::$authCodeSessionKey])) {
			return 1;
		}

		//取得最后一个SESSION的键
		end($_SESSION[self::$authCodeSessionKey]);
		$lastKey = key($_SESSION[self::$authCodeSessionKey]);

		//返回分配的新键
		return ++ $lastKey;
	}

}

?>