<?php

class Jcan_Config
{
	public static $imageMimeTypes = array
				(
				'image/gif'	=> 'gif',
				'image/png'	=> 'png',
				'image/x-png'	=> 'png',
				'image/jpg'	=> 'jpg',
				'image/jpeg'	=> 'jpg',
				'image/pjpeg'	=> 'jpg',
				'image/bmp'	=> 'bmp'
				);
	public static $null = '<em>null</em>';

	public static function init()
	{
	}
}
