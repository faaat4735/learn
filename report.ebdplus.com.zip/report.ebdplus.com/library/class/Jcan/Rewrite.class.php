<?php

class Jcan_Rewrite
{
	//Rewrite Mode
	const REWRITE_MODE_OFF = 0;
	const REWRITE_MODE_PATHINFO = 1;
	const REWRITE_MODE_URLREWRITE = 2;

	//分隔符, 不可为"/"
	public static $uriDelimiter = '-';
	//URL忽略的扩展名
	public static $extensions = array('.html', '.htm', '.wml', '.wap');
	//
	public static $channels = array('Admin');

	/**
	 * 根据rewriteMode执行URL重写
	 *
	 * @param const $rewriteMode 有三种可选模式: REWRITE_MODE_URLREWRITE(默认), REWRITE_MODE_OFF, REWRITE_MODE_PATHINFO
	 */
	public static function run($rewriteMode = REWRITE_MODE_URLREWRITE)
	{
		//关闭重写模式
		if ($rewriteMode === self::REWRITE_MODE_OFF) return;

		//CLI mode
		if (PHP_SAPI == 'cli') return false;

		//pathinfo重写模式(解析_SERVER['PATH_INFO'])
		if ($rewriteMode === self::REWRITE_MODE_PATHINFO) {
			if (empty($_SERVER['PATH_INFO'])) return;
			$redirectUrl = $_SERVER['PATH_INFO'];
		}
		//URL rewrite重写模式(解析_SERVER['REDIRECT_URL']
		else {
			//cgi模式
			if (stripos(PHP_SAPI, 'cgi') !== false) {
				if (!isset($_SERVER['REQUEST_URI'])) return;
				$_arr = explode('?', $_SERVER['REQUEST_URI']);
				$redirectUrl = urldecode($_arr[0]);
			}
			//apache模式
			else {
				//基于_SERVER['REDIRECT_URL']进行rewrite
				if (empty($_SERVER['REDIRECT_URL'])) return;
				$redirectUrl = $_SERVER['REDIRECT_URL'];
			}
		}

		//判断URL是否有扩展名
		$hasExtension = false;
		if (self::$extensions) {
			$_extensionReg = (array)self::$extensions;
			array_walk($_extensionReg, create_function('&$item,$key,$delimiter', '$item = preg_quote($item, $delimiter) . "$";'), '/');
			$_extensionReg = implode('|', $_extensionReg);
			if (preg_match('/' . $_extensionReg . '/iu', $redirectUrl)) {
				$hasExtension = true;
			}
		}

		//去除URL中的ROOT_URL部分的正则
		$_rootUrlReg = '^' . preg_quote(ROOT_URL, '/');

		//去除URL中的ROOT_URL及扩展名部分
		$_extensionReg = $_extensionReg ? $_extensionReg . '|\/$' : '\/$';
		$_replaceReg = "/{$_rootUrlReg}|{$_extensionReg}/iu";
		$redirectUrl = preg_replace($_replaceReg, '', $redirectUrl);

		/**
		 *  把 admin/news/item-3.html => admin-news/item-3.html 形式)
		 */
		//$redirectUrl = preg_replace('/^admin\//iu', 'admin' . self::$uriDelimiter, $redirectUrl);

		//controls & params
		$_arr = explode('/', $redirectUrl, 2);


		//is Channel
		$_channel = ucfirst($_arr[0]);
		if (in_array($_channel, self::$channels)) {
			$_REQUEST['_channel'] = $_GET['_channel'] = $_channel;
			$redirectUrl = isset($_arr[1]) ? $_arr[1] : '';
			$_arr = explode('/', $redirectUrl, 2);
		}

		//_module & _action & _op
		if (!empty($_arr[0])) {
			$controls = explode(self::$uriDelimiter, $_arr[0], 4);

			//order.html或者channel/order.html这种情况将把order视为action
			if (count($_arr) == 1 && count($controls) == 1 && $hasExtension) {
				$_REQUEST['_action'] = $_GET['_action'] = $controls[0];
			}
			else {
				if (!empty($controls[0])) {
					$_REQUEST['_module'] = $_GET['_module'] = ucfirst($controls[0]);
				}
				if (!empty($controls[1])) {
					$controls[1][0] = strtolower($controls[1][0]);
					$_REQUEST['_action'] = $_GET['_action'] = $controls[1];
				}
				if (!empty($controls[2])) {
					$_REQUEST['_op'] = $_GET['_op'] = $controls[2];
				}
			}
		}

		//params
		if (!empty($_arr[1])) {
			$queryStr = str_replace('/', self::$uriDelimiter, $_arr[1]) . self::$uriDelimiter . self::$uriDelimiter;
			$cnt = substr_count($queryStr, self::$uriDelimiter);
			if ($cnt % 2 == 0) {
				$queryStr = '_token' . self::$uriDelimiter . $queryStr;
			}

			$uriDelimiterReg = preg_quote(self::$uriDelimiter, '/');
			$queryStr = preg_replace("/(.*){$uriDelimiterReg}(.*){$uriDelimiterReg}/Uu", '$1=$2&', $queryStr);
			$queryStr = preg_replace("/{$uriDelimiterReg}$/u", '', $queryStr);
			parse_str($queryStr, $_arr);
			$_GET += $_arr;
			$_REQUEST += $_arr;
			unset($_arr);
		}

		//Jcan::dump($_GET);
	}
}