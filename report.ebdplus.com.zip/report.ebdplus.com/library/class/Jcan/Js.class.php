<?php
/**
 * @author Jcan
 */
class Jcan_Js
{
	/**
	 * JavaScript跳转, 包括对父窗口的操作
	 * @desc    operate可选参数有以下四种:
	 *          1. 数字n, 表示history.go(n)
	 *          2. [back, close, reload, redirect, stop]
	 *          3. [back_self, close_self, reload_self, redirect_self
	 *          4. [back_parent, close_parent, reload_parent, redirect_parent]
	 *          5. [back_top, close_top, reload_top, redirect_top]
	 *          5. 3与4的任意组合,   3,4,5总是以下划线相连, 且3在前4,5在后
	 * @author  Jcan
	 * @param   String|Interger $operate
	 * @param   String $url
	 */
	public static function redirect($operate = null, $url = null)
	{
		// 如果operate为空则直接返回
		if ($operate == null) return;

		// 设置script标准标签
		$jsOpenTag = '<script type="text/javascript">';
		$jsCloseTag = '</script>';

		// 如果 $operate==stop || $operate==stop_self 直接返回,脚本停止执行
		if ($operate == 'stop' || $operate == 'stop_self') exit;

		// 如果 $operate 是数字则调用 history.go($operate)
		if (is_numeric($operate)) {
			$history_go = 'history.go(' . $operate . ')';
			echo $jsOpenTag, $history_go, $jsCloseTag;
			exit;
		}

		// 规范$operate字符串
		if ($operate == 'back') $operate = 'back_self';
		if ($operate == 'close') $operate = 'close_self';
		if ($operate == 'reload') $operate = 'reload_self';
		if ($operate == 'redirect') $operate = 'redirect_self';


		// 以下变量保存操作父窗口的javascript语句
		$back_parent = '';
		$close_parent = '';
		$reload_parent = '';
		$redirect_parent = '';

		if (stripos($operate, 'back_parent') !== false) {
			$back_parent = 'window.opener.history.back();';
		} elseif (stripos($operate, 'close_parent') !== false) {
			$close_parent = 'window.opener.opener = null; window.opener.close();';
		} elseif (stripos($operate, 'reload_parent') !== false) {
			$reload_parent = 'window.opener.location.reload();';
		} elseif (stripos($operate, 'redirect_parent') !== false) {
			$redirect_parent = 'window.opener.location.href = "' . $url . '";';
		}

		// 以下变量保存操作本窗口的javascript语句
		$back_self = '';
		$close_self = '';
		$reload_self = '';
		$redirect_self = '';

		if (stripos($operate, 'back_self') !== false) {
			$back_self = 'history.back();';
		} elseif (stripos($operate, 'close_self') !== false) {
			$close_self = 'window.opener = null; window.close();';
		} elseif (stripos($operate, 'reload_self') !== false) {
			$reload_self = 'window.location.reload()';
		} elseif (stripos($operate, 'redirect_self') !== false) {
			$redirect_self = 'window.location.href = "' . $url . '";';
		}

		// 以下变量保存操作顶窗口的javascript语句
		// version 0.1
		$back_top = '';
		$close_top = '';
		$reload_top = '';
		$redirect_top = '';

		if (stripos($operate, 'back_top') !== false) {
			$back_top = 'window.top.history.back();';
		} elseif (stripos($operate, 'close_top') !== false) {
			$close_top = 'window.opener = null; window.top.close();';
		} elseif (stripos($operate, 'reload_top') !== false) {
			$reload_top = 'window.top.location.reload()';
		} elseif (stripos($operate, 'redirect_top') !== false) {
			$redirect_top = 'window.top.location = "' . $url . '";';
		}

		// javascript content
		$jsData = $back_parent . $close_parent . $reload_parent . $redirect_parent
			. $back_self . $close_self . $reload_self . $redirect_self
			. $back_top . $close_top . $reload_top . $redirect_top;

		echo $jsOpenTag, $jsData, $jsCloseTag;
		exit;
	}


	/**
	 * 弹出javascript警告并对子窗口与父窗口进行操作
	 *
	 * @author  Jcan
	 * @param   String $msg
	 * @param   String|Integer $operate 参数见self::jsRedirect()
	 * @param   String $url
	 */
	public static function msg($msg, $operate = null, $url = null)
	{
		if ($msg) {
			$msg = addcslashes($msg, "'\"\n/\\");
			printf('<script type="text/javascript">alert("%s"); </script>', $msg);
		}
		self::redirect($operate, $url);
	}
}
