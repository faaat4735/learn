<?php

/**
 * @example
 *	if (_FAILURE_ !== ($rows = $cache->read('fields/xx/yy', 5, null))) {
 *		Jcan::dump($rows, 'read cache');
 *	}
 *	else {
 *		$rows = $db->getAll("SELECT * FROM t");
 *		Jcan::dump($rows, 'read db');
 *
 *		$cache->write($rows);
 *	}
 */
interface Jcan_Cache_Interface
{
	public function __construct($cacheDir = CACHE_DIR);
	public function read($cacheId, $ttl = -1, $token = '');
	public function write($cache);
	public function clear($cacheId = null, $token = null);
	public function reset();
}