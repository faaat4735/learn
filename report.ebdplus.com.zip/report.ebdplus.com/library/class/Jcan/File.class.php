<?php

class Jcan_File
{
	/**
	 * delete file
	 *
	 * @param string $file
	 * @param int $exp_time
	 * @return bool
	 */
	public static function unlink($file, $exp_time = null)
	{
		$retval = true;

		if (isset($exp_time)) {
			if(time() - @filemtime($file) >= $exp_time) {
				$retval = @unlink($file);
			}
		} else {
			$retval = @unlink($file);
		}

		return (bool)$retval;
	}

	/**
 	 * delete a dir recursively (rm_root=false -> keep root)
	 *
	 * @param string $dirname
	 * @param int $rm_root  rm_root=false -> keep root
	 * @param int $exp_time
	 * @return bool
	 */
	public static function rmdir($dirname, $rm_root = true, $exp_time = null)
	{
		$dirname = rtrim($dirname, '/\\');

		if ($_handle = @opendir($dirname)) {

			while (false !== ($_entry = readdir($_handle))) {
				if ($_entry != '.' && $_entry != '..') {
					$_name = $dirname . DIRECTORY_SEPARATOR . $_entry;

					if (@is_dir($_name)) {
						self::rmdir($_name, true, $exp_time);
					} else {
						self::unlink($_name, $exp_time);
					}
				}
			}
			closedir($_handle);
		}

		if ($rm_root) {
			return @rmdir($dirname);
		}
		return (bool)$_handle;
	}

	/**
	 * write file
	 *
	 * @param string $filename
	 * @param string $content
	 * @param bool $create_dirs
	 *
	 * @see smarty_core_write_file()
	 */
	public static function write($filename, $content, $create_dirs = true)
	{
		$_dirname = dirname($filename);

		if ($create_dirs && !is_dir($_dirname)) {
			if (!@mkdir($_dirname, 0644, true)) return false;
		}

		// write to tmp file, then rename it to avoid file locking race condition
		$_tmp_file = tempnam($_dirname, 'wrt');
		if (!($handle = @fopen($_tmp_file, 'wb'))) {
			$_tmp_file = $_dirname . DIRECTORY_SEPARATOR . uniqid();
			if (!($handle = @fopen($_tmp_file, 'wb'))) {
				return false;
			}
		}

		fwrite($handle, $content);
		fclose($handle);

		if (DIRECTORY_SEPARATOR == '\\' || !@rename($_tmp_file, $filename)) {
			// On platforms and filesystems that cannot overwrite with rename()
			// delete the file before renaming it -- because windows always suffers
			// this, it is short-circuited to avoid the initial rename() attempt
			@unlink($filename);
			@rename($_tmp_file, $filename);
		}
		@chmod($filename, 0644);

		return true;
	}
}