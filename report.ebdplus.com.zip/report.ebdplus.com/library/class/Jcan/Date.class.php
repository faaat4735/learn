<?php

/**
 * @author Jcan.Zhong [at] gmail.com
 */
class Jcan_Date
{
	/**
	 * get begin and end of a week
	 *
	 * @param string|int $time (optional)
	 * @param int $first (optional) 1=> monday
	 * @return array
	 * @see Jcan_Date::amonth()
	 * @example
	 * 	Jcan_Date::aweek('2009-05-07 22:23') => array(strtotime('2009-05-04'), strtotime('2009-05-10'))
	 */
	public static function aweek($time = null, $first = 1)
	{
		if ($time) {
			if (!is_numeric($time)) {
				$time = strtotime($time);
			}
		} else {
			$time = time();
		}

		$day = date('w', $time);
		$dn = $day ? $day - $first : 6;
		$st = strtotime("- $dn days", $time);
		$en = strtotime("+6 days", $st);
		return array($st, $en);
	}

	/**
	 * get begin and end of a month
	 *
	 * @param string|int $time
	 * @return array
	 */
	public static function amonth($time = null)
	{
		if ($time) {
			if (!is_numeric($time)) {
				$time = strtotime($time);
			}
		} else {
			$time = time();
		}

		$from = strtotime(date('Y-m-01', $time));
		$to = strtotime('+1 month -1 day', $from);
		return array($from, $to);
	}

	/**
	 * get begin and end of a year
	 *
	 * @param string|int $time
	 * @return array
	 */
	public static function ayear($time = null)
	{
		if ($time) {
			if (!is_numeric($time)) {
				$time = strtotime($time);
			}
		} else {
			$time = time();
		}

		$from = strtotime(date('Y-01-01', $time));
		$to = strtotime('+1 year -1 day', $from);
		return array($from, $to);
	}

	/**
	 * get date array from $from to $to
	 *
	 * @param string|int $from
	 * @param string|int $to
	 * @param string|null $format (optional)
	 * @return array
	 * @see Jcan_Date::getWeeks()
	 * @see Jcan_Date::getMonths()
	 * @example
	 * 	Jcan_Date::getDates('2009/05/07', '2009-08-09 22:10:09', 'Y/m/d')
	 * 	Jcan_Date::getDates(1241688695, '2009/08/09 22:10', null)
	 */
	public static function getDates($from, $to, $format = 'Y-m-d')
	{
		// to timestamp
		if (!is_numeric($from)) {
			$from = strtotime($from);
		}

		// to timestamp
		if (!is_numeric($to)) {
			$to = strtotime($to);
		}

		// $to must bigger than $from
		if ($from > $to) {
			return array();
		}

		// return
		$retval = array();
		$dateTo = date($format, $to);
		while (true) {
			$dateFrom = date($format, $from);
			$retval[] = $dateFrom;

			if ($dateFrom >= $dateTo) {
				break;
			}
			$from = strtotime('+1 day', $from);
		}
		return $retval;
	}

	/**
	 * get week array from $from to $to
	 *
	 * @param string|int $from
	 * @param string|int $to
	 * @param string $format (optional)
	 * @return array
	 * @see Jcan_Date::getDates()
	 * @see Jcan_Date::getMonths()
	 */
	public static function getWeeks($from, $to, $format = 'oW')
	{
		// to timestamp
		if (!is_numeric($from)) {
			$from = strtotime($from);
		}

		// to timestamp
		if (!is_numeric($to)) {
			$to = strtotime($to);
		}

		// $to must bigger than $from
		if ($from > $to) {
			return array();
		}

		// return
		$retval = array();
		$dateTo = date($format, $to);
		while (true) {
			$dateFrom = date($format, $from);
			$retval[] = $dateFrom;

			if ($dateFrom >= $dateTo) {
				break;
			}
			$from = strtotime('+1 week', $from);
		}
		return $retval;
	}

	/**
	 * get month array from $from to $to
	 *
	 * @param string|int $from
	 * @param string|int $to
	 * @param string $format (optional)
	 * @return array
	 * @see Jcan_Date::getDates()
	 * @see Jcan_Date::getWeeks()
	 */
	public static function getMonths($from, $to, $format = 'Ym')
	{
		// to timestamp
		if (!is_numeric($from)) {
			$from = strtotime($from);
		}

		// to timestamp
		if (!is_numeric($to)) {
			$to = strtotime($to);
		}

		// $to must bigger than $from
		if ($from > $to) {
			return array();
		}

		// return
		$retval = array();
		$monthTo = date($format, $to);
		while (true) {
			// format='Ym' is same with EXTRACT(YEAR_MONTH FROM date) of MySQL
			$monthFrom = date($format, $from);
			$retval[] = $monthFrom;

			if ($monthFrom >= $monthTo) {
				break;
			}
			$from = strtotime('+1 month', $from);
		}
		return $retval;
	}

	/**
	 * get year array from $from to $to
	 *
	 * @param string|int $from
	 * @param string|int $to
	 * @param string $format (optional)
	 * @return array
	 * @see Jcan_Date::getDates()
	 * @see Jcan_Date::getWeeks()
	 * @see Jcan_Date::getMonths()
	 */
	public static function getYears($from, $to, $format = 'Y')
	{
		// to timestamp
		if (!is_numeric($from)) {
			$from = strtotime($from);
		}

		// to timestamp
		if (!is_numeric($to)) {
			$to = strtotime($to);
		}

		// $to must bigger than $from
		if ($from > $to) {
			return array();
		}

		// return
		$retval = array();
		$yearTo = date($format, $to);
		while (true) {
			// format='Ym' is same with EXTRACT(YEAR_MONTH FROM date) of MySQL
			$yearFrom = date($format, $from);
			$retval[] = $yearFrom;

			if ($yearFrom >= $yearTo) {
				break;
			}
			$from = strtotime('+1 year', $from);
		}
		return $retval;
	}
}
