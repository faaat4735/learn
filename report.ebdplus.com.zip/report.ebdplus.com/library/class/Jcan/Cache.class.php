<?php

class Jcan_Cache implements Jcan_Cache_Interface
{
	protected $_cacheDir;
	protected $_cacheId;
	protected $_ttl;
	protected $_cacheFile;

	public function __construct($cacheDir = CACHE_DIR)
	{
		$this->_cacheDir = $cacheDir;
	}

	public function read($cacheId, $ttl = -1, $token = '')
	{
		$this->_setCache($cacheId, $ttl, $token);

		if (!$this->_isCached()) return _FAILURE_;

		$cache = file_get_contents($this->_cacheFile);
		$retval = @unserialize($cache);
		if ($retval === false && $cache !== 'b:0;') {
			return _FAILURE_;
		}

		return $retval;
	}

	public function write($cache)
	{
		$cache = serialize($cache);
		$bool = Jcan_File::write($this->_cacheFile, $cache, true);
		$this->reset();
		return $bool;
	}

	public function clear($cacheId = null, $token = null)
	{
		$path = $this->_getCachePath($cacheId);

		if (!is_null($token)) {
			$cacheName = $this->_getCacheName($token);
			return Jcan_File::unlink($path . $cacheName);
		}

		return Jcan_File::rmdir($path, $path != $this->_cacheDir);
	}

	public function reset()
	{
		$this->_ttl = 0;
	}



	/**
	 * 设置cache相关参数
	 *
	 * @param string $cacheId
	 * @param int $ttl
	 * @param mixed $token
	 * @return bool
	 */
	protected function _setCache($cacheId, $ttl = -1, $token = '')
	{
		$this->_cacheId = $cacheId;
		$this->_ttl = $ttl;

		$path = $this->_getCachePath($cacheId);
		$cacheName = $this->_getCacheName($token);
		$this->_cacheFile = $path . $cacheName;

		return true;
	}

	protected function _isCached()
	{
		if (!$this->_ttl) return false;

		if (!file_exists($this->_cacheFile)) {
			return false;
		}

		if ($this->_ttl != -1 && time() - @filemtime($this->_cacheFile) > $this->_ttl) {
			return false;
		}

		return true;
	}

	protected function _getCachePath($cacheId = null)
	{
		if (!isset($cacheId) || !preg_match('/^[a-z0-9\_\-]+\/?[a-z0-0\_\-]+$/i', $cacheId)) {
			return $this->_cacheDir;
		}

		if (DIRECTORY_SEPARATOR == '\\') {
			$cacheId = str_replace('/', DIRECTORY_SEPARATOR, $cacheId);
		}
		return $this->_cacheDir . $cacheId . DIRECTORY_SEPARATOR;
	}

	protected function _getCacheName($token)
	{
		if (empty($token)) $token = '';
		return Jcan_Encrypt::md5_8(serialize($token)) . '.c';
	}
}