<?php

class Jcan_Filter
{
	/**
	 * 把varTo引用到varFrom; 如果不存在varFrom,则设varTo=null
	 * 如果不存在varFrom返回false,否则返回true
	 * @example self::ref($_GET['username'], $username, null)
	 * @param mixed $varFrom
	 * @param mixed $varTo
	 * @param string[optional=trim] $callback (可为null, trim, ltrim, rtrim等)
	 * @param mixed[optional=null] $default (如果$varFrom为空,default is not null,则返回$default值)
	 * @return bool  return isset($varFrom)
	 */
	public static function ref(&$varFrom, &$varTo, $callback='trim', $default=null)
	{
		if (!isset($varFrom)) {
			$varTo = $default;
			return false;
		}

		if (empty($callback) || (!is_string($varFrom) && !is_numeric($varFrom) && $callback == 'trim')) {
			$varTo = $varFrom;
		} else {
			$varTo = call_user_func($callback, $varFrom);
		}

		if (isset($default)) {
			if (empty($varTo)) {
				$varTo = $default;
			}
		}
		return true;
	}

	/**
	 * @param string $varName
	 * @return string
	 * @example
	 * 	self::getRefEvalCode('_POST', 'username', 'passwd', 'email', 'tel', 'address');
	 * 	self::getRefEvalCode('_POST', array('username', 'passwd', 'email', 'tel', 'address'));
	 */
	public static function getRefEvalCode($varName)
	{
		$params = func_get_args();
		array_shift($params);

		if (is_array($params[0])) {
			$params = $params[0];
		}

		$code = '';
		foreach ($params as $key) {
//			$code .= "Jcan_Filter::ref(\${$varName}['{$key}'], \${$key});\n";
			$code .= "\${$key} =& \${$varName}['{$key}'];\n";
		}

		return $code;
	}

	/**
	 * 规范变量
	 *
	 * @param mixed $var
	 * @param mixed $scope
	 * @param string $func
	 * @param mixed $_default
	 * @return void
	 * @example self::fix($var, array('aa','bb','cc'), 'array_key_exists', null)
	 */
	public static function fix(&$var, $scope, $func = 'in_array')
	{
		$nArg = func_num_args();

		if (!call_user_func($func, $var, $scope)) {

			//没有设置第四个参数
			if ($nArg < 4) {
				if (empty($scope)) {
					$var = null;
					return;
				}

				if ($func == 'in_array') {
					reset($scope);
					$var = current($scope);
					return;
				}
				elseif ($func == 'array_key_exists') {
					reset($scope);
					$var = key($scope);
					return;
				}
				else {
					return null;
				}
			}

			//设置第四个参数
			$var = func_get_arg(3);
		}
	}
}