<?php
class GoogleAnalytics
{
    /**
     * OAuth 2.0
     */
    protected $client;
    protected $ga;
    protected $profileId = '2804976';

    public function __construct($profileId = false)
    {
        require_once INC_DIR . 'Google/autoload.php';

        $email = '175764474781-bas7s3g54h0ga1q0gln1gd9kq3r1mtj9@developer.gserviceaccount.com';
        $keyFileLoc = INC_DIR . 'Google/ebd_client_secrets.p12';

        if ($profileId) {
            $this->profileId = $profileId;
        }

        // Configure a new client object.
        $this->client = new \Google_Client();
        $this->ga = new \Google_Service_Analytics($this->client);

        // Read the generated client_secrets.p12 key.
        $key = file_get_contents($keyFileLoc);
        $cred = new Google_Auth_AssertionCredentials(
            $email,
            array(Google_Service_Analytics::ANALYTICS_READONLY),
            $key
        );
        $this->client->setAssertionCredentials($cred);
        if($this->client->getAuth()->isAccessTokenExpired()) {
          $this->client->getAuth()->refreshTokenWithAssertion($cred);
        }
    }

	public function getReport($startTime, $endTime, $dimensions = 'date', $metrics = 'visitors', $filter = '', $sortMetric = '')
    {
        $startTime = date('Y-m-d', strtotime($startTime));
        $endTime = date('Y-m-d', strtotime($endTime));

        if (!is_array($dimensions) && $dimensions !== null) {
            $dimensions = array($dimensions);
        }

        $params = array();
        foreach ($dimensions as $dimesion) {
            switch ($dimesion) {
                case 'week':
                    $params[] = 'ga:yearWeek';
                    break;
                case 'month':
                    $params[] = 'ga:yearMonth';
                    break;
                case 'year':
                    $params[] = 'ga:year';
                    break;
                default :
                    $params[] = 'ga:'.$dimesion;
            }
        }
        $optParams['dimensions'] = implode(',', $params);

        if (is_array($metrics)) {
            $params = array();
            foreach ($metrics as $metric) {
                $params[] = 'ga:' . $metric;
            }
            $optMetrics = implode(',', $params);
        } else {
            $optMetrics = 'ga:'.$metrics;
            $metrics = array($metrics);
        }

        if ($sortMetric==null&&isset($optMetrics)) {
            $optParams['sort'] = $optMetrics;
        } elseif (is_array($sortMetric)) {
            $sorts = array();
            foreach ($sortMetric as $sort) {
              //Reverse sort - Thanks Nick Sullivan
              if (substr($sort, 0, 1) == "-") {
                $sorts[] = '-ga:' . substr($sort, 1); // Descending
              }
              else {
                $sorts[] = 'ga:' . $sort; // Ascending
              }
            }

            $optParams['sort'] = implode(',', $sorts);
        } else {
            if (substr($optMetrics, 0, 1) == "-") {
              $optParams['sort'] = '-ga:' . substr($optMetrics, 1);
            } else {
              $optParams['sort'] = 'ga:' . $optMetrics;
            }
        }

        if ($filter!=null) {
            $filter = $this->processFilter($filter);
            if ($filter!==false) {
              $optParams['filters'] = $filter;
            }
        }

        try {
            $results = $this->ga->data_ga->get('ga:' . $this->profileId, $startTime, $endTime, $optMetrics, $optParams);
        } catch (\Google_ServiceException $e) {
            $error = $e->getMessage();
            throw new \Exception($error);
        } catch (\Google_IOException $e) {
            $error = $e->getMessage();
            throw new \Exception($error);
        }
        $data = $results->getRows();

        return $data;
    }


    /**
   * Process filter string, clean parameters and convert to Google Analytics
   * compatible format
   *
   * @param String $filter
   * @return String Compatible filter string
   */
    protected function processFilter($filter) {
      $valid_operators = '(!~|=~|==|!=|>|<|>=|<=|=@|!@)';

      $filter = preg_replace('/\s\s+/', ' ', trim($filter)); //Clean duplicate whitespace
      $filter = str_replace(array(',', ';'), array('\,', '\;'), $filter); //Escape Google Analytics reserved characters
      $filter = preg_replace('/(&&\s*|\|\|\s*|^)([a-z]+)(\s*' . $valid_operators . ')/i','$1ga:$2$3',$filter); //Prefix ga: to metrics and dimensions
      $filter = preg_replace('/[\'\"]/i', '', $filter); //Clear invalid quote characters
      $filter = preg_replace(array('/\s*&&\s*/','/\s*\|\|\s*/','/\s*' . $valid_operators . '\s*/'), array(';', ',', '$1'), $filter); //Clean up operators

      if (strlen($filter) > 0) {
        return urlencode($filter);
      }
      else {
        return false;
      }
    }
}
