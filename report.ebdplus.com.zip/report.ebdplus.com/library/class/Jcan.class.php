<?php

/**
 * 静态类, 常用函数集
 *
 * @author Jcan
 */
class Jcan
{
	/**
	 * framework version
	 */
	const VERSION = '2.0.2';

	/**
	 * Compare the specified framework version string $version
	 * with the current Jcan::VERSION of the framework.
	 *
	 * @param  string  $version  A version string (e.g. "0.7.1").
	 * @return boolean -1 if the $version is older,
	 *                 0 if they are the same,
	 *                 and +1 if $version is newer.
	 *
	 */
	public static function compareVersion($version)
	{
		return version_compare($version, self::VERSION);
	}

	/**
	 * Jcan_Debug::dump shortcut
	 */
	public static function dump($var, $label=null, $echo=true)
	{
		return Jcan_Debug::dump($var, $label, $echo);
	}

	/**
	 * Jcan_Debug::printr shortcut
	 */
	public static function printr($var, $label=null, $echo=true)
	{
		return Jcan_Debug::printr($var, $label, $echo);
	}

	/**
	 * Jcan_Debug::export shortcut
	 */
	public static function export($var, $label=null, $echo=true)
	{
		return Jcan_Debug::export($var, $label, $echo);
	}
}