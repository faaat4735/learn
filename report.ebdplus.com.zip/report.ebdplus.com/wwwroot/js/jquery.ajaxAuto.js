/**
 * 封装 $.ajaxUpload
 */
$.fn.ajaxUpload = function(options)
{
	var settings = {
		dataType : 'json',
		uploadform : this[0],
		url : this[0].action
	};
	$.extend(settings, options || {});

	if (settings.url) {
		settings.url = settings.url.concatQuery('__ajax=1');
	}
	$.requirePlugin($.ajaxUpload, 'jquery.ajaxUpload.js', function(){
		$.ajaxUpload(settings);
	});
	return this;
};

/**
 * 返回值类型为json的ajax接口(内部函数)
 * @param json data
 * @param callback cb
 *
 *	服务器端返回格式：
 *		$retval = array(
 *			'status'	=> ok | error | other..
 *			'msg'		=> string
 *			'redirect'	=> reload | referer | back | http://xxx
 *			'delay'		=> 2000
 *		);
 *		exit( json_encode($retval) );
 */
$._ajaxJsonInterface = function(data, cb)
{
	//settings
	var settings = {
		delay : 1000
	};

	//无返回状态(异常)
	if (typeof data.status == 'undefined') {
		cb && cb.call(null, data);
		return;
	}

	//sign
	var sign = 0;

	//status分支
	switch (data.status) {
		//ok状态
		case 'ok':
		//error状态
		case 'error':

			//转向
			if (data.redirect != undefined) {

				//redirect
				var redirect = function(){
					switch (data.redirect) {
						case 'reload':
							window.location = window.location.href;
							break;
						case 'referer':
							if (document.referrer) {
								window.location = document.referrer;
							} else {
								history.go(-1);
							}
							break;
						case 'back':
							history.go(-1);
							break;
						default:
							window.location = data.redirect;
							break;
					}
				};

				//延迟转向
				if (data.msg != undefined) {
					var delay = data.delay == undefined ? settings.delay : data.delay;

					if (delay == 0) {
						$.layer.timer = 1;
						$.alert(data.msg, redirect);
					} else {
						$.quickMsg(data.msg, null, 9999999);
						setTimeout(redirect, data.delay || settings.delay);
					}
				}
				//立即转向
				else {
					redirect();
				}
			}

			//不转向
			else {
				//显示消息
				if (data.msg) {
					if ($.layer.cache) {
						$('#jqMsg > *').eq(0).autoTip(data.msg);
					} else {
						if (data.status == 'error') {
							$.layer.timer = 1;
							$.alert(data.msg);
						} else {
							$.quickMsg(data.msg, null, data.delay || settings.delay);
						}
					}
				}
			}
			sign = 1;

		//其它状态(用户自定义)
		default:
			if (!$.isFunction(cb) || cb.call(null, data) === false) {
				if (sign == 0) $.alert('Unknow action: ' + data.status);
			}
			break;
	}
};

/**
 * @param ajaxSettings options
 * @param callback cb
 * @example
 *	1.
 *	$.ajaxJson(function(json){
 *		switch (json.status){
 *		}
 *	});
 *
 *	2.
 *	$.ajaxJson({
 *		url : 'test.php',
 *		data : 'user=jcan&passwd=123',
 *		type : 'POST'
 *	}, function(json){
 *		switch (json.status) {
 *			'username is null':
 *				$.quickMsg('Username cannot null')
 *				$('[@name=username]').focus();
 *				break;
 *		}
 *	})
 */
$.ajaxJson = function(options, cb)
{
	if ($.isFunction(options)) {
		cb = options;
		options = {};
	}
	var settings = {
		dataType : 'json',
		global : $.layer.cache ? false : true,
		success : function(json) {
			$._ajaxJsonInterface(json, cb);

			//enable submit button
			$.layer.cache && $('#jqMsg button[type=submit]').removeAttr('disabled');
		}
	};

	$.extend(settings, options || {});
	$.ajax(settings);
};



$.fn._ajaxJsonUpload = function(options, cb)
{
	if ($.isFunction(options)) {
		cb = options;
		options = {};
	}
	var settings = {
		dataType : 'json',
		global : $.layer.cache ? false : true,
		success : function(json) {
			//uploadprogress timer
			$.uploadingFlag = false;
			if ($.uploadTimer) {
				clearTimeout($.uploadTimer);
			}
			$._ajaxJsonInterface(json, cb);

			//enable submit button
			$.layer.cache && $('button[type=submit]', this).removeAttr('disabled');
		}
	};
	$.extend(settings, options || {});

	if (settings.uploadprogressUrl) {
		var uid = $.uid();
		if ($('#UPLOAD_IDENTIFIER').length) {
			uid = $('#UPLOAD_IDENTIFIER').val();
		} else {
			this.prepend('<input type="hidden" name="UPLOAD_IDENTIFIER" id="UPLOAD_IDENTIFIER" value="' + uid + '" />');
		}
		settings.uploadprogressUrl = settings.uploadprogressUrl.replace('{id}', uid);

		settings.complete = function() {
			//uploadprogress timer
			$.uploadingFlag = false;
			if ($.uploadTimer) {
				clearTimeout($.uploadTimer);
			}
		};
	}

	$.uploadingFlag = true;
	this.ajaxUpload(settings);
	if (settings.uploadprogressUrl) {
		$.requirePlugin($.cycleUploadInfo, 'jquery.cycleUploadInfo.js', function(){
			if ($.uploadingFlag) $.cycleUploadInfo(settings.uploadprogressUrl);
		});
	}
	return this;
};


/**
 * @param ajaxSettings options
 * @param callback cb
 * @example
 *
 *	1.
 *	$('a#delete').ajaxAuto({
 *		data : 'user=jcan&passwd=123'
 *	}, function(json){
 *		switch (json.status) {
 *			case 'username is null':
 *				$.quickMsg('Username cannot null')
 *				$('[@name=username]').focus();
 *				break;
 *		}
 *	})
 *
 *	2.
 *	$('form#user').ajaxAuto(function(json){
 *		switch (json.status) {
 *			case 'username is null':
 *				$.quickMsg('Username cannot null')
 *				$('[@name=username]').focus();
 *				break;
 *		}
 *	})
 */
$.fn.ajaxAuto = function(options, cb)
{
	var tag = this[0].tagName.toLowerCase();

	if ($.isFunction(options)) {
		cb = options;
		options = {};
	}

	var settings;
	switch (tag) {
		case 'a':
			settings = {
				type : 'GET',
				url : this[0].href
			};
			break;

		case 'form':
			//disabled submit button
			$.layer.cache && $('button[type=submit]', this).attr('disabled', 'disabled');

			//upload
			if (this.attr('enctype') == 'multipart/form-data') {
				this._ajaxJsonUpload(options, cb);
				return this;
			}
			//!upload
			if (!$.fn.fastSerialize) {
				$.includeJs('jquery.serialize.js');
			}
			settings = {
				type : this.attr('method'),
				url : this.attr('action'),
				data : this.fastSerialize()
			};
			break;
	}
	$.extend(settings, options || {});
	$.ajaxJson(settings, cb);
	return this;
};