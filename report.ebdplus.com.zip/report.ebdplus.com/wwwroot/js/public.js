$(function(){
	$('#saveImgHandler').click(function(){
		this.href = 'data:image/png;base64,' + $('#mychart')[0].get_img_binary();
		this.target = '_blank';
	});

	$('input[name=from], input[name=to]').date_input();
});