<?php

//timezone
# date_default_timezone_set('UTC');

//request microtime
define('REQUEST_MICROTIME', microtime(true));

//added for proxy by Jcan - 2010.08.30
if (isset($_SERVER['HTTP_X_REAL_IP']) && preg_match('/^[\d\.]{7,15}$/', $_SERVER['HTTP_X_REAL_IP'])) {
	$_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_REAL_IP'];
}

//DS
if (!defined('DS')) {
	define('DS', DIRECTORY_SEPARATOR);
}



define('WWW_DIR',	dirname(__FILE__) . DS);
define('_ROOT_DIR',	realpath(WWW_DIR . '..') . DS);
define('APP_DIR',	_ROOT_DIR . 'approot' . DS);
define('LIB_DIR',	_ROOT_DIR . 'library' . DS);
//dirs
define('CLASS_DIR',	APP_DIR . 'class' . DS);
define('INC_DIR',	APP_DIR . 'includes' . DS);
define('TPL_DIR',	APP_DIR . 'tpl' . DS);
define('LOG_DIR',	APP_DIR . 'log' . DS);
define('CACHE_DIR',	APP_DIR . 'cache' . DS);

define('JS_DIR',	WWW_DIR . 'js' . DS);
define('CSS_DIR',	WWW_DIR . 'themes' . DS . 'default' . DS);
define('LIB_CLASS_DIR',	LIB_DIR . 'class' . DS);

/**
 * load the private configure
 */
if (file_exists(INC_DIR . 'config.private.php')) {
    include INC_DIR . "config.private.php";
}

//run enviorment
!defined('RUN_ENV') && define('RUN_ENV', 'local');

!defined('DB_DSN') &&  define('DB_DSN',	'mysql:host=192.168.0.8;dbname=ebd_main');
!defined('DB_USERNAME') &&  define('DB_USERNAME', 'ebd_dev');
!defined('DB_PASSWORD') &&  define('DB_PASSWORD', 'ebd');
!defined('DB_PCONNECT') &&  define('DB_PCONNECT', false);

!defined('DB_DSN2') &&  define('DB_DSN2', 'mysql:host=192.168.0.8;dbname=ebd_main');
!defined('DB_USERNAME2') &&  define('DB_USERNAME2',	'ebd_dev');
!defined('DB_PASSWORD2') &&  define('DB_PASSWORD2',	'ebd');
!defined('DB_PCONNECT2') &&  define('DB_PCONNECT2',	false);

// gapi
define('GA_EMAIL', 'dev@eyebuydirect.com');
define('GA_PASSWORD', 'eyebuydev');
define('GA_PROFILE_ID_US', '2804976');
define('GA_PROFILE_ID_AU', '72520323');
define('GA_PROFILE_ID_CA', '102262804');
define('GA_PROFILE_ID_FR', '102263507');
define('GA_PROFILE_ID_DE', '121909249');
define('GA_PROFILE_ID_GB', '124030531');

//DEBUG_MODE
define('DEBUG_MODE', RUN_ENV == 'local');

//LOG_ERROR
define('LOG_ERROR', !DEBUG_MODE);

//files
define('ERROR_LOG',	LOG_DIR . date('Y-m') . '.log');

//charset
define('PAGE_CHARSET',	'utf-8');
define('DB_CHARSET',	'utf8');

//ROOT_PATH
define('ROOT_PATH',	'/report/');


//auto load classes
function ebd_autoload($className)
{
	$classFileName = str_replace('_', DS, $className) . '.class.php';

	if (file_exists(CLASS_DIR . $classFileName)) {
		require_once CLASS_DIR . $classFileName;
	}

	elseif (file_exists(LIB_CLASS_DIR . $classFileName)) {
		require_once LIB_CLASS_DIR . $classFileName;
	}

	else {
		return false;
	}
}
spl_autoload_register('ebd_autoload');


//rewrite mode
define('REWRITE_MODE',	Jcan_Rewrite::REWRITE_MODE_URLREWRITE);
if (REWRITE_MODE == Jcan_Rewrite::REWRITE_MODE_PATHINFO) {
	define('ROOT_URL', ROOT_PATH . 'index.php/');
} else {
	define('ROOT_URL', ROOT_PATH);
}

//front-end constants
define('JS_URL',	ROOT_PATH . 'js/');
define('IMG_URL',	ROOT_PATH . 'images/');
define('THEMES_URL',	ROOT_PATH . 'themes/');
define('CSS_URL',	THEMES_URL . 'default/');

//set display_errors
ini_set('display_errors', DEBUG_MODE);
if (DEBUG_MODE) {
	error_reporting(E_ALL | E_STRICT);
}
if (LOG_ERROR) {
	ini_set('log_error', true);
	ini_set('error_log', ERROR_LOG);
}
