
NAGIOS will monitor it every serveral minutes.
Every page should response "Linux" text on linux server.