<?php

/**
 * Check PHP Status
 */
echo PHP_OS;