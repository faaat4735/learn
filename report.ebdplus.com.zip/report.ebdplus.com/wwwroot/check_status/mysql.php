<?php

/**
 * Check MySQL status
 */


define('DB_DSN',	'mysql:host=h1;dbname=ebd_blog;port=3307');
define('DB_USERNAME',	'www');
define('DB_PASSWORD',	'=ebd.pwd1');

$db = new PDO(DB_DSN, DB_USERNAME, DB_PASSWORD);
$sql = "SELECT COUNT(*) FROM wp_posts";
$cnt = $db->query($sql);
if (!empty($cnt)) {
	echo PHP_OS;
}