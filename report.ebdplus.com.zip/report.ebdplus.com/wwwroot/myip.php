<?php

if (isset($_GET['script'])) {
	echo "remoteIp = \"{$_SERVER['HTTP_X_REAL_IP']}\";";
}
else {
	echo $_SERVER['HTTP_X_REAL_IP'];
}
