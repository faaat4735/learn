<?php
require "./init.inc.php";

Jcan_Compat::magicQuotes();
Jcan_Rewrite::run(REWRITE_MODE);

//session start
session_start();

//send headers
header('Content-Type:text/html; charset=' . PAGE_CHARSET);

//initialize configuration
App_Config::init();

//get channel, module, action
$channel	=& $_GET['_channel'];
$module		=& $_GET['_module'];
$action		=& $_GET['_action'];

//instant template
$tpl = new App_Tpl();

//dispatch
var_dump($channel);exit;
$router = new App_Router($channel, $module, $action);

//Dispatch
$router->dispatch($tpl);

//echo microtime(true) - REQUEST_MICROTIME;