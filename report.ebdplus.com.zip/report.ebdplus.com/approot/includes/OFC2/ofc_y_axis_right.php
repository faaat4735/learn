<?php

class y_axis_right extends y_axis_base
{
	function y_axis_right(){}
}