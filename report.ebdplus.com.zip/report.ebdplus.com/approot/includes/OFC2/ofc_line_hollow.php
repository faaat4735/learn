<?php

class line_hollow extends line_base
{
	function line_hollow()
	{
		$this->type      = "line_hollow";
	}
}