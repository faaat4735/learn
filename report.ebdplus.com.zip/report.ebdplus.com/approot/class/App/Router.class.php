<?php

class App_Router extends Jcan_Router
{
	protected function _getModuleClassName($module)
	{
		if (empty($this->channel) || $this->channel == $this->_defaultChannel) {
			$className = 'App_Module_' . $module;
		} else {
			$className = 'App_Module_' . $this->channel . '_' . $module;
		}
		return $className;
	}
}