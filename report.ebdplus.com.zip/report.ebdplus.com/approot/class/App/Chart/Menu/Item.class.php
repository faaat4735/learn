<?php

class App_Chart_Menu_Item extends ofc_menu_item
{
	public function __construct($text, $javascript_function_name)
	{
		$this->{"background-colour"} = '#ffffff';
		$this->{"glow-colour"} = '#000099';
		$this->{"text-colour"} = '#0000dd';
		parent::ofc_menu_item($text, $javascript_function_name);
	}
}