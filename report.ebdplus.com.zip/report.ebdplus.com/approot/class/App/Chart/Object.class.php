<?php

class App_Chart_Object
{
	protected $_data = array();

	public static function toString($arr = null)
	{
		$o = new self($arr);
		return $o->_data;
	}

	public function __construct($arr = null)
	{
		if ($arr) {
			foreach ($arr as $key => $value) {
				$this->$key = $value;
			}
		}
	}

	public function __set($name, $value)
	{
		$this->_data[$name] = $value;
	}

	public function __get($name)
	{
		return isset($this->_data[$name]) ? $this->_data[$name] : null;
	}

	public function __isset($name)
	{
		return isset($this->_data[$name]);
	}

	public function __unset($name)
	{
		unset($this->_data[$name]);
	}

	public function __toString()
	{
		return json_encode($this->_data);
	}
}