<?php

class App_Chart_Menu extends ofc_menu
{
	public function __construct($values = array())
	{
		parent::ofc_menu('#ffffee', '#ffffee');

		$arr = array();
		foreach ($values as $text => $func) {
			$arr[] = new App_Chart_Menu_Item($text, $func);
		}
		$this->values($arr);
	}
}