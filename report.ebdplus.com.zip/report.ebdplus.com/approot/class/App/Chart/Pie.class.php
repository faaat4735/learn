<?php

class App_Chart_Pie
{
	public $title = '';
	public $data = array();
	public $tip;

	public function getJson()
	{
		if (empty($this->tip)) {
			throw new Exception('Miss <em>$this->tip</em> parameter');
		}

		//draw graph
		$title = new OFC_Elements_Title($this->title);
		$pie = new OFC_Charts_Pie();
		$pie->set_start_angle(35);

		$data = array();
		foreach ($this->data as $k => $v) {
			$v = intval($v);
			$data[] = new OFC_Charts_Pie_Value($v, $k);
		}
		$pie->values = $data;
		$pie->tip = $this->tip;

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		return $chart->toString();
	}
}