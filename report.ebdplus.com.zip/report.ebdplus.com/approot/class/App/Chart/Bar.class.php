<?php

class App_Chart_Bar extends bar
{
	/**
	 * constructor
	 *
	 * @param string $type (optional)
	 */
	public function __construct($color = '#0077cc', $width = 3)
	{
		parent::bar();

		$this->set_colour($color);
		$this->alpha = 0.6;
	}

	/**
	 * set title
	 *
	 * @param string $text
	 * @param int $fontSize
	 * @return App_Chart_Line
	 */
	public function setTitle($text, $fontSize = 11)
	{
		parent::set_key($text, $fontSize);
		return $this;
	}

	public function setType()
	{
	}

	public function setTip($tip)
	{
		$this->tip = $tip;
	}

	/**
	 * set values
	 *
	 * @param array $values
	 * @param array $dates
	 * @param string $color
	 * @return App_Chart_Line
	 */
	public function setValues($values, $dates = null, $color = '#009900')
	{
		if (!empty($dates)) {
			foreach ($dates as $k => $date) {
				$whichDay = date('N', is_numeric($date) ? $date : strtotime($date));
				if ($whichDay == 6 || $whichDay == 7) {
					$_tmp = new stdClass();
					$_tmp->top = $values[$k];
//					$_tmp->colour = $color;
					$_tmp->alpha = 1;
					$values[$k] = $_tmp;
				}
			}
		}
		parent::set_values($values);
		return $this;
	}

	/**
	 * append to chart
	 *
	 * @param App_Chart $chart
	 * @return App_Chart_Line
	 */
	public function appendTo(App_Chart $chart)
	{
		$chart->appendGraph($this);
		return $this;
	}

	/**
	 * keep same interface with Line
	 */
	public function set_width($width)
	{}
}