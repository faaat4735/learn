<?php

class App_Chart_Line extends line
{
	/**
	 * @var solid_dot
	 */
	public $dot;

	/**
	 * constructor
	 *
	 * @param string $type (optional)
	 */
	public function __construct($color = '#0077cc', $width = 3)
	{
		parent::line();

		$this->set_width($width);
		$this->set_colour($color);

//		$this->dot = new solid_dot();
//		$this->dot->size(3);
		$this->{"dot-style"} = array(
			'type' => 'solid-dot',
			'dot-size' => $width,
			'tip' => '#x_label#<br>Total: #val#',
			);
	}

	public function setType($type)
	{
		$this->{"dot-style"}['type'] = $type;
	}

	public function setTip($tip)
	{
		$this->{"dot-style"}['tip'] = $tip;
	}

	/**
	 * set title
	 *
	 * @param string $text
	 * @param int $fontSize
	 * @return App_Chart_Line
	 */
	public function setTitle($text, $fontSize = 11)
	{
		parent::set_key($text, $fontSize);
		return $this;
	}

	/**
	 * set values
	 *
	 * @param array $values
	 * @param array $dates
	 * @param string $color
	 * @param int $bigDotSize
	 * @return App_Chart_Line
	 */
	public function setValues($values, $dates = null, $color = '#009900', $bigDotSize = 5)
	{
		if (!empty($dates)) {
			foreach ($dates as $k => $date) {
				$whichDay = date('N', is_numeric($date) ? $date : strtotime($date));
				if ($whichDay == 6 || $whichDay == 7) {
					$_tmp = new stdClass();
					$_tmp->value = $values[$k];
//					$_tmp->type = 'solid-dot';
//					$_tmp->colour = $color;
					$_tmp->{"dot-size"} = $bigDotSize;
					$values[$k] = $_tmp;
				}
			}
		}
		parent::set_values($values);
		return $this;
	}

	/**
	 * append to chart
	 *
	 * @param App_Chart $chart
	 * @return App_Chart_Line
	 */
	public function appendTo(App_Chart $chart)
	{
		if ($this->dot) {
			$this->set_default_dot_style($this->dot);
		}

		$chart->appendGraph($this);
		return $this;
	}
}