<?php

class App_Chart_OldLine
{
	public $from;
	public $to;
	public $data;
	public $graphby;
	public $tip;

	public $chartXAmount = 5;
	public $chartYAmount = 5;
	public $dateFormat = 'M j, Y';
	public $fullDateFormat = 'M j, Y - l';

	public function getJson()
	{
		if (empty($this->from)) {
			throw new Exception('Miss <em>$this->from</em> parameter');
		}
		if (empty($this->to)) {
			throw new Exception('Miss <em>$this->to</em> parameter');
		}
		if (!isset($this->data)) {
			throw new Exception('Miss <em>$this->data</em> parameter');
		}
		if (empty($this->graphby)) {
			throw new Exception('Miss <em>$this->graphby</em> parameter');
		}
		if (empty($this->tip)) {
			throw new Exception('Miss <em>$this->tip</em> parameter');
		}


		$fromTimestamp = strtotime($this->from);
		$toTimestamp = strtotime($this->to);
		$count = count($this->data);

		$xUnit = ceil($count / $this->chartXAmount);
		$xUnit = max($xUnit, 1);

		$labels = array();
		$data = array();
		$max = 0;
		foreach ($this->data as $row) {
			$total = intval($row->total);
			$data[] = $total;
			$max = max($max, $total);

			$date = $row->date;
			switch ($this->graphby) {
				case 'weekly':
					$tmp = Jcan_Date::aweek(strtotime($date), 1);
					$tmp[0] = max($tmp[0], $fromTimestamp);
					$tmp[1] = min($tmp[1], $toTimestamp);
					$labels[] = date($this->dateFormat, $tmp[0]) . ' - ' . date($this->dateFormat, $tmp[1]);
					break;
				case 'monthly':
					$tmp = Jcan_Date::amonth(strtotime($date));
					$tmp[0] = max($tmp[0], $fromTimestamp);
					$tmp[1] = min($tmp[1], $toTimestamp);
					$labels[] = date($this->dateFormat, $tmp[0]) . ' - ' . date($this->dateFormat, $tmp[1]);
					break;
				case 'daily':
				default:
//					$whichDay = date('N', strtotime($orderdate));
//					if ($whichDay == 6 || $whichDay == 7) {
//						$total = new OFC_Charts_Bar_Value($total);
//						$total->set_colour('#008800');
//					}
					$labels[] = date($this->dateFormat, strtotime($date));
					break;
			}
		}

		$yUnit = ceil($max / $this->chartYAmount);
		$yUnit = max($yUnit, 1);
		if ($yUnit > 100000) {
			$yUnit = ceil($yUnit/1000) * 1000;
		} elseif ($yUnit > 1000) {
			$yUnit = ceil($yUnit/100) * 100;
		} elseif ($yUnit > 10) {
			$yUnit = ceil($yUnit/10) * 10;
		}

		if ($count > 60) {
			$line = new OFC_Charts_Line();
		} else {
			$line = new OFC_Charts_Line_Dot();
		}
		$line->set_width(3);
		$line->set_dot_size(3);
		$line->set_colour('#0077cc');
		$line->set_values($data);
		$line->tip = $this->tip;

		$xLabels = new OFC_Elements_Axis_X_Label_Set();
		$xLabels->set_steps($xUnit);
		$xLabels->set_labels($labels);

		$x = new OFC_Elements_Axis_X();
		$x->set_grid_colour('#eeeeee');
		$x->set_stroke(1);
		$x->set_steps($xUnit);
		$x->set_labels($xLabels);

		$y = new OFC_Elements_Axis_Y();
		$y->set_range(0, $yUnit * $this->chartYAmount, $yUnit);
		$y->set_grid_colour('#f3f3f3');
		$y->set_stroke(1);

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title(new OFC_Elements_Title(''));
		$chart->set_x_axis($x);
		$chart->set_y_axis($y);
		$chart->add_element($line);

		return $chart->toString();
	}
}