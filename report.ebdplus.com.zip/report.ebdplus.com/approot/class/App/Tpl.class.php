<?php

class App_Tpl
{
	public $templateDir;

	//view [channel, module, action, title, keywords, description, ......]
	public $view;

	public $channel;
	public $module;
	public $action;

	public function __construct()
	{
		$this->templateDir = TPL_DIR . 'templates/';
	}

	public function display($file = null)
	{
		if (empty($file)) {
			$file = $this->module . '_' . $this->action . '.tpl';
		}
		include $this->templateDir . $file;
	}

	public function assign($var, $value)
	{
		$this->$var = $value;
	}

	public function assign_by_ref($var, &$value)
	{
		$this->$var = $value;
	}

	public function __set($var, $value)
	{
		$this->$var = $value;
	}

	public function __get($var)
	{
		return null;
	}

	public function def(&$var, $default = '')
	{
		if (!isset($var)) {
			return $default;
		}
		return $var;
	}
}