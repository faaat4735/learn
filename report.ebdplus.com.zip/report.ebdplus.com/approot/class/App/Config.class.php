<?php

class App_Config extends Jcan_Config
{}