<?php

class App_Model_Categories
{
	public static $categories = array(
		array(52, 'Plastic', 1),
		array(51, 'Metal', 1),
		array(49, 'Flexlite', 1),
		array(54, 'Titanium', 1),
		array(53, 'Rimless', 1),
		array(48, 'Fashion', 1),
		array(55, 'Sport', 1),
		array(47, 'Designer', 1),
		array(56, 'Classic', 1),
		array(66, 'Goggles', 1),
		array(70, 'Sunglasses', 2),
		array(71, 'Reading', 2),
		);

	public static function getCommonCategoryList()
	{
		$categories = array();
		foreach (self::$categories as $row) {
			if ($row[2] == 1) {
				$categories[$row[0]] = $row[1];
			}
		}
		return $categories;
	}

	public static function getAllCategoryList()
	{
		$categories = array();
		foreach (self::$categories as $row) {
			if ($row[2]) {
				$categories[$row[0]] = $row[1];
			}
		}
		return $categories;
	}
}