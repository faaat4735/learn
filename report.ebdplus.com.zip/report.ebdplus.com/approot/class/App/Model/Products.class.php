<?php

class App_Model_Products
{
	public static function getSubTotal()
	{
		$categories = App_Model_Categories::getCommonCategoryList();
		$categoryIdStr = implode(',', array_keys($categories));
		$sql = "SELECT products_price, categories_id, products_gender, COUNT(*) cnt
                FROM products_to_categories C
                LEFT JOIN products P
                USING (products_id)
                WHERE categories_id IN ({$categoryIdStr}) AND products_status = 1 AND products_quantity > 5
                GROUP BY products_price, categories_id, products_gender
                WITH ROLLUP";
		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getColorTotal()
	{
		$categories = App_Model_Categories::getCommonCategoryList();
		$categoryIdStr = implode(',', array_keys($categories));
		$sql = "SELECT P.color_family name, COUNT(*) cnt
			FROM products_to_categories C
			LEFT JOIN products P
			USING (products_id)
			WHERE C.categories_id IN ({$categoryIdStr}) AND P.products_status = 1 AND products_quantity > 5
			GROUP BY P.color_family
			ORDER BY cnt DESC";
		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getSizeTotal()
	{
		$categories = App_Model_Categories::getCommonCategoryList();
		$categoryIdStr = implode(',', array_keys($categories));
		$sql = "SELECT
			CASE
				WHEN P.products_total_width BETWEEN 120 AND 129 THEN 1
				WHEN P.products_total_width BETWEEN 130 AND 139 THEN 2
				WHEN P.products_total_width > 139 THEN 3
				ELSE 0
			END name,
			COUNT(*) cnt
			FROM products_to_categories C
			LEFT JOIN products P
			USING (products_id)
			WHERE C.categories_id IN ({$categoryIdStr}) AND P.products_status = 1 AND products_quantity > 5
			GROUP BY name
			ORDER BY cnt DESC";
		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}
}