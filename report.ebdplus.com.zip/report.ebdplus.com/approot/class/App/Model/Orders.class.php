<?php

class App_Model_Orders
{
	public static function getCommonStatusList()
	{
		return App_Model_Status::$commonStatusList;
	}

    public static function excludeTax($field, $taxRate = 'tax_rate')
    {
       // return $field;
        return ($field  .'/(1 + ' . $taxRate. ')'); 
    }
    public static function getStatusList()
	{
		$sql = "SELECT orders_status_id, orders_status_name
			FROM orders_status
			WHERE language_id = 1
			ORDER BY orders_status_name ASC";
		$rows = App_Db::getInstance()->getAll($sql, PDO::FETCH_KEY_PAIR);
		return $rows;
	}
    public static function getLensBundlingList()
    {
        $sql = "SELECT bundling_id, bundling_name
                FROM t_lens_bundling
                WHERE bundling_status > 0";
        $rows = App_Db::getInstance()->getAll($sql, PDO::FETCH_KEY_PAIR);
		return $rows;
    }

	public static function getColorList()
	{
		$sql = "SELECT color_id, color_name FROM products_color
			WHERE language_id = 1";
		$list = App_Db::getInstance()->getAll($sql, PDO::FETCH_KEY_PAIR);
		return $list;
	}

	public static function getGenderList()
	{
		$list = array(
			0	=> 'Male',
			1	=> 'Female',
			2	=> 'Unisex',
		);
		return $list;
	}

	public static function getSizeList()
	{
		$list = array(
			1	=> 'Small(120 to 129mm)',
			2	=> 'Medium(130 to 139mm)',
			3	=> 'Large(140 and above)',
		);
		return $list;
	}

	public static function getMaterialRange($startdate, $enddate)
	{
		$startdateStr = $enddateStr = '';
		if ($startdate) {
			$startdateStr = sprintf("AND DATE(O.date_purchased) >= DATE('%s')", addslashes($startdate));
		}
		if ($enddate) {
			$enddateStr = sprintf("AND DATE(O.date_purchased) <= DATE('%s')", addslashes($enddate));
		}

		$sql = "SELECT C.categories_id name, SUM(OP.products_quantity) cnt
                FROM orders O
                LEFT JOIN (orders_products OP, orders_total T)
                    ON O.orders_id = OP.orders_id AND O.orders_id = T.orders_id
                LEFT JOIN t_product P ON P.product_id = OP.products_id
                LEFT JOIN products_to_categories C ON P.product_id = C.products_id
                WHERE O.orders_status IN (" . implode(',', App_Model_Status::$commonStatusList) . ")
                    AND T.class = 'total'
                $startdateStr $enddateStr
                GROUP BY name
                ORDER BY cnt DESC";

		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getColorRange($startdate, $enddate)
	{
		$startdateStr = $enddateStr = '';
		if ($startdate) {
			$startdateStr = sprintf("AND DATE(O.date_purchased) >= DATE('%s')", addslashes($startdate));
		}
		if ($enddate) {
			$enddateStr = sprintf("AND DATE(O.date_purchased) <= DATE('%s')", addslashes($enddate));
		}

		$sql = "SELECT PCF.color_name name, SUM(OP.products_quantity) cnt
                FROM orders O
                LEFT JOIN (orders_products OP, orders_total T)
                    ON O.orders_id = OP.orders_id AND O.orders_id = T.orders_id
                LEFT JOIN t_product P ON P.product_id = OP.products_id
                LEFT JOIN t_product_color_product PCP ON PCP.product_id = P.product_id
                LEFT JOIN t_product_color PC ON PC.color_id = PCP.color_id
                LEFT JOIN t_product_color_family PCF ON PCF.family_id = PC.family_id
                WHERE O.orders_status IN (" . implode(',', App_Model_Status::$commonStatusList) . ")
                    AND T.class = 'total'
                $startdateStr $enddateStr
                GROUP BY name
                ORDER BY cnt DESC";

		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getPriceRange($startdate, $enddate)
	{
		$startdateStr = $enddateStr = '';
		if ($startdate) {
			$startdateStr = sprintf("AND DATE(O.date_purchased) >= DATE('%s')", addslashes($startdate));
		}
		if ($enddate) {
			$enddateStr = sprintf("AND DATE(O.date_purchased) <= DATE('%s')", addslashes($enddate));
		}

		$sql = "SELECT P.product_price name, SUM(OP.products_quantity) cnt
                FROM orders O
                LEFT JOIN (orders_products OP, orders_total T)
                    ON O.orders_id = OP.orders_id AND O.orders_id = T.orders_id
                LEFT JOIN t_product P ON P.product_id = OP.products_id
                WHERE O.orders_status IN (" . implode(',', App_Model_Status::$commonStatusList) . ")
                    AND T.class = 'total'
                $startdateStr $enddateStr
                GROUP BY name
                ORDER BY cnt DESC";

		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getSizeRange($startdate, $enddate)
	{
		$startdateStr = $enddateStr = '';
		if ($startdate) {
			$startdateStr = sprintf("AND DATE(O.date_purchased) >= DATE('%s')", addslashes($startdate));
		}
		if ($enddate) {
			$enddateStr = sprintf("AND DATE(O.date_purchased) <= DATE('%s')", addslashes($enddate));
		}

		$sql = "SELECT
                    CASE
                        WHEN P.product_total_width BETWEEN 120 AND 129 THEN 1
                        WHEN P.product_total_width BETWEEN 130 AND 139 THEN 2
                        WHEN P.product_total_width > 139 THEN 3
                        ELSE 0
                    END name,
                SUM(OP.products_quantity) cnt
                FROM orders O
                LEFT JOIN (orders_products OP, orders_total T)
                    ON O.orders_id = OP.orders_id AND O.orders_id = T.orders_id
                LEFT JOIN t_product P ON P.product_id = OP.products_id
                WHERE O.orders_status IN (" . implode(',', App_Model_Status::$commonStatusList) . ")
                    AND T.class = 'total'
                $startdateStr $enddateStr
                GROUP BY name
                ORDER BY cnt DESC";

		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}

	public static function getGenderRange($startdate, $enddate)
	{
		$startdateStr = $enddateStr = '';
		if ($startdate) {
			$startdateStr = sprintf("AND DATE(O.date_purchased) >= DATE('%s')", addslashes($startdate));
		}
		if ($enddate) {
			$enddateStr = sprintf("AND DATE(O.date_purchased) <= DATE('%s')", addslashes($enddate));
		}

		$sql = "SELECT
                CASE
                    WHEN FIND_IN_SET('men', P.product_attrs) AND FIND_IN_SET('women',product_attrs) THEN 2
                    WHEN FIND_IN_SET('women', P.product_attrs) THEN 1
                    WHEN FIND_IN_SET('men', P.product_attrs) THEN 0
                END name, SUM(OP.products_quantity) cnt
                FROM orders O
                LEFT JOIN (orders_products OP, orders_total T)
                    ON O.orders_id = OP.orders_id AND O.orders_id = T.orders_id
                LEFT JOIN t_product P ON P.product_id = OP.products_id
                WHERE O.orders_status IN (" . implode(',', App_Model_Status::$commonStatusList) . ")
                    AND T.class = 'total'
                $startdateStr $enddateStr
                GROUP BY name
                ORDER BY cnt DESC";

		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}
    
    public static function getCountryName($countryId) {
        $sql = "SELECT countries_name FROM countries WHERE countries_id = ". (int)$countryId;
        $name = App_Db::getInstance()->getOne($sql);
		return $name;
    }
}