<?php

class App_Model_Admin
{
	public static function validate($plain, $encrypted)
	{
		if (empty($plain) || empty($encrypted)) {
			return false;
		}

		$stack = explode(':', $encrypted);
		if (count($stack) != 2) {
			return false;
		}

		if (md5($stack[1] . $plain) == $stack[0]) {
			return true;
		}

		return false;
	}

	public static function getRow($email)
	{
		$sql = "SELECT * FROM t_member WHERE member_email = ? AND admin_groups_id IN (1, 2, 6, 7, 8, 9)";
		$row = App_Db::getInstance()->getRow($sql, null, $email);
		return $row;
	}
    
    public static function checkErrorLog($email,$ip)
    {
        $sql = "SELECT times, UNIX_TIMESTAMP(last_time) as last_time FROM t_member_login WHERE email='{$email}' AND ip ='{$ip}'";
        $row = App_Db2::getInstance()->getRow($sql);
        if (!empty($row) && $row->times >= 5 && time() - $row->last_time  < 3600) {
            return false;
        }
        if (!empty($row) && time() - $row->last_time  > 3600) {
            self::clearLog($email, $ip);
        }
        return true;
    }
    
    public static function errorLog($email, $ip)
    {
        $sql = "INSERT INTO t_member_login
                SET email = '{$email}',
                ip = '{$ip}', times = 1
                ON DUPLICATE KEY UPDATE
                times = times + 1";
        App_Db2::getInstance()->exec($sql);
        return;
    }
    public function clearLog($email, $ip)
    {
        $sql = "DELETE FROM t_member_login WHERE email='{$email}' AND ip ='{$ip}'";
        App_Db2::getInstance()->exec($sql);
        return;
    }


    /**
     * Get real IP address (also for proxy)
     * It is not safe for un-proxy
     *
     * @return string
     */
    public static function getIp()
    {
        if (
            isset($_SERVER['HTTP_X_REAL_IP'])
            && preg_match('/^[\d\.]{7,15}$/', $_SERVER['HTTP_X_REAL_IP'])
        ) {
            return $_SERVER['HTTP_X_REAL_IP'];
        }
        return $_SERVER["REMOTE_ADDR"];
    }
}