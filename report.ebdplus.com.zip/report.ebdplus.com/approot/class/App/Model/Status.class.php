<?php

class App_Model_Status
{

//	public static $statuses = array(
//		6	=> 'Canceled',
//		1	=> 'Data Received',
//		9	=> 'New Order',
//		4	=> 'On Hold',
//		10	=> 'Outstanding',
//		12	=> 'Preparing for shipment',
//		11	=> 'Preparing [GoogleCheckout]',
//		7	=> 'Preparing [PayPal IPN]',
//		2	=> 'Processing',
//		8	=> 'Quality Check',
//		5	=> 'Refunded',
//		3	=> 'Shipped',
//		);

	const SHIPPED_ID = 3;

	public static $commonStatusList = array(
		1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20, 23
	);

}