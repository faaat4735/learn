<?php

class App_Model_Customers
{
	public static function getRow($id)
	{
		$sql = "SELECT customers_firstname, customers_lastname, customers_email_address
			FROM customers
			WHERE customers_id = ?";
		$row = App_Db::getInstance()->getRow($sql, null, $id);
		return $row;
	}

	public static function getUtmSource()
	{
		$sql = "SELECT DISTINCT utm_source as reg_from
			FROM customers_info ci
			WHERE ci.utm_source IS NOT NULL";
		$row = App_Db::getInstance()->getAll($sql);
		return $row;
	}
	public static function getUtmCampaign()
	{
		$sql = "SELECT DISTINCT utm_campaign as reg_from
			FROM customers_info ci
			WHERE ci.utm_campaign IS NOT NULL";
		$row = App_Db::getInstance()->getAll($sql);
		return $row;
	}
	public static function getUtmMedium()
	{
		$sql = "SELECT DISTINCT utm_medium as reg_from
			FROM customers_info ci
			WHERE ci.utm_medium IS NOT NULL";
		$row = App_Db::getInstance()->getAll($sql);
		return $row;
	}
}