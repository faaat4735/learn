<?php

class App_Model_Coupon
{

    /**
     * Check the coupon code whether is in our record
     *
     * @param String $code
     * @return False|Int coupon id
     */
    public static function checkCodeIsExist($code)
    {
        $sql = "SELECT coupon_id
                FROM t_coupon
                WHERE coupon_code = ?";
        return App_Db::getInstance()->getOne($sql, $code);
    }

    /**
     * Check the group whether is exist.
     *
     * @param type $groupName
     * @return False|Int Group Id
     */
    public static function checkGroupIsExist($groupName)
    {
        $sql = "SELECT group_id
                FROM t_coupon_group
                WHERE group_name = ?";
        return App_Db::getInstance()->getOne($sql, $groupName);
    }

    /**
     * Get Coupon group list
     *
     * @return Array|Boolean
     */
    public static function getGroupList($internal = false)
    {
        $sql = "SELECT *
                FROM t_coupon_group";
        if ($internal !== false) {
            if ($internal == 1) {
                $sql .= " WHERE group_type != 'manual'";
            } else {
                $sql .= " WHERE group_type = 'manual'";
            }
        }
        return App_Db::getInstance()->getAll($sql);
    }

    /**
     * Get the coupon infomation
     *
     * @param String $code
     * @return False|Int
     */
    public static function getCode($code) {
        $sql = "SELECT *
                FROM t_coupon
                WHERE coupon_code = ?";
        return App_Db::getInstance()->getRow($sql, null, $code);
    }
    
    /**
     * Get coupon groups by type
     *
     * @param String $groupType
     * @return Array|Boolean
     */
    public static function getGroupsByType($groupType)
    {
        $sql = "SELECT *
                FROM t_coupon_group
                WHERE group_type = ?";
        return App_Db::getInstance()->getAll($sql, $groupType);

    }
    
    
    /**
     * Get the coupon_group infomation
     *
     * @param String $groupId
     * @return False|Int
     */
    public static function getGroup($groupId) {
        $sql = "SELECT *
                FROM t_coupon_group
                WHERE group_id = ?";
        return App_Db::getInstance()->getRow($sql, null, $groupId);
    }
}

