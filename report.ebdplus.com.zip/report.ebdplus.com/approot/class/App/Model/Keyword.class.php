<?php

class App_Model_Keyword
{

	public static function getData($from, $to, $keywords, $orderbyWhere, $start = 0, $limit = 30)
	{
		$db = App_Db::getInstance();

		$whereKeywords = $keywords ? "AND keyword = '" . addslashes($keywords) . "'" : '';

		$sql = sprintf("SELECT COUNT(DISTINCT keyword)
			FROM priv_search_keywords
			WHERE DATE(createtime) BETWEEN DATE('%s') AND DATE('%s')
			%s",$from, $to, $whereKeywords);
			//echo $sql;
		$db->foundRows = $db->getOne($sql);

		$sql = sprintf("SELECT keyword, COUNT(*) total
				FROM priv_search_keywords
				WHERE DATE(createtime) BETWEEN DATE('%s') AND DATE('%s') %s
				GROUP BY keyword
				$orderbyWhere LIMIT %d, %d",
				$from, $to, $whereKeywords, $start, $limit);
		$rows = App_Db::getInstance()->getAll($sql);
		return $rows;
	}


	public static function getStatByTimeRange($from, $to, $keywords, $graphby)
	{
		// fix the bug of old version mysql
		$from = str_replace('/', '-', $from);
		$to = str_replace('/', '-', $to);

		// whereKeywords
		$whereKeywords = empty($keywords) ? '' : "AND keyword = '" . addslashes($keywords) . "'";

		//graphby
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date, 3)';
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date)';
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM date)';
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date)';
				break;
		}

		//db
		$db = App_Db::getInstance();

		//not by category
		$sql = "SELECT DATE(createtime) date, COUNT(*) total
			FROM priv_search_keywords
			WHERE DATE(createtime) BETWEEN ? AND ?
			$whereKeywords
			GROUP BY $groupby
			ORDER BY DATE(createtime) ASC";
		$rows = $db->getAll($sql, null, null, $from, $to);

		//return
		return $rows;
	}
}