<?php

class App_Model_Plannogram
{
	public static function parseResults($rows)
	{
		$retval = array(
			'data'	=> array(),
			'sum'	=> 0,
			);

		foreach ($rows as $row) {
			$price = $row->product_price;
			$category = $row->category;
			$gender = $row->product_gender;
			$cnt = $row->cnt;

			if (is_null($price)) {
				$retval['sum'] = $cnt;
				continue;
			}

			if (!isset($retval['data'][$price])) {
				$retval['data'][$price] = array('data'=>array(), 'sum'=>0);
			}
			if (is_null($category)) {
				$retval['data'][$price]['sum'] = $cnt;
				continue;
			}

			if (!isset($retval['data'][$price]['data'][$category])) {
				$retval['data'][$price]['data'][$category] = array('data'=>array(), 'sum'=>0);
			}
			if (is_null($gender)) {
				$retval['data'][$price]['data'][$category]['sum'] = $cnt;
				continue;
			}

			if (!isset($retval['data'][$price]['data'][$category]['data'][$gender])) {
				$retval['data'][$price]['data'][$category]['data'][$gender] = $cnt;
			}
		}

		return $retval;
	}

	public static function getSubTotal($result, $category, $genderId = null)
	{
		$sum = 0;
		foreach ($result['data'] as $priceRow) {

			if (!isset($genderId)) {
				if (!isset($priceRow['data'][$category])) continue;
				$sum += $priceRow['data'][$category]['sum'];
			} else {
				if (!isset($priceRow['data'][$category]['data'][$genderId])) continue;
				$sum += $priceRow['data'][$category]['data'][$genderId];
			}
		}
		return $sum;
	}
}