<?php

class App_Model_Loyalty
{
	public static $defaultActions = array(
		'Registration', 'Purchase', 'Referral',
	);

	public static $actions = array(
		'Registration'	=> 'Registration',
		'Purchase'	=> 'Purchase',
		'Referral'	=> 'Referral',
		'Redeemed'	=> 'UsePoints',
	);

	public static function getActions()
	{
		return self::$actions;
	}

	public static function getDefaultActions()
	{
		return self::$defaultActions;
	}

	public static function stat($actions, $start = 0, $limit = 30)
	{
		$db = App_Db::getInstance();

		if (!$actions) {
			$actions = self::$actions;
		}
        $actions[] = 'Adjustment';
		$actions = implode(',', $actions);


		$sql = "SELECT COUNT(DISTINCT P.customers_id)
			FROM customers_points_history P
			WHERE FIND_IN_SET(action, ?)";
		$db->foundRows = $db->getOne($sql, $actions);

		$sql = sprintf("SELECT U.customers_id, U.customers_firstname, U.customers_lastname, U.customers_email_address, ABS(SUM(points)) total
				FROM customers_points_history P
				LEFT JOIN customers U
				ON U.customers_id = P.customers_id
				WHERE FIND_IN_SET(action, ?)
				GROUP BY P.customers_id
				ORDER BY total DESC, U.customers_id DESC
				LIMIT %d, %d", $start, $limit);
		$rows = App_Db::getInstance()->getAll($sql, null, null, $actions);
		return $rows;
	}

	public static function getCustomerRows($customerId)
	{
		$sql = "SELECT * FROM
			customers_points_history P
			WHERE customers_id = ? AND points != 0
			ORDER BY actiontime DESC";
		$rows = App_Db::getInstance()->getAll($sql, null, null, $customerId);
		return $rows;
	}
}