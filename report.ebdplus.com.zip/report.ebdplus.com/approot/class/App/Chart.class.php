<?php

class App_Chart extends open_flash_chart
{
	protected $_dateFormat = 'M j, Y';
	protected $_fullDateFormat = 'M j, Y - l';
	protected $_from;
	protected $_to;

	protected $_xAmount = 8;
	protected $_yAmount = 5;
	protected $_bgColor = '#ffffff';

	protected $_xLabels = array();
	protected $_graphs = array();

	/**
	 * @var title
	 */
	public $title;

	/**
	 * @var x_axis
	 */
	public $x;

	/**
	 * @var y_axis
	 */
	public $y;

	/**
	 * auto get shape
	 *
	 * @param string $type (optional)
	 * @param int $count (optional)
	 * @param string $color (optional)
	 * @param int $width (optional)
	 * @return App_Chart_Line | App_Chart_Bar
	 */
	public function getShape($type = 'line', $count = null, $color = '#0044cc', $width = 3)
	{
		if ($type == 'bar') {
			$this->x->set_offset(true);
			$shape = new App_Chart_Bar($color);
			return $shape;
		} else {
			$line = new App_Chart_Line($color, $width);
			if ($count > 65 || $count === true) {
				$line->setType('solid');
			}
			return $line;
		}
	}

	/**
	 * override the contructor
	 */
	public function __construct()
	{
		// parent method
		parent::open_flash_chart();

		/**
		 * set title
		 */
		// $this->title = new title();
		// $this->title->set_style('font-size:12px; color:#000000; font-weight:bold; padding-bottom:8px; font-family:verdana');

		// set x axis
		$this->x = new x_axis();
		$this->x->set_grid_colour('#f3f3f3');
		$this->x->set_steps($this->_xAmount);
		$this->x->set_stroke(1);
		$this->x->set_offset(false);

		// set y axis
		$this->y = new y_axis();
		$this->y->set_grid_colour('#f9f9f9');
		$this->y->set_steps($this->_yAmount);
		$this->y->set_stroke(1);
		$this->y->set_vertical();

		// tooltip
		$tooltip = new tooltip();
		$tooltip->set_background_colour('#ffffee');
		$tooltip->set_colour('#999999');
		$tooltip->set_stroke(1);
		$this->set_tooltip($tooltip);

		// y legend
//		$legend = new y_legend('EyeBuyDirect.com');
//		$legend->set_style('color: #333333; font-size: 10px; text-align: top; padding-top: -30px');
//		$this->set_y_legend($legend);
	}

	/**
	 * set labels
	 *
	 * @param array $labels
	 * @return App_Chart
	 */
	public function setLabels(array $labels, $color = null, $size = null, $rotate = null)
	{
		if ($color === null) {
			$color = ' #333333';
		}
		if ($size === null) {
			$size = 11;
		}
		if ($rotate === null) {
			$rotate = 15;
		}

		// get max value of x labels
		$xMax = count($labels);
		$xUnit = ceil($xMax / $this->_xAmount);
		$xUnit = max($xUnit, 1);
		$this->x->set_steps($xUnit);

		$_labels = new x_axis_labels();
		foreach ($labels as $k => &$_label) {
			$_label = new x_axis_label($_label, $color, $size, $rotate);
			$_label->visible = ($k % $xUnit) ? false : true;
		}
		$_labels->set_labels($labels);
		//$_labels->set_steps($xUnit);
		$this->x->set_labels($_labels);

		return $this;
	}

	/**
	 * format date labels
	 *
	 * @param string $graphby (optional)
	 * @param string|int $from (optional)
	 * @param string|int $to (optional)
	 * @return App_Chart
	 */
	public function formatDate($graphby = 'daily', $from = null, $to = null)
	{
		// fromTimestamp
		if (!$from) {
			$fromTimestamp = 0;
		} else {
			if (is_numeric($from)) {
				$fromTimestamp = $from;
			} else {
				$fromTimestamp = strtotime($from);
			}
		}

		// toTimestamp
		if (!$to) {
			$toTimestamp = time();
		} else {
			if (is_numeric($to)) {
				$toTimestamp = $to;
			} else {
				$toTimestamp = strtotime($to);
			}
		}

		foreach ($this->x->labels->labels as &$row) {
			// timestamp
			$date = $row->text;
			$timestamp = strtotime($date);

			switch ($graphby) {
				case 'weekly':
					$tmp = Jcan_Date::aweek($timestamp, 1);
					$tmp[0] = max($tmp[0], $fromTimestamp);
					$tmp[1] = min($tmp[1], $toTimestamp);
					$row->text = date($this->_dateFormat, $tmp[0]) . ' - ' . date($this->_dateFormat, $tmp[1]);
					break;
				case 'monthly':
					$tmp = Jcan_Date::amonth($timestamp);
					$tmp[0] = max($tmp[0], $fromTimestamp);
					$tmp[1] = min($tmp[1], $toTimestamp);
					$row->text = date($this->_dateFormat, $tmp[0]) . ' - ' . date($this->_dateFormat, $tmp[1]);
					break;
				case 'yearly':
					$tmp = Jcan_Date::ayear($timestamp);
					$tmp[0] = max($tmp[0], $fromTimestamp);
					$tmp[1] = min($tmp[1], $toTimestamp);
					$row->text = date($this->_dateFormat, $tmp[0]) . ' - ' . date($this->_dateFormat, $tmp[1]);
					break;
				case 'daily':
				default:
					$row->text = date($this->_dateFormat, $timestamp);
					break;
			}
		}
	}

	/**
	 * output json
	 *
	 * @return string
	 */
	public function output()
	{
		$this->set_x_axis($this->x);
		$this->set_y_axis($this->y);
		$this->set_title($this->title);

		// set background color
		$this->set_bg_colour($this->_bgColor);

		// append & set y axis range
		$_tmp = array(1);
		foreach ($this->_graphs as $graph) {

			if (isset($graph->tip)) {
				foreach ($graph->values as $k => $v) {
					if (!is_object($v)) {
						$graph->values[$k] = new stdClass();
						$graph->values[$k]->top = $v;
						$graph->values[$k]->alpha = 0.6;
					}
					$tip = str_replace('#x_label#', $this->x->labels->labels[$k]->text, $graph->tip);
					$graph->values[$k]->tip = $tip;
				}
			}

			$this->add_element($graph);
			$max = 1;
			foreach ($graph->values as $val) {
				if (!is_numeric($val)) {
					if (isset($val->top)) {
						$val = $val->top;
					} else if (isset($val->value)) {
						$val = $val->value;
					} else {
						$val = 1;
					}
				}
				$max = max($max, $val);
			}
			$_tmp[] = $max;
		}
		$yMax = max($_tmp);
		$yUnit = ceil($yMax / $this->_yAmount);
		$yUnit = max($yUnit, 1);
		if ($yUnit > 100000) {
			$yUnit = ceil($yUnit/1000) * 1000;
		} elseif ($yUnit > 1000) {
			$yUnit = ceil($yUnit/100) * 100;
		} elseif ($yUnit > 10) {
			$yUnit = ceil($yUnit/10) * 10;
		}
		$this->y->set_range(0, $yUnit * ($this->_yAmount + 0.5), $yUnit);

		// echo
		echo $this->toPrettyString();
	}

	/**
	 * fetch array column
	 *
	 * @param array $data
	 * @param int $column (optional)
	 * @param callback $callback (optional)
	 * @return array
	 */
	public function fetchColumn(array $data, $column = 0, $callback = null)
	{
		$retval = array();
		foreach ($data as $k => $v) {
			$v = (array)$v;
			for ($i=0; $i<$column; $i++) {
				next($v);
			}
			$value = current($v);

			if ($callback && $value !== null) {
				if (stripos($callback, '%') === false) {
					$value = $callback($value);
				} else {
					$value = floatval(sprintf($callback, $value));
				}
			}
			$retval[$k] = $value;
		}
		return $retval;
	}


	/**
	 * fix rows
	 *
	 * @param array $rows
	 * @param array $labels
	 * @return array
	 */
	public function fixRows(array $rows, array $labels)
	{
		$pairs = array();
		foreach ($rows as $row) {
			$pairs[$row[0]] = array($row[1], $row[2]);
		}

		$retval = array();
		foreach ($labels as $label) {
			$retval[] = empty($pairs[$label]) ? array(null, 0) : $pairs[$label];
		}
		return $retval;
	}
    
	public function fixRowsPercent(array $rows, array $labels, array $percent)
	{
		$pairs = array();
		foreach ($rows as $row) {
			$pairs[$row[0]] = array($row[1], 100 * $row[2] / $percent[$row[0]]);
		}

		$retval = array();
		foreach ($labels as $label) {
			$retval[] = empty($pairs[$label]) ? array(null, 0) : $pairs[$label];
		}
		return $retval;
	}    
    
	public function fixRowsNull(array $rows, array $labels, $start, $end)
	{
		$pairs = array();
		foreach ($rows as $row) {
			$pairs[$row[0]] = array($row[1], $row[2]);
		}

		$retval = array();
		foreach ($labels as $label) {
			if($label<$start || $label>$end)
			$retval[] = empty($pairs[$label]) ? array(null, null) : $pairs[$label];
			else 
			$retval[] = empty($pairs[$label]) ? array(null, 0) : $pairs[$label];
		}
		return $retval;
	}
	/**
	 * append graph object
	 *
	 * @param array $labels
	 * @return App_Chart
	 */
	public function appendGraph($graph)
	{
		$this->_graphs[] = $graph;
		return $this;
	}

	/**
	 * set _xAmount
	 *
	 * @param int $amount
	 * @return App_Chart
	 */
	public function setXAmount($amount)
	{
		$this->_xAmount = $amount;
		return $this;
	}

	/**
	 * set _yAmount
	 *
	 * @param int $amount
	 * @return App_Chart
	 */
	public function setYAmount($amount)
	{
		$this->_yAmount = $amount;
		return $this;
	}

	/**
	 * set background color
	 *
	 * @param string $bgColor
	 * @return App_Chart
	 */
	public function setBgColor($bgColor)
	{
		$this->_bgColor = $bgColor;
		return $this;
	}

	/**
	 * set date format
	 *
	 * @param string $format
	 * @return App_Chart
	 */
	public function setDateFormat($format)
	{
		$this->_dateFormat = $format;
		return $this;
	}

	/**
	 * set full date format
	 *
	 * @param string $format
	 * @return App_Chart
	 */
	public function setFulLDateFormat($format)
	{
		$this->_fullDateFormat = $format;
		return $this;
	}
}