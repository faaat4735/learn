<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Keyword extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);
		$this->tpl->breadcrumb->add('Keyword Report');

		// orderby
		$orderby =& $_GET['orderby'];

		// from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];

		// chart
		$chart =& $_GET['chart'];
		if (!$chart) {
			$chart = 'line';
		}

		if ($this->tpl->action == 'index') {
			if (!$from && !$to) {
				$from = $to = date('Y-m-d');
			}
		} else {
			if (!$from) {
				$from = date('Y-m-d', strtotime('-2 month -1 day'));
			}
			if (!$to) {
				$to = date('Y-m-d', strtotime('-1 day'));
			}
		}

		// graphby
		$graphby =& $_GET['graphby'];
		if (!in_array($graphby, array('daily', 'weekly', 'monthly', 'yearly'))) {
			$graphby = 'daily';
		}

		// keywords
		$keywords =& $_GET['keywords'];

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('keywords', $keywords);
		$this->tpl->assign_by_ref('orderby', $orderby);
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
		$this->tpl->breadcrumb->add('List');

		//orderby
		$orderbyWhere = '';
		if ($this->tpl->orderby == 'a') {
			$orderbyWhere = "ORDER BY keyword";
		} else {
			$orderbyWhere = "ORDER BY total DESC";
		}

		//get data
		$p = new Jcan_Pager(5);
		$rows = App_Model_Keyword::getData($this->tpl->from, $this->tpl->to, $this->tpl->keywords, $orderbyWhere, $p->getLimitStart(), $p->getLimitCnt());
		$pager = $p->split(App_Db::getInstance()->foundRows);

		//print_r($pager);
		//print_r($rows);
		$this->tpl->assign_by_ref('rows', $rows);
		$this->tpl->assign_by_ref('pager', $pager);
		$this->display();
	}

	public function graphAction()
	{
		$this->tpl->breadcrumb->add('Graph');
		$this->display();
	}

	public function graphChartAction()
	{
		$rows = App_Model_Keyword::getStatByTimeRange($this->tpl->from, $this->tpl->to, $this->tpl->keywords, $this->tpl->graphby);

		// chart
		$chart = new App_Chart();

		$data = $chart->fetchColumn($rows, 1, 'intval');
		$line = $chart->getShape($this->tpl->chart, count($rows));

		$line->setValues($data, $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Total: #val#');
		$line->appendTo($chart);
		$chart->setLabels($chart->fetchColumn($rows, 0))->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}