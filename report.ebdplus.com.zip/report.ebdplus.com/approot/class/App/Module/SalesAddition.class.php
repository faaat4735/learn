<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
require_once LIB_CLASS_DIR . "gapi.class.php";

class App_Module_SalesAddition extends App_Module
{

    public function __construct($tpl)
    {
        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $graphby = & $_GET['graphby'];
        $chart = & $_GET['chart'];
        $test = & $_GET['test'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month'));
        }
        if (!$to) {
            $to = date('Y-m-d');
        }
        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$chart) {
            $chart = 'line';
        }

        //sortby
        $sortby = & $_GET['sortby'];
        if (!$sortby) {
            $sortby = 'number';
        }

        $payment_method = & $_GET['payment_method'];
        if (!$payment_method) {
            $payment_method = 'All';
        }

        $product_id = & $_GET['pid'];
        $this->tpl->assign('pid', addslashes($product_id));
        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('sortby', $sortby);
        $this->tpl->assign_by_ref('chart', $chart);
        $this->tpl->assign_by_ref('test', $test);
        $this->tpl->assign_by_ref('payment_method', $payment_method);
    }

    public function indexAction()
    {
        $this->reflect('SalesAddition', 'total');
    }

    public function totalAction()
    {
        $this->tpl->breadcrumb->add('Orders');
        $this->display();
    }

    public function totalLabAction()
    {
        $this->tpl->breadcrumb->add('Lab Orders');
        $this->display();
    }

    public function detailAction()
    {
        $this->tpl->breadcrumb->add('Orders');
        $this->display();
    }

    public function jobsAction()
    {
        $this->tpl->breadcrumb->add('Jobs');
        $this->display();
    }

    public function jobsLabAction()
    {
        $this->tpl->breadcrumb->add('Lab Jobs');
        $this->display();
    }

    public function orderPurchaseDateAction()
    {
        $this->tpl->breadcrumb->add('Order Purchase Date');

        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // sum
        $sql = "SELECT EXTRACT(YEAR_MONTH FROM o.date_purchased) grp, COUNT(orders_id) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                GROUP BY grp";

        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $charge_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        $this->tpl->assign('rows', $charge_sum_rows);

        // charge sum
        $sql = "SELECT EXTRACT(YEAR_MONTH FROM o.date_purchased) grp, COUNT(orders_id) total, sum(amount) amount
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59' AND o.data_from = 1 AND o.amount > 0
                GROUP BY grp";

        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $charge_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        $this->tpl->assign('charge_rows', $charge_sum_rows);

        // refund sum
        $sql = "SELECT EXTRACT(YEAR_MONTH FROM o.date_purchased) grp, COUNT(orders_id) total, sum(amount) amount
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59' AND o.data_from = 1 AND o.amount < 0
                GROUP BY grp";

        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $charge_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        $this->tpl->assign('refund_rows', $charge_sum_rows);

        $this->display();
    }

    public function totalChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_complete, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_complete)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_complete)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_complete)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // sum
        $sql = "SELECT $groupby gpy, date_complete, SUM(amount) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // count
        $sql = "SELECT $groupby gpy, date_complete, COUNT(orders_id) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $count_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // Download
        if (isset($_GET['download']) || !empty($_GET['export'])) {
            $filename = date('Y.m.d-Hi') . '.csv';
            header("Content-Type: text/csv");
            header("Content-Disposition: filename=" . $filename);
            echo "Date,Amount,Jobs\r\n";

            foreach ($sum_rows as $sum_row) {
                if (!isset($result[$sum_row[0]])) {
                    $result[$sum_row[0]] = array(
                        'date' => $sum_row[0],
                        'amount' => 0,
                        'jobs' => 0
                    );
                }
                $result[$sum_row[0]]['amount'] = $sum_row['2'];
            }

            foreach ($count_rows as $count_row) {
                if (!isset($result[$count_row[0]])) {
                    $result[$count_row[0]] = array(
                        'date' => $count_row[0],
                        'amount' => 0,
                        'jobs' => 0
                    );
                }
                $result[$count_row[0]]['jobs'] = $count_row['2'];
            }

            foreach ($result as $k => $v) {
                $result[$k] = implode(',', $v);
            }

            $content = implode("\r\n", $result);
            echo mb_convert_encoding($content, 'gbk', 'utf-8');
            exit;
        }

        // chart
        $chart = new App_Chart();

        //print_r($rows);
        $rows = $chart->fixRows($sum_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total Amount: $#val#');
        $line->setTitle('Total amount');
        $line->appendTo($chart);

        // apped orders chart
        $rows = $count_rows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#009922');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Count: #val#');
        $line->setTitle('Total count');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function totalLabChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_complete, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_complete)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_complete)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_complete)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // sum
        $sql = "SELECT $groupby gpy, date_complete, SUM(amount) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 0
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // count
        $sql = "SELECT $groupby gpy, date_complete, COUNT(orders_id) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 0
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $count_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // Download
        if (isset($_GET['download']) || !empty($_GET['export'])) {
            $filename = date('Y.m.d-Hi') . '.csv';
            header("Content-Type: text/csv");
            header("Content-Disposition: filename=" . $filename);
            echo "Date,Amount,Jobs\r\n";

            foreach ($sum_rows as $sum_row) {
                if (!isset($result[$sum_row[0]])) {
                    $result[$sum_row[0]] = array(
                        'date' => $sum_row[0],
                        'amount' => 0,
                        'jobs' => 0
                    );
                }
                $result[$sum_row[0]]['amount'] = $sum_row['2'];
            }

            foreach ($count_rows as $count_row) {
                if (!isset($result[$count_row[0]])) {
                    $result[$count_row[0]] = array(
                        'date' => $count_row[0],
                        'amount' => 0,
                        'jobs' => 0
                    );
                }
                $result[$count_row[0]]['jobs'] = $count_row['2'];
            }

            foreach ($result as $k => $v) {
                $result[$k] = implode(',', $v);
            }

            $content = implode("\r\n", $result);
            echo mb_convert_encoding($content, 'gbk', 'utf-8');
            exit;
        }

        // chart
        $chart = new App_Chart();

        //print_r($rows);
        $rows = $chart->fixRows($sum_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total Amount: $#val#');
        $line->setTitle('Total amount');
        $line->appendTo($chart);

        // apped orders chart
        $rows = $count_rows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#009922');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Count: #val#');
        $line->setTitle('Total count');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function jobsChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_complete, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_complete)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_complete)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_complete)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        // jobs SQL
        $sql = "SELECT $groupby grp, date_complete, COUNT(*) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59' AND o.data_from = 1
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $jobRows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if (isset($_GET['download']) || !empty($_GET['export'])) {
            $filename = date('Y.m.d-Hi') . '.csv';
            header("Content-Type: text/csv");
            header("Content-Disposition: filename=" . $filename);
            echo "Date,Jobs\r\n";

            foreach ($jobRows as $jobRow) {
                if (!isset($result[$jobRow[0]])) {
                    $result[$jobRow[0]] = array(
                        'date' => $jobRow[0],
                        'jobs' => 0
                    );
                }
                $result[$jobRow[0]]['jobs'] = $jobRow['2'];
            }

            foreach ($result as $k => $v) {
                $result[$k] = implode(',', $v);
            }

            $content = implode("\r\n", $result);
            echo mb_convert_encoding($content, 'gbk', 'utf-8');
            exit;
        }

        // chart
        $chart = new App_Chart();

        // append jobs chart
        $rows = $jobRows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total Jobs: #val#');
        $line->appendTo($chart);

        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function jobsLabChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_complete, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_complete)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_complete)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_complete)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        // jobs SQL
        $sql = "SELECT $groupby grp, date_complete, SUM(jobs) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 0
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $jobRows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if (isset($_GET['download']) || !empty($_GET['export'])) {
            $filename = date('Y.m.d-Hi') . '.csv';
            header("Content-Type: text/csv");
            header("Content-Disposition: filename=" . $filename);
            echo "Date,Jobs\r\n";

            foreach ($jobRows as $jobRow) {
                if (!isset($result[$jobRow[0]])) {
                    $result[$jobRow[0]] = array(
                        'date' => $jobRow[0],
                        'jobs' => 0
                    );
                }
                $result[$jobRow[0]]['jobs'] = $jobRow['2'];
            }

            foreach ($result as $k => $v) {
                $result[$k] = implode(',', $v);
            }

            $content = implode("\r\n", $result);
            echo mb_convert_encoding($content, 'gbk', 'utf-8');
            exit;
        }

        // chart
        $chart = new App_Chart();

        // append jobs chart
        $rows = $jobRows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total Jobs: #val#');
        $line->appendTo($chart);

        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function detailChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_complete, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_complete)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_complete)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_complete)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        $payment_method = $this->tpl->payment_method;
        $where_payment = '';
        if ($payment_method != 'All') {
            $where_payment = " AND o.payment_method like '%%{$payment_method}%%'";
        }
        /* Charge */
        // sum
        $sql = "SELECT $groupby gpy, date_complete, ABS(SUM(amount)) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 1
                    AND o.data_category = 'Charge'
                    {$where_payment}
                GROUP BY gpy
                ORDER BY o.orders_id ASC";

        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $charge_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // count
        /*$sql = "SELECT $groupby, date_complete, COUNT(orders_id) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s' AND o.date_complete < ADDDATE('%s', 1)
                    AND o.data_from = 1
                    AND o.amount > 0
                    {$where_payment}
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $charge_count_rows = $db->getAll($sql, null, PDO::FETCH_NUM);*/

        /* Refund */
        // sum
        $sql = "SELECT $groupby gpy, date_complete, ABS(SUM(amount)) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 1
                    AND o.data_category = 'Refund'
                    {$where_payment}
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $refund_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // count
        /*$sql = "SELECT $groupby, date_complete, COUNT(orders_id) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s' AND o.date_complete < ADDDATE('%s', 1)
                    AND o.data_from = 1
                    AND o.amount < 0
                    {$where_payment}
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $refund_count_rows = $db->getAll($sql, null, PDO::FETCH_NUM);*/

        /* Cancel */
        // sum
        $sql = "SELECT $groupby gpy, date_complete, ABS(SUM(amount)) total
                FROM  tv_orders_complete o
                WHERE o.date_complete >= '%s 00:00:00' AND o.date_complete <= '%s 23:59:59'
                    AND o.data_from = 1
                    AND o.data_category = 'Cancel'
                    {$where_payment}
                GROUP BY %s
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $groupby);
        $cancel_sum_rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if(!empty($_GET['export'])) {
            $csvDatas = array();
            $csvDatas['Charge orders amount'] = $charge_sum_rows;
            $csvDatas['Refund orders amount'] = $refund_sum_rows;
            $csvDatas['Cancel amount'] = $cancel_sum_rows;
            $csv = new App_Csv();
            $csvDatas = $csv->prepareCsvData ($csvDatas);
            $csvTitles = array('Time', 'Charge orders amount', 'Refund orders amount', 'Cancel amount');

			$csv->setHeader($csvTitles);
			$csv->setData($csvDatas, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }
        // chart
        $chart = new App_Chart();

        //print_r($rows);
        $rows = $chart->fixRows($charge_sum_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Charge orders amount: $#val#');
        $line->setTitle('Charge orders amount');
        $line->appendTo($chart);

        /*$rows = $chart->fixRows($charge_count_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#009922');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Cahrge orders count: #val#');
        $line->setTitle('Charge orders count');
        $line->appendTo($chart);*/

        // apped orders chart
        $rows = $chart->fixRows($refund_sum_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#ff6600');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Refund orders amount: $#val#');
        $line->setTitle('Refund orders amount');
        $line->appendTo($chart);

        /*$rows = $chart->fixRows($refund_count_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#ff00ff');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Refund orders count: #val#');
        $line->setTitle('Refund orders count');
        $line->appendTo($chart);*/


        $rows = $chart->fixRows($cancel_sum_rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#ff0000');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Refund orders amount: $#val#');
        $line->setTitle('Cancel amount');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);

        if (isset($_GET['download'])) {
            $filename = date('Y.m.d-Hi') . '.csv';
            header("Content-Type: text/csv");
            header("Content-Disposition: filename=" . $filename);
            echo "Date,Charge Amount, Refund Amount\r\n";

            foreach ($charge_sum_rows as $charge_sum_row) {
                if (!isset($result[$charge_sum_row[0]])) {
                    $result[$charge_sum_row[0]] = array(
                        'date' => $charge_sum_row[0],
                        'charge' => 0,
                        'refund' => 0
                    );
                }
                $result[$charge_sum_row[0]]['charge'] = $charge_sum_row['2'];
            }
            foreach ($refund_sum_rows as $refund_sum_row) {
                if (!isset($result[$charge_sum_row[0]])) {
                    $result[$charge_sum_row[0]] = array(
                        'date' => $charge_sum_row[0],
                        'charge' => 0,
                        'refund' => 0
                    );
                }
                $result[$refund_sum_row[0]]['refund'] = $refund_sum_row['2'];
            }

            foreach ($result as $k => $v) {
                $result[$k] = implode(',', $v);
            }

            $content = implode("\r\n", $result);
            echo mb_convert_encoding($content, 'gbk', 'utf-8');

            /*$csv = new App_Csv();
			$csv->setHeader(array('Date', 'Charge amount', 'Refund amount'));
			$csv->setData($charge_sum_rows, array('total', 'total'));
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();*/
            exit;
        }

        $chart->output();
    }



    /**
     * Sync order complete data from Lab and CRM
     */
    public function syncOrderCompleteAction()
    {
        exit;
    }

    //tag manager test
    public function tagAction()
    {
        $this->tpl->breadcrumb->add('Orders');
        if(Jcan_Http::isAjax()){
            $value = array('html' => '<div><div><button id="pop">pop</button></div></div>');
            echo json_encode($value);
            exit;
        }
        $this->display();
    }
}