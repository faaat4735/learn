<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_TimeToCustomer extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$statusList = App_Model_Orders::getStatusList();
		$this->tpl->assign_by_ref('statusList', $statusList);

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$chart =& $_GET['chart'];
		$tracking =& $_GET['tracking'];
        $localeId = & $_GET['localeId'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-3 month'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 month'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$chart) {
			$chart = 'line';
		}
        if(!$tracking){
            $tracking = array('total');
        }
        if (!$localeId) {
            $localeId = 0;
        }
		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
		$this->tpl->assign_by_ref('tracking', $tracking);
        $this->tpl->assign('localeId', $localeId);
	}

	public function indexAction()
	{
		$this->reflect('TimeToCustomer', 'average');
	}

	public function averageAction()
	{
		$this->tpl->breadcrumb->add('Average');
		$this->display();
	}

	public function percentAction()
	{
		$this->tpl->breadcrumb->add('Days (%)');
		$this->display();
	}

	public function daysAction()
	{
		$this->tpl->breadcrumb->add('Average Days');
		$this->display();
	}

	public function ordersAction()
	{
		$this->tpl->breadcrumb->add('Order Status');
		$this->display();
	}

	public function percentDaysAction()
	{
		$this->tpl->breadcrumb->add('Days (%)');
		$this->display();
	}

	public function averageChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date_purchased, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM date_purchased)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date_purchased)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND s.orders_status_id IN ({$_states})";

		//SQL
		$sql = "SELECT $groupby grp, date_purchased, AVG(diff)+2 total
				FROM (
					SELECT date_purchased, DATEDIFF(h.date_added, o.date_purchased) diff
					FROM orders o
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					LEFT JOIN orders_status_history h
					ON o.orders_id = h.orders_id
					WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
					AND o.orders_status = 3
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					AND h.orders_status_id = 3
					AND h.customer_notified = 1
					AND h.orders_id IS NOT NULL
					GROUP BY o.orders_id
				) t
				GROUP BY grp
				ORDER BY grp ASC";
		$sql = sprintf($sql, $this->tpl->from, $this->tpl->to);

		if(!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null,PDO::FETCH_OBJ);
            $csv = new App_Csv();
			$csv->setHeader(array('Time', 'Avg'));
			$csv->setData($rows, array('grp', 'total'));
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Avg: #val# days');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function percentDaysChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();
		//locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

		//SQL
		$sql = "SELECT IF(diff > 20, '> 20', diff) val, COUNT(orders_id) total
				FROM (
					SELECT DATEDIFF(ost.deliver_date, o.date_purchased) diff, o.orders_id
					FROM orders o
					LEFT JOIN orders_status_tracking ost
					ON o.orders_id = ost.orders_id
					WHERE o.date_purchased > '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
					AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
					AND (ost.dispatch_date != '0000-00-00 00:00:00' AND ost.ship_date != '0000-00-00 00:00:00' AND ost.deliver_date != '0000-00-00 00:00:00')
					AND (ost.deliver_date >= o.date_purchased)
                    $localeWhere
				) t
				GROUP BY val";
		$sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
		$rows = $db->getAll($sql);

		$map = array(
			13 => 'more than 14 days',
			10 => '11-13 days',
			7 => '8-10 days',
			-1 => '0-7 days',
		);
		$data = array();
		foreach ($rows as $row) {
			foreach ($map as $k => $desc) {
				if ($row->val > $k) {
					if (!isset($data[$desc])) {
						$data[$desc] = 0;
					}
					$data[$desc] += $row->total;
					break;
				}
			}
		}
		$rows = $data;
		arsort($rows);

		// draw graph
		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $k);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		//$title = new title('Day Pie');
		//$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}

	public function ordersChartAction()
	{
		$db = App_Db::getInstance();

		$graphby = $this->tpl->graphby;
		$tracking = $this->tpl->tracking;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date_purchased, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM date_purchased)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date_purchased)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        $colors = array('#009922', '#ff6600', '#ff00ff', '#999900', '#990000', '#6666aa');

        $processing = $shipping = array();
        if(in_array('processing',$tracking)){
			$sqlProcessing = "SELECT $groupby grp, date_purchased, COUNT(orders_id) total
						FROM (
							SELECT orders_id, date_purchased
							FROM orders
							WHERE (date_purchased > '%s 00:00:00' AND date_purchased <= '%s 23:59:59')
							AND orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
							AND orders_id NOT IN (SELECT orders_id FROM orders_status_tracking)
				            $localeWhere
				            ) t
			            GROUP BY grp
			 			ORDER BY grp";		
			$sqlProcessing = sprintf($sqlProcessing, $this->tpl->from, $this->tpl->to);
        	$rowsProcessing = $db->getAll($sqlProcessing, null, PDO::FETCH_NUM);
        }
        if(in_array('shipping',$tracking)){
			$sqlShipping = "SELECT $groupby grp, date_purchased, COUNT(orders_id) total
						FROM (
							SELECT o.orders_id, o.date_purchased
							FROM orders o
				            LEFT JOIN orders_status_tracking ost
				            ON o.orders_id = ost.orders_id
							WHERE (o.date_purchased > '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59')
							AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
							AND (ost.dispatch_date != '0000-00-00 00:00:00' AND ost.ship_date = '0000-00-00 00:00:00' AND ost.deliver_date = '0000-00-00 00:00:00')
				            $localeWhere
				            ) t
			            GROUP BY grp
			 			ORDER BY grp";
			$sqlShipping = sprintf($sqlShipping, $this->tpl->from, $this->tpl->to);
        	$rowsShipping = $db->getAll($sqlShipping, null, PDO::FETCH_NUM);
        }        
        if(in_array('mile',$tracking)){
			$sqlMile = "SELECT $groupby grp, date_purchased, COUNT(orders_id) total
						FROM (
							SELECT o.orders_id, o.date_purchased
							FROM orders o
				            LEFT JOIN orders_status_tracking ost
				            ON o.orders_id = ost.orders_id
							WHERE (o.date_purchased > '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59')
							AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
							AND (ost.dispatch_date != '0000-00-00 00:00:00' AND ost.ship_date != '0000-00-00 00:00:00')
				            $localeWhere
				            ) t
			            GROUP BY grp
			 			ORDER BY grp";
			$sqlMile = sprintf($sqlMile, $this->tpl->from, $this->tpl->to);
        	$rowsMile = $db->getAll($sqlMile, null, PDO::FETCH_NUM);
        }        
        if(in_array('total',$tracking)){
			$sqlTotal = "SELECT $groupby grp, date_purchased, COUNT(orders_id) total
						FROM (
							SELECT orders_id, date_purchased
							FROM orders
							WHERE (date_purchased > '%s 00:00:00' AND date_purchased <= '%s 23:59:59')
							AND orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
				            $localeWhere
				            ) t
			            GROUP BY grp
			 			ORDER BY grp";		
			$sqlTotal = sprintf($sqlTotal, $this->tpl->from, $this->tpl->to);
			$rowsTotal = $db->getAll($sqlTotal, null, PDO::FETCH_NUM);
	    }
        
		if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvTitles = array('Time');
            if ($rowsProcessing) {
            	$csvData['processing'] = $rowsProcessing;
            	array_push($csvTitles, 'processing');
            }
            if ($rowsShipping) {
            	$csvData['shipping'] = $rowsShipping;
            	array_push($csvTitles, 'shipping');
            }
            if ($rowsMile) {
            	$csvData['mile'] = $rowsMile;
            	array_push($csvTitles, 'mile');
            }
            if ($rowsTotal) {
            	$csvData['total'] = $rowsTotal;
            	array_push($csvTitles, 'total');
            }
            $rows = $csv->prepareCsvData($csvData);
			$csv->setHeader($csvTitles);
			$csv->setData($rows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
			exit;
        }
		$chart = new App_Chart();
        if(isset($rowsProcessing) && !empty($rowsProcessing)){
            $rows = $chart->fixRows($rowsProcessing, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[0]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br> In processing : #val# ');
            $line->appendTo($chart);
        }

        if(isset($rowsShipping) && !empty($rowsShipping)){
            $rows = $chart->fixRows($rowsShipping, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[1]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br> International Shipping : #val# ');
            $line->appendTo($chart);    
        }
        
        if(isset($rowsMile) && !empty($rowsMile)){
            $rows = $chart->fixRows($rowsMile, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[2]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br> Last mile : #val# ');
            $line->appendTo($chart);
        }
        
        if(empty($tracking) || isset($rowsTotal) && !empty($rowsTotal)){
            $rows = $chart->fixRows($rowsTotal, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[3]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br> Total : #val# ');
            $line->appendTo($chart);
        }
        
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function percentChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//SQL
		$sql = "SELECT IF(diff > 20, '> 20', diff) val, COUNT(*) total
				FROM (
					SELECT DATEDIFF(h.date_added, o.date_purchased) diff
					FROM orders o
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					LEFT JOIN orders_status_history h
					ON o.orders_id = h.orders_id
					WHERE o.date_purchased >= '%s' AND o.date_purchased < '%s'
					AND o.orders_status = 3
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					AND h.orders_status_id = 3
					AND h.customer_notified = 1
					AND h.orders_id IS NOT NULL
					GROUP BY o.orders_id
				) t
				GROUP BY val";
		$sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
		$rows = $db->getAll($sql);

		$map = array(
			12 => 'more than 14 days',
			8 => '11-14 days',
			5 => '8-10 days',
			-1 => '0-7 days',
		);
		$data = array();
		foreach ($rows as $row) {
			foreach ($map as $k => $desc) {
				if ($row->val > $k) {
					if (!isset($data[$desc])) {
						$data[$desc] = 0;
					}
					$data[$desc] += $row->total;
					break;
				}
			}
		}
		$rows = $data;
		arsort($rows);

		// draw graph
		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $k);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		//$title = new title('Day Pie');
		//$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}
    
	public function daysChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		$tracking = $this->tpl->tracking;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date_purchased, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM date_purchased)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date_purchased)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}
        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        $colors = array('#009922', '#ff6600', '#ff00ff', '#999900', '#990000', '#6666aa');

		if(in_array('processing',$tracking) || in_array('total',$tracking)){
            $sqlProcessing = "SELECT $groupby grp, date_purchased, AVG(diff) total
                    FROM (
                        SELECT date_purchased, DATEDIFF(h.dispatch_date, o.date_purchased) diff
                        FROM orders o
                        LEFT JOIN orders_status_tracking h
                        ON o.orders_id = h.orders_id
                        WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND h.dispatch_date != '0000-00-00 00:00:00'
                        AND DATEDIFF(h.dispatch_date, o.date_purchased)>0
                        AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                        $localeWhere
                    ) t
                    GROUP BY grp
                    ORDER BY grp ASC";
            $sqlProcessing = sprintf($sqlProcessing, $this->tpl->from, $this->tpl->to);
            $rowsProcessing = $total = $db->getAll($sqlProcessing, null, PDO::FETCH_NUM);
        }

		if(in_array('shipping',$tracking) || in_array('total',$tracking)){
            $sqlShipping = "SELECT $groupby grp, date_purchased, AVG(diff) total
                    FROM (
                        SELECT date_purchased, DATEDIFF(h.ship_date, h.dispatch_date) diff
                        FROM orders o
                        LEFT JOIN orders_status_tracking h
                        ON o.orders_id = h.orders_id
                        WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND h.ship_date != '0000-00-00 00:00:00'
                        AND DATEDIFF(h.ship_date, h.dispatch_date)>0
                        AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                        $localeWhere
                    ) t
                    GROUP BY grp
                    ORDER BY grp ASC";
            $sqlShipping = sprintf($sqlShipping, $this->tpl->from, $this->tpl->to);
            $rowsShipping = $db->getAll($sqlShipping, null, PDO::FETCH_NUM);
        }
		
        if(in_array('mile',$tracking) || in_array('total',$tracking)){
            $sqlMile = "SELECT $groupby grp, date_purchased, AVG(diff) total
                    FROM (
                        SELECT date_purchased, DATEDIFF(h.deliver_date, h.ship_date) diff
                        FROM orders o
                        LEFT JOIN orders_status_tracking h
                        ON o.orders_id = h.orders_id
                        WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND h.deliver_date != '0000-00-00 00:00:00'
                        AND DATEDIFF(h.deliver_date, h.ship_date)>0
                        AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                        $localeWhere
                    ) t
                    GROUP BY grp
                    ORDER BY grp ASC";
            $sqlMile = sprintf($sqlMile, $this->tpl->from, $this->tpl->to);
            $rowsMile = $db->getAll($sqlMile, null, PDO::FETCH_NUM);
        }
        
        if(in_array('total',$tracking)){
            $processing = $shipping = $delivered = array();
            foreach ($rowsProcessing as $row) {
                $processing[$row[0]] = $row[2];
            }

            foreach ($rowsShipping as $key => $row) {
                $shipping[$row[0]] = $row[2];
            }

            foreach ($rowsMile as $key => $row) {
                $delivered[$row[0]] = $row[2];
            }
            foreach ($total as $key => $row) {
                if(!isset($processing[$row[0]]))    $processing[$row[0]] = 0;
                if(!isset($shipping[$row[0]]))    $shipping[$row[0]] = 0;
                if(!isset($delivered[$row[0]]))    $delivered[$row[0]] = 0;
                $total[$key][2] = $processing[$row[0]]+ $shipping[$row[0]] + $delivered[$row[0]];
            }
        }
        
		if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvTitles = array('Time');
            if(in_array('processing',$tracking)){
                array_push($csvTitles, 'processing');
                $csvData['processing'] = $rowsProcessing;
            }
            if(in_array('shipping',$tracking)){
                array_push($csvTitles, 'shipping');
                $csvData['shipping'] = $rowsShipping;    
            }
            if(in_array('mile',$tracking)){
                array_push($csvTitles, 'mile');
                $csvData['mile'] = $rowsMile;
            }
            if(in_array('total',$tracking)){
                array_push($csvTitles, 'total');
                $csvData['total'] = $total;
            }
            $rows = $csv->prepareCsvData($csvData);
			$csv->setHeader($csvTitles);
			$csv->setData($rows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
			exit;
        }
		// chart
		$chart = new App_Chart();
        if(in_array('processing',$tracking)){
            $rows = $chart->fixRows($rowsProcessing, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[0]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Avg Processing: #val# days');
            $line->appendTo($chart);
        }

        if(in_array('shipping',$tracking)){
            $rows = $chart->fixRows($rowsShipping, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[1]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Avg Shipping: #val# days');
            $line->appendTo($chart);    
        }
        
        if(in_array('mile',$tracking)){
            $rows = $chart->fixRows($rowsMile, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[2]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Avg Mile: #val# days');
            $line->appendTo($chart);
        }
        
        if(in_array('total',$tracking)){
            $rows = $chart->fixRows($total, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[3]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Avg Total: #val# days');
            $line->appendTo($chart);
        }
        
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}