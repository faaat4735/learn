<?php

//require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Plannogram extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);
	}

	public function indexAction()
	{
		$this->reflect('Plannogram', 'stock');
	}

	public function stockAction()
	{
		$productType =& $_GET['product_type'];
		$border =& $_GET['border'];
		$shape =& $_GET['shape'];
		$is_spring =& $_GET['is_spring'];
		$is_fashion =& $_GET['is_fashion'];
		$is_classic =& $_GET['is_classic'];
		$is_designer =& $_GET['is_designer'];
		$is_prescription =& $_GET['is_prescription'];
		$is_party =& $_GET['is_party'];
		$min =& $_GET['min'];

		if (empty($productType)) {
			$productType = 'eyeglasses';
		}
		if ($min === null || $min === '') {
			$min = 5;
		}
		$min = intval($min);

		$this->tpl->assign_by_ref('product_type', $productType);
		$this->tpl->assign_by_ref('border', $border);
		$this->tpl->assign_by_ref('shape', $shape);
		$this->tpl->assign_by_ref('is_spring', $is_spring);
		$this->tpl->assign_by_ref('is_fashion', $is_fashion);
		$this->tpl->assign_by_ref('is_classic', $is_classic);
		$this->tpl->assign_by_ref('is_designer', $is_designer);
		$this->tpl->assign_by_ref('is_party', $is_party);
		$this->tpl->assign_by_ref('is_prescription', $is_prescription);
		$this->tpl->assign_by_ref('min', $min);

		// wheres
		$wheres = array();
		$wheres[] = sprintf("pm.product_type = '%s'", addslashes($productType));
		if ($productType == 'eyeglasses') {
			$categories = array('plastic', 'metal', 'titanium', 'flexlite', '');

			if (!empty($border) && in_array($border, array('full-rim', 'semi-rimless', 'rimless'))) {
                    $wheres[] = "FIND_IN_SET('" . $border . "', product_attrs)";
			}
			if (!empty($shape) && in_array($shape, array('rectangle', 'oval', 'square', 'round', 'wayfarer', 'horn'))) {
                    $wheres[] = "FIND_IN_SET('" . $shape . "', product_attrs)";
            }
			if (!empty($is_spring)) {
				$wheres[] = "FIND_IN_SET('spring', product_attrs)";
			}
			if (!empty($is_fashion)) {
                $wheres[] = "FIND_IN_SET('fashion', product_attrs)";
			}
			if (!empty($is_classic)) {
                $wheres[] = "FIND_IN_SET('classic', product_attrs)";
			}
			if (!empty($is_designer)) {
                $wheres[] = "FIND_IN_SET('designer', product_attrs)";
			}
			if (!empty($is_party)) {
                $wheres[] = "FIND_IN_SET('party', product_attrs)";
			}
		}
		elseif ($productType == 'sunglasses') {
			$categories = array('Prescription', 'No Prescription');
			if (!empty($is_prescription)) {
				$wheres[] = "FIND_IN_SET('prescription', product_attrs)";
			}
		}

		else {
			$categories = array($productType);
		}
		$whereStr = implode(' AND ', $wheres);

		// sql
		if ($productType == 'eyeglasses') {
			$sql = "SELECT product_price,
                        IF(is_plastic, 'plastic', IF(is_metal, 'metal', IF(is_flexlite, 'flexlite', IF(is_titanium, 'titanium', '')))) category,
                        IF((is_men > 0 && is_women > 0) || (is_men = 0 && is_women = 0), '2', IF(is_men, '0', '1')) product_gender,
                    COUNT(*) cnt
                    FROM
                    (SELECT product_price,
                        FIND_IN_SET('men', product_attrs) is_men,
                        FIND_IN_SET('women', product_attrs) is_women,
                        FIND_IN_SET('plastic', product_attrs) is_plastic,
                        FIND_IN_SET('metal', product_attrs) is_metal,
                        FIND_IN_SET('flexlite', product_attrs) is_flexlite,
                        FIND_IN_SET('titanium', product_attrs) is_titanium
                    FROM t_product p
                    LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                    WHERE product_status = 1 AND product_quantity > $min AND $whereStr
                    ) a
                    GROUP BY product_price, category, product_gender
                    WITH ROLLUP";
		} elseif ($productType == 'sunglasses') {
			$sql = "SELECT product_price,
                        IF(is_prescription, 'Prescription', 'No Prescription') category,
                        IF((is_men > 0 && is_women > 0) || (is_men = 0 && is_women = 0), '2', IF(is_men, '0', '1')) product_gender,
                    COUNT(*) cnt
                    FROM
                    (SELECT product_price,
                        FIND_IN_SET('men', product_attrs) is_men,
                        FIND_IN_SET('women', product_attrs) is_women,
                        FIND_IN_SET('prescription', product_attrs) is_prescription
                    FROM t_product p
                    LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                    WHERE product_status = 1 AND product_quantity > $min AND $whereStr
                    )a
                    GROUP BY product_price, category, product_gender
                    WITH ROLLUP";
		}
		$subTotal = App_Db::getInstance()->getAll($sql);

		$data = App_Model_Plannogram::parseResults($subTotal);

		$this->tpl->breadcrumb->add('Current Stock');
		$this->tpl->assign_by_ref('categories', $categories);
		$this->tpl->assign_by_ref('data', $data);
		$this->display();
	}
}