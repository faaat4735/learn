<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Referral extends App_Module
{
    public function __construct($tpl)
    {
        parent::__construct($tpl);

        //from date & end date
        $from =& $_GET['from'];
        $to =& $_GET['to'];
        $stat =& $_GET['stat'];
        $graphby =& $_GET['graphby'];
        $chart =& $_GET['chart'];

        if (empty($stat)) {
            $stat = 'volume';
        }
        if (empty($graphby)) {
            $graphby = 'daily';
        }
        if (empty($chart)) {
            $chart = 'line';
        }
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month -1 day'));
        }
        if (!$to) {
            $to = date('Y-m-d', strtotime('-1 day'));
        }

        $source =& $_GET['source'];
        $campaign =& $_GET['campaign'];
        $medium =& $_GET['medium'];
        $this->tpl->assign_by_ref('source', $source);
        $this->tpl->assign_by_ref('campaign', $campaign);
        $this->tpl->assign_by_ref('medium', $medium);

        $sourceList = App_Model_Customers::getUtmSource();
        $this->tpl->assign_by_ref('sourceList', $sourceList);

        $sourceList = App_Model_Customers::getUtmCampaign();
        $this->tpl->assign_by_ref('campaignList', $sourceList);

        $sourceList = App_Model_Customers::getUtmMedium();
        //var_dump($sourceList);exit();
        $this->tpl->assign_by_ref('mediumList', $sourceList);

        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('gender', $gender);
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('chart', $chart);
    }

    public function indexAction()
    {
        $this->tpl->breadcrumb->add('Referral Report');
        $this->display();
    }

    public function onlineAction()
    {
        $this->tpl->breadcrumb->add('Online Users');
        $this->display();
    }

    public function indexChartAction()
    {
        $db = App_Db::getInstance();
        //groupby
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(cr.refer_time, 3)';
                $date = "YW";
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM cr.refer_time)';
                $date = "Ym";
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM cr.refer_time)';
                $date = "Y";
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(cr.refer_time)';
                $date = "Y-m-d";
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        if($this->tpl->stat == 'value') {
            $invitedSql = "SELECT $groupby as grp, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total, DATE(cr.refer_time) time 
                          FROM orders o
                          LEFT JOIN customers_refer cr ON cr.customers_id = o.customers_id
                          LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                          WHERE cr.refer_time >= '%s 00:00:00' AND cr.refer_time <= '%s 23:59:59'
                          AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                          AND ot.class = 'total'
                          AND o.refer_customers_id > 0
                          GROUP BY $groupby "
                          . "ORDER BY time ASC";
        } else {
            $invitedSql = "SELECT $groupby grp, COUNT(*) AS total, DATE(cr.refer_time) AS time FROM customers_refer AS cr
                           WHERE cr.refer_time >= '%s 00:00:00' AND cr.refer_time <= '%s 23:59:59'
                           GROUP BY $groupby ORDER BY time ASC";
            
            $boughtSql = "SELECT $groupby grp, COUNT(*) total, DATE(cr.refer_time) time 
                          FROM customers_refer cr
                          LEFT JOIN orders o ON o.customers_id = cr.customers_id
                          WHERE cr.refer_time >= '%s 00:00:00' AND cr.refer_time <= '%s 23:59:59'
                          AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                          AND o.refer_customers_id > 0
                          GROUP BY $groupby "
                          . "ORDER BY time ASC";
            
            $referSql = "SELECT $groupby grp, COUNT(DISTINCT refer_customers_id) AS total, DATE(cr.refer_time) AS time FROM customers_refer AS cr
                         WHERE cr.refer_time >= '%s 00:00:00' AND cr.refer_time <= '%s 23:59:59'
                         GROUP BY $groupby ORDER BY time ASC";
        }
        
        $invitedSql = sprintf($invitedSql, $this->tpl->from, $this->tpl->to);
        $invitedRows0 = $db->getAll($invitedSql, null, PDO::FETCH_NUM);
              
        // sent
        $sent = $this->tpl->graphby;
		switch ($sent) {
			case 'weekly':
				$sent = 'YEARWEEK(track_time, 3)';
				break;
			case 'monthly':
				$sent = 'EXTRACT(YEAR_MONTH FROM track_time)';
				break;
			case 'yearly':
				$sent = 'EXTRACT(YEAR FROM track_time)';
				break;
			case 'daily':
			default:
				$sent = 'DATE(track_time)';
				break;
		}

        $sql = "SELECT $sent as grp, COUNT(*) as total, DATE(track_time) as time
                FROM priv_email_tracker et
                LEFT JOIN customers c ON c.customers_email_address = et.track_email
                LEFT JOIN customers_info ci ON ci.customers_info_id = c.customers_id
                WHERE et.track_time > '%s 00:00:00' AND et.track_time < '%s 23:59:59'
                AND et.types_id = 35
                AND (ci.customers_info_date_account_created > et.track_time OR ci.customers_info_date_account_created is NULL)
                GROUP BY grp ORDER BY time ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
        $sentTotal = $db->getAll($sql, null, PDO::FETCH_NUM);

        // inviter
        $inviter = $this->tpl->graphby;
        switch ($inviter) {
            case 'weekly':
                $inviterby = 'YEARWEEK(created_at, 3)';
                break;
            case 'monthly':
                $inviterby = 'EXTRACT(YEAR_MONTH FROM created_at)';
                break;
            case 'yearly':
                $inviterby = 'EXTRACT(YEAR FROM created_at)';
                break;
            case 'daily':
            default:
                $inviterby = 'DATE(created_at)';
                break;
        }

        $inviterSql = "SELECT $inviterby as grp, COUNT(DISTINCT user_id) as total, DATE(created_at) as time FROM t_referral_email
                           WHERE created_at >= '%s 00:00:00' AND created_at <= '%s 23:59:59'
                           GROUP BY $inviterby ORDER BY time ASC";
        $inviterSql = sprintf($inviterSql, $this->tpl->from, $this->tpl->to);
        $inviterTotal = $db->getAll($inviterSql, null, PDO::FETCH_NUM);

        $chart = new App_Chart();
        $invitedRows0 = $chart->fixRows($invitedRows0, $labels);
        if($this->tpl->stat == 'value') {
            $data_1 = $chart->fetchColumn($invitedRows0, 0, 'intval');
            $line_1 = $chart->getShape($this->tpl->chart, count($invitedRows0), '#0000ff');
            $line_1->setValues($data_1, $chart->fetchColumn($invitedRows0, 1));
            $tip = $this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#' : '#x_label#<br>Total: #val#';
            $line_1->setTip($tip);
            $line_1->setTitle("Bought");
            $line_1->appendTo($chart);
        } else {
            $boughtSql = sprintf($boughtSql, $this->tpl->from, $this->tpl->to);
            $boughtRows0 = $db->getAll($boughtSql, null, PDO::FETCH_NUM);
            $boughtRows0 = $chart->fixRows($boughtRows0, $labels);

            $referSql = sprintf($referSql, $this->tpl->from, $this->tpl->to);
            $referRows0 = $db->getAll($referSql, null, PDO::FETCH_NUM);
            $referRows0 = $chart->fixRows($referRows0, $labels);

            $sentTotal = $chart->fixRows($sentTotal, $labels);
            $inviterTotal = $chart->fixRows($inviterTotal, $labels);

//            list($invitedRows0, $boughtRows0) = $this -> array_compare_fillZero($invitedRows0, $boughtRows0, $date);

            $data_2 = $chart->fetchColumn($boughtRows0, 0, 'intval');
            $line_2 = $chart->getShape($this->tpl->chart, count($labels), '#ff0000');
            $line_2->setValues($data_2, $chart->fetchColumn($boughtRows0, 1));
            $line_2->setTip('#x_label#<br>Bought Total: #val#');
            $line_2->setTitle("Bought");
            $line_2->appendTo($chart);

            $data_3 = $chart->fetchColumn($referRows0, 0, 'intval');
            $line_3 = $chart->getShape($this->tpl->chart, count($labels), '#006400');
            $line_3->setValues($data_3, $chart->fetchColumn($referRows0, 1));
            $line_3->setTip('#x_label#<br>Refer Total: #val#');
            $line_3->setTitle("Refer");
            $line_3->appendTo($chart);

            $data_4 = $chart->fetchColumn($sentTotal, 0, 'intval');
            $line_4 = $chart->getShape($this->tpl->chart, count($labels), '#00ff00');
            $line_4->setValues($data_4, $chart->fetchColumn($sentTotal, 1));
            $line_4->setTip('#x_label#<br>Sent Total: #val#');
            $line_4->setTitle("Sent");
            $line_4->appendTo($chart);

            $data_5 = $chart->fetchColumn($inviterTotal, 0, 'intval');
            $line_5 = $chart->getShape($this->tpl->chart, count($labels), '#000000');
            $line_5->setValues($data_5, $chart->fetchColumn($inviterTotal, 1));
            $line_5->setTip('#x_label#<br>Inviter Total: #val#');
            $line_5->setTitle("Inviter");
            $line_5->appendTo($chart);
        }

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = array('Invited' => $this->newFixRows($invitedRows0, $date));
            $csvTitles = array('Time', 'Invited');
            if($this->tpl->stat != 'value') {
                $csvRows['Bought'] = $this->newFixRows($boughtRows0, $date);
                $csvRows['Refer'] = $this->newFixRows($referRows0, $date);
                $csvRows['Sent'] = $this->newFixRows($sentTotal, $date);
                $csvRows['Inviter'] = $this->newFixRows($inviterTotal, $date);
                $csvTitles[] = 'Bought';
                $csvTitles[] = 'Refer';
                $csvTitles[] = 'Sent';
                $csvTitles[] = 'Inviter';
            }
            $csvRows = $csv->prepareCsvData($csvRows, 1, 0);

            $csv->setHeader($csvTitles);
            $csv->setData($csvRows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }

        $chart->setLabels($chart->fetchColumn($chartLabels))->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function array_compare_fillZero($arr1, $arr2, $date){
        $more = count($arr1) >= count($arr2) ? $arr1 : $arr2;
        $less = count($arr1) >= count($arr2) ? $arr2 : $arr1;
        $reArr1 = $more;
        $reArr2 = $dataArr = [];
        foreach ($less as $key => $value) {
            $dataArr[date($date, strtotime($value[1]))] = $value[0];
        }
        foreach ($reArr1 as $key => $value) {
            $k = date($date, strtotime($value[1]));
            if(!isset($dataArr[$k])) {
                $reArr2[$key] = array(0, $value[1]);
            } else {
                $reArr2[$key] = array($dataArr[$k], $value[1]);
            }
        }
        return [$reArr1, $reArr2];
    }

    public function newFixRows($rows, $date)
    {
        $retval = array();
        foreach ($rows as $key => $value) {
            $retval[$key] = array(empty($value[0]) ? 0 : $value[0], date($date, strtotime($value[1])));
        }
        return $retval;
    }
}