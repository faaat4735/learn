<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Newsletter extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$chart =& $_GET['chart'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$chart) {
			$chart = 'line';
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
		$this->reflect('Newsletter', 'report');
	}

	public function reportAction()
	{
		$this->tpl->breadcrumb->add('Newsletter');
		$this->display();
	}

	public function reportChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(create_time, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM create_time)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM create_time)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(create_time)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		//SQL
		$sql = sprintf("SELECT $groupby, create_time, COUNT(*) total
				FROM priv_email_opt_in_emails e
				WHERE e.create_time <= '%s 23:59:59' AND e.create_time >= '%s 00:00:00'
				GROUP BY %s
				ORDER BY id ASC",
				$this->tpl->to, $this->tpl->from, $groupby);
		$rowsA = $db->getAll($sql, null, PDO::FETCH_NUM);

        $groupby = str_replace('create_time', 'added', $groupby);
        $sql = sprintf("SELECT $groupby, added create_time, COUNT(*) total
				FROM t_email_subscribe s
				WHERE s.added <= '%s 23:59:59' AND s.added >= '%s 00:00:00'
                AND s.type IN ('newsletter','fashion','coupon','registration','firstvisit','blog','collection','promotion')
				GROUP BY %s
				ORDER BY id ASC",
				$this->tpl->to, $this->tpl->from, $groupby);
        $rowsB = $db->getAll($sql, null, PDO::FETCH_NUM);

        $rows = array_merge($rowsA, $rowsB);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvData(array('Total' => $rows));
            $csvTitles = array('Time', 'Total');

			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Total: #val#');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}