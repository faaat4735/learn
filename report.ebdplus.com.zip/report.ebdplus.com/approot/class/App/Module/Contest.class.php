<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Contest extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$chart =& $_GET['chart'];

		if (empty($chart)) {
			$chart = 'line';
		}
		if (!$from) {
			$from = date('2016-9-26');
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
			// $to = date('2016-9-27');
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
		$this->display();
	}

	public function subscribersAction()
	{
		$db = App_Db::getInstance();
		$p = new Jcan_Pager(30);
		$where = '';
		$from = !empty($_POST['from']) && !empty($_POST['to']) ? $_POST['from'] : date('2016-9-26');
		$to = !empty($_POST['from']) && !empty($_POST['to']) ? $_POST['to'] : date('Y-m-d', strtotime('-1 day'));
		$where .= !empty($_POST['from']) && !empty($_POST['to']) ? "AND a.added BETWEEN '" . $_POST['from'] . "' AND '" . $_POST['to'] . "'" : '';
		$where .= !empty($_POST['crew_name']) ? "AND c.t_crew_name LIKE '%" . $_POST['crew_name'] . "%'" : '';
		$where .= !empty($_POST['email']) ? "AND a.email = '" . $_POST['email'] . "'" : '';
		if(isset($_POST['export'])) {
			$csv = new App_Csv();
			$sql = sprintf("SELECT a.email,a.added,c.t_crew_name
			        FROM t_email_subscribe  a
			        LEFT JOIN t_crew b ON a.email = b.invited_email
			        LEFT JOIN t_crew_info c ON c.t_crew_info_id = b.t_crew_info_id
	            	WHERE a.type = 'contest' %s", $where);
			$stmt = $db->prepare($sql);
			$stmt->execute();
			$csvRows = $stmt->fetchAll(PDO::FETCH_NUM);
			$csvTitles = array('Email', 'Time', 'Crew name');
			$csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($from, $to);$csv->output();
			exit;
		}
		$sql = sprintf("SELECT a.email,a.added,c.t_crew_name
		        FROM t_email_subscribe  a
		        LEFT JOIN t_crew b ON a.email = b.invited_email
		        LEFT JOIN t_crew_info c ON c.t_crew_info_id = b.t_crew_info_id
            	WHERE a.type = 'contest' %s
            	ORDER BY a.added desc
            	LIMIT %d, %d", $where, $p->getLimitStart(), $p->getLimitCnt());
		$stmt = $db->prepare($sql);
		$stmt->execute();
		$fullRows = $stmt->fetchAll(PDO::FETCH_NUM);
		$sql = sprintf("SELECT count(*)
		        FROM t_email_subscribe  a
		        LEFT JOIN t_crew b ON a.email = b.invited_email
		        LEFT JOIN t_crew_info c ON c.t_crew_info_id = b.t_crew_info_id
            	WHERE a.type = 'contest' %s", $where);
		$pager = $p->split($db->getOne($sql));
		$this->tpl->assign_by_ref('dates', $fullRows);
		$this->tpl->assign_by_ref('pager', $pager);
		$this->display();
	}

	public function indexChartAction()
	{
		$db = App_Db::getInstance();

		$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);

		$chart = new App_Chart();

		$sql = "SELECT COUNT(*) total, DATE(created_at) time
				FROM t_crew_info
				WHERE DATE(created_at) BETWEEN DATE(:begindate) AND DATE(:enddate)
				GROUP BY DATE(created_at)";
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$newRows = $stmt->fetchAll(PDO::FETCH_NUM);
		// $newRows = $chart->fixRows($newRows, $labels);
		$newRows = $this->fillArray($newRows, $labels);

		$data_1 = $chart->fetchColumn($newRows, 0, 'intval');
		$line_1 = $chart->getShape($this->tpl->chart, count($labels), '#0000ff');
		$line_1->setValues($data_1, $chart->fetchColumn($newRows, 1));
		$line_1->setTip('#x_label#<br>new Crew: #val#');
		$line_1->setTitle("New Crew");
		$line_1->appendTo($chart);

		$sql = "SELECT count(*) count, DATE(b.max_at) time
				FROM (
					SELECT COUNT(*) total,MAX(updated_at) max_at
					FROM t_crew 
					WHERE is_invited = 1  
					GROUP BY t_crew_info_id
					HAVING total >= 9) b 
				GROUP BY time
				HAVING time BETWEEN DATE(:begindate) AND DATE(:enddate)";
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$fullRows = $stmt->fetchAll(PDO::FETCH_NUM);
		$fullRows = $this->fillArray($fullRows, $labels);

		$data_2 = $chart->fetchColumn($fullRows, 0, 'intval');
		$line_2 = $chart->getShape($this->tpl->chart, count($labels), '#009922');
		$line_2->setValues($data_2, $chart->fetchColumn($fullRows, 1));
		$line_2->setTip('#x_label#<br>New completed: #val#');
		$line_2->setTitle("New completed");
		$line_2->appendTo($chart);

		$sql = "SELECT count(*) total, DATE(updated_at) time
				FROM t_crew 
				WHERE is_invited = 1
				AND DATE(updated_at) BETWEEN DATE(:begindate) AND DATE(:enddate) 
				GROUP BY DATE(updated_at)";
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$acceptRows = $stmt->fetchAll(PDO::FETCH_NUM);
		$acceptRows = $this->fillArray($acceptRows, $labels);

		$data_3 = $chart->fetchColumn($acceptRows, 0, 'intval');
		$line_3 = $chart->getShape($this->tpl->chart, count($acceptRows), '#ff6600');
		$line_3->setValues($data_3, $chart->fetchColumn($acceptRows, 1));
		$line_3->setTip('#x_label#<br>New Member: #val#');
		$line_3->setTitle("New Member");
		$line_3->appendTo($chart);

		$sql = "SELECT count(*) total, DATE(created_at) time
				FROM t_crew 
				WHERE DATE(created_at) BETWEEN DATE(:begindate) AND DATE(:enddate) 
				GROUP BY time";
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$sendRows = $stmt->fetchAll(PDO::FETCH_NUM);
		$sendRows = $this->fillArray($sendRows, $labels);

		$data_4 = $chart->fetchColumn($sendRows, 0, 'intval');
		$line_4 = $chart->getShape($this->tpl->chart, count($labels), '#ff00ff');
		$line_4->setValues($data_4, $chart->fetchColumn($sendRows, 1));
		$line_4->setTip('#x_label#<br>Emails sent: #val#');
		$line_4->setTitle("Emails sent");
		$line_4->appendTo($chart);


		$sql = "SELECT COUNT(*) total, DATE(a.created_at) time
				FROM t_crew_info a
				LEFT JOIN customers_info b ON a.created_user_id = b.customers_info_id
				WHERE DATE(b.customers_info_date_account_created) BETWEEN DATE(:begindate) AND DATE(:enddate)
				AND DATE(b.customers_info_date_account_created) > '2016-9-26'
				GROUP BY DATE(a.created_at)";
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$newCustomersRows = $stmt->fetchAll(PDO::FETCH_NUM);
		$newCustomersRows = $this->fillArray($newCustomersRows, $labels);

		$data_5 = $chart->fetchColumn($newCustomersRows, 0, 'intval');
		$line_5 = $chart->getShape($this->tpl->chart, count($labels), '#6666aa');
		$line_5->setValues($data_5, $chart->fetchColumn($newCustomersRows, 1));
		$line_5->setTip('#x_label#<br>New customers: #val#');
		$line_5->setTitle("New customers");
		$line_5->appendTo($chart);

		if(!empty($_GET['export'])) {
			$csv = new App_Csv();
			$csvRows = array(
				'New created' => $newRows,
				'New completed' => $fullRows,
				'New eligible' => $acceptRows,
				'Emails sent' => $sendRows,
				'New customers' => $newCustomersRows
			);
			$csvRows = $csv->prepareCsvData($csvRows, 1, 0);
			$csvTitles = array('Time', 'New Crew', 'New completed', 'New Member', 'Emails sent', 'New customers');
			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
		}

		$chart->setLabels($labels)->formatDate('daily', $this->tpl->from, $this->tpl->to);
		$chart->output();
	}



	/**
	 * fix rows
	 *
	 * @param array $rows
	 * @param array $labels
	 * @return array
	 */
	public function fillArray(array $rows, array $labels)
	{
		$pairs = array();
		foreach ($rows as $row) {
			$pairs[$row[1]] = array($row[0],$row[1]);
		}

		$retval = array();
		foreach ($labels as $label) {
			$retval[] = empty($pairs[$label]) ? array(0, $label) : $pairs[$label];
		}
		return $retval;
	}
}