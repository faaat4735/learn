<?php

class App_Module_Server extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);
	}

	public function indexAction()
	{
		$this->reflect('Server', 'online');
	}

	public function onlineAction()
	{
		$this->tpl->breadcrumb->add("Online Users");
		$this->display();
	}

	public function requestsAction()
	{
		$this->tpl->breadcrumb->add('Requests');
		$this->display();
	}

	public function connectionsAction()
	{
		$this->tpl->breadcrumb->add('Active Connections');
		$this->display();
	}
}