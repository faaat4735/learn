<?php

class App_Module_Index extends App_Module
{
	public function indexAction()
	{
		$this->display();
	}

	public function logoutAction()
	{
		$_SESSION = array();
		Jcan_Http::redirect(ROOT_URL . 'login');
	}

	public function loginAction()
	{
		$error = '';

		if (Jcan_Http::isPost()) {
			$email =& $_POST['email'];
			$email = trim($email);
			$passwd =& $_POST['passwd'];
            $ip = App_Model_Admin::getIp();
            if (!App_Model_Admin::checkErrorLog($email, $ip)) {
                Jcan_Http::headerStatus(403);
                die;
            }
            
			if (empty($email)) {
				$error = 'Please enter your email address.';
			}
			elseif (empty($passwd)) {
				$error = 'Please enter your password.';
			}
			else {
//				if (!strpos($email, '@')) {
//					$email .= '@eyebuydirect.com';
//				}
				$row = App_Model_Admin::getRow($email);
				if (empty($row) || !App_Model_Admin::validate($passwd, $row->member_password)) {
                    App_Model_Admin::errorLog($email, $ip);
					$error = 'No match for E-Mail Address and/or Password.';
				}
				else {
                    App_Model_Admin::clearLog($email, $ip);
                    // set sessions
                    $_SESSION['member_id'] = $row->member_id;
                    $_SESSION['emp_id'] = $row->emp_id;
                    $_SESSION['login_id'] =& $_SESSION['member_id'];
                    $_SESSION['login_groups_id'] = $row->admin_groups_id;
                    $_SESSION['login_firstname'] = $row->member_firstname;
                    
					Jcan_Http::redirect(ROOT_URL);
				}
			}
		}

		$this->tpl->assign_by_ref('error', $error);
		$this->display('Index_login.tpl');
	}
}