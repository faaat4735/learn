<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
//require_once LIB_CLASS_DIR . "gapi.class.php";
require_once LIB_CLASS_DIR . "GoogleAnalytics.class.php";

class App_Module_Traffic extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$chart =& $_GET['chart'];
        $localeId = & $_GET['localeId'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$chart) {
			$chart = 'line';
		}
        
        if (!$localeId) {
            $localeId = 0;
        }
        
		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
        $this->tpl->assign('localeId', $localeId);
	}

	public function indexAction()
	{
		$this->reflect('Traffic', 'visits');
	}

	public function visitsAction()
	{
		$this->tpl->breadcrumb->add('Visits');
		$this->display();
	}

	public function visitsChartAction()
	{
		$this->tpl->chart = 'line';
        
        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }
        
        $dimensions = array('date', 'week', 'month', 'year');
		$metrics = array('newVisits', 'visits', 'visitors');
        
        $ga_rows = array();
        if ($this->tpl->localeId == 1) { //US
            $usGA = new \GoogleAnalytics();
            $gaResult = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else if ($this->tpl->localeId == 2) { //AU
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);

            $gaResult = $auGA->getReport($this->tpl->from, $this->tpl->to,  $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else if ($this->tpl->localeId == 3) { //CA
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);

            $gaResult = $caGA->getReport($this->tpl->from, $this->tpl->to,  $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else if($this->tpl->localeId == 4) { // FR
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);
            
            $gaResult = $frGA->getReport($this->tpl->from, $this->tpl->to,  $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else if($this->tpl->localeId == 6) { // DE
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);
            
            $gaResult = $deGA->getReport($this->tpl->from, $this->tpl->to,  $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else if($this->tpl->localeId == 7) { // GB
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);
            
            $gaResult = $gbGA->getReport($this->tpl->from, $this->tpl->to,  $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        } else { //ALL
            $usGA = new \GoogleAnalytics();
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);
            
            $gaResult = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
            
            $gaResult = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
            
            $gaResult = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
            
            $gaResult = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
            
            $gaResult = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
            
            $gaResult = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null, array('date'));
            foreach ($gaResult as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $ga_rows[$group] = array(
                        'visitors' => array($date, 0), 'new' => array($date, 0), 'returning' => array($date, 0), 'visits' => array($date, 0)
                    );
                }
                $ga_rows[$group]['visitors'][1] += $result[6];
                $ga_rows[$group]['new'][1] += $result[4];
                $ga_rows[$group]['returning'][1] += $result[5] - $result[4];
                $ga_rows[$group]['visits'][1] += $result[5];
            }
        }

		// chart
		$chart = new App_Chart();

		// settings
		$settings = array(
			'visitors' => array('All Visitor', '#aaaaaa'),
			'visits' => array('All Visits', '#0033cc'),
			'new' => array('New Visits', '#009922'),
			'returning' => array('Returning Visits', '#ff6600'),
		);

        if(!empty($_GET['export'])) {
            $csvData = array();
            $csvTitles = array('Time');
        }

		// append to chart
		$num = 0;
		foreach ($settings as $_name => $_arr) {
			$num++;

			$rows = array();
			foreach ($ga_rows as $group => $arr) {
				$rows[] = array($group, $arr[$_name][0], $arr[$_name][1]);
			}
            if(!empty($_GET['export'])) {
                $csvData[$_name] = $rows;
                if (!in_array($_name, $csvTitles)) {
                    $csvTitles[] = $_name;
                }
                continue;
            }
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>Total: #val#');
			$line->setTitle($_arr[0]);
			$line->appendTo($chart);
		}
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}