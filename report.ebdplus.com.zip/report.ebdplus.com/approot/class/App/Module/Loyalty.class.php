<?php

class App_Module_Loyalty extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);
		$this->tpl->breadcrumb->add('Loyalty Report');
	}

	public function indexAction()
	{
		//actions
		$actions =& $_GET['actions'];
		if (!$actions) {
			$actions = App_Model_Loyalty::getDefaultActions();
		}

		//get data
		$p = new Jcan_Pager(30);
		$rows = App_Model_Loyalty::stat($actions, $p->getLimitStart(), $p->getLimitCnt());
		$pager = $p->split(App_Db::getInstance()->foundRows);

		$this->tpl->assign('actionList', App_Model_Loyalty::getActions());
		$this->tpl->assign_by_ref('rows', $rows);
		$this->tpl->assign_by_ref('pager', $pager);
		$this->display();
	}

	public function customerAction()
	{
		$id =& $_GET['item'];
		$rows = App_Model_Loyalty::getCustomerRows($id);
		$customer = App_Model_Customers::getRow($id);

		$this->tpl->assign_by_ref('rows', $rows);
		$this->tpl->assign_by_ref('customer', $customer);
		$this->display();
	}
}