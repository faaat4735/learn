<?php
require_once INC_DIR . "OFC2/open-flash-chart.php";


class App_Module_Stock extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$statusList = App_Model_Orders::getStatusList();
		$this->tpl->assign_by_ref('statusList', $statusList);

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$stat =& $_GET['stat'];
		$chart =& $_GET['chart'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month'));
		}
		if (!$to) {
			$to = date('Y-m-d');
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$stat) {
			$stat = 'cnt';
		}
		if (!$chart) {
			$chart = 'line';
		}

		//sortby
		$sortby =& $_GET['sortby'];
		if (!$sortby) {
			$sortby = 'number';
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('sortby', $sortby);
		$this->tpl->assign_by_ref('stat', $stat);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
		$this->tpl->breadcrumb->add('Compared Stocks');

		$this->display();
	}
	public function indexChartAction(){
		$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
		$chartLabels = $labels;

		$db = App_Db::getInstance();

		$sql="select `time`,`time`,`" . $this->tpl->stat . "` from `g_products_cnt` where `time`>='" . $this->tpl->from . "' and `time`<='" . $this->tpl->to . "' order by `time` desc";

		$rows=$db->getAll($sql, null, PDO::FETCH_NUM);
		//echo $sql;
		$chart = new App_Chart();
		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Total: #val#');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
	public function averagedayAction(){
		$this->tpl->breadcrumb->add('Average Days to Clear Inventory');

		if($this->tpl->from<'2012-01-01')
		$this->tpl->assign('error', 'Error: The Form Day is smaller than 2012-01-01 ');
		else{
			$db = App_Db::getInstance();

			$sql="select sum(cnt) as cnt from g_products_cnt where time>='2012-01-01' and time<'".$this->tpl->from."'";
			$total_sales=$db->query($sql)->fetchColumn();
			$this->tpl->assign('error',0);
			$this->tpl->assign('totalsales',$total_sales);
		}
		$this->display();
	}

	public function averagedayChartAction(){
		$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
		$chartLabels = $labels;

		$db = App_Db::getInstance();
		$total=&$_GET['total'];
		$sql="SELECT t.`time`, t.`time`, (128300+t.avg_stock*sum(tp.cnt))*DAYOFYEAR(time) stock, t.cnt
			FROM g_products_cnt t
			LEFT JOIN g_products_price_cnt tp ON tp.day=t.time
			Where `time`>='" . $this->tpl->from . "' and `time`<='" . $this->tpl->to . "'
			Group by tp.day
			order by `time` asc";

		$rows = $db->getAll($sql, null, PDO::FETCH_NUM);

		foreach ($rows as $k=>$row) {
			if ($k==0) $rows[$k][4] = $total; else $rows[$k][4] = $rows[$k-1][4]+$rows[$k][3];

			$rows[$k][2] = ($rows[$k][4] * 2) != 0 ? round($rows[$k][2] / ($rows[$k][4] * 2)) : 0;
		}

        if(!empty($_GET['export'])) {
            $csvDatas = array();
            $csvDatas['average_days'] = $rows;
            $csv = new App_Csv();
            $csvDatas = $csv->prepareCsvData ($csvDatas);
            $csvTitles = array('Time', 'average_days');

			$csv->setHeader($csvTitles);
			$csv->setData($csvDatas, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }
		$chart = new App_Chart();
		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Average Days: #val#');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function exportAction(){
		$db = App_Db::getInstance();
		$sql="select `time`,`cnt`,`avg_stock` from `g_products_cnt` where `time`>='" . $this->tpl->from . "' and `time`<='" . $this->tpl->to . "' order by `time` desc";
		$rows=$db->getAll($sql);

		$csv = new App_Csv();
		$csv->setHeader(array('Date', 'Jobs per day', 'Ave. Stock '));
		$csv->setData($rows, array('time', 'cnt', 'avg_stock'));
		$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
		exit;
	}
}