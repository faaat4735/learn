<?php

class App_Module_AccessSourceAnalytics extends App_Module {

	public function __construct($tpl) {
		parent::__construct($tpl);

		//from date & end date
		$from = & $_GET['from'];
		$to = & $_GET['to'];
		$chart = & $_GET['chart'];
		$source = & $_GET['source'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-1 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$chart) {
			$chart = 'line';
		}
		$graphby = 'daily';

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('source', $source);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction() {
		$from = $this->tpl->from;
		$to = $this->tpl->to;
        $rows = $this->getDataFromDb($from, $to);
        if(!empty($_GET['export'])) {
//            print_r($rows);
//            die();
            $csv = new App_Csv();
            $csvTitles = array('domain', 'count');
			$csv->setHeader($csvTitles);
			$csv->setData($rows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }
		$this->tpl->assign('rows', $rows);

		$this->display();
	}

	public function graphAction() {
		$this->tpl->breadcrumb->add('Graph');
		$this->display();
	}

	public function graphChartAction() {
		// include files
		set_include_path(get_include_path() . PATH_SEPARATOR . INC_DIR);
		require_once 'OFC/OFC_Chart.php';

		$from = $this->tpl->from;
		$to = $this->tpl->to;

		$result_total = $this->getDataFromDb($from, $to);

		foreach ($result_total as $v) {
			$values[] = $v['count'];
			$labels[] = $v['domain'];
		}

        if(!empty($_GET['export'])) {
            $csvRows = array();
            foreach ($labels as $k => $v) {
                $csvRows[$k]['domain'] = $v;
                $csvRows[$k]['count'] = $values[$k];
            }
            $csvTitles = array('domain', 'count');
            $csv = new App_Csv();
            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

		//draw graph
		$title = new OFC_Elements_Title('');

		$x = new OFC_Elements_Axis_X();
		$x->set_grid_colour('#ffffff');
		@$x->set_range(0, count($values));
		$x->set_stroke(1);

		$x_labels = new OFC_Elements_Axis_X_Label_Set();
		$x_labels->set_colour('#ffffff');
		@$x_labels->set_labels($labels);
		$x_labels->set_size(1);
		$x->set_labels($x_labels);

		$y = new OFC_Elements_Axis_Y();
		@$y->set_range(0, max($values), max($values) / 5);
		$y->set_grid_colour('#eeeeee');
		$y->set_stroke(1);

		$bar = new OFC_Charts_Bar();
		@$bar->set_values($values);
		$bar->tip = '#x_label#<br>#val#';

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_x_axis($x);
		$chart->set_y_axis($y);
		$chart->set_title($title);
		$chart->add_element($bar);
		echo $chart->toPrettyString();
	}

	public function pieAction() {
		$this->tpl->breadcrumb->add('Pie chart');

		$this->display();
	}

	public function pieChartAction() {
		$from = $this->tpl->from;
		$to = $this->tpl->to;
		$pre_source = empty($_GET['source']) ? '' : $_GET['source'];

		// inlcude files
		require_once INC_DIR . "OFC2/open-flash-chart.php";

		$db = App_Db::getInstance();

		//SQL
		$sql = "SELECT a.uuid, COUNT(*) AS total
				FROM priv_visitor_analysis a
				WHERE NOT EXISTS(
					SELECT b.uuid FROM priv_visitor_analysis b
					WHERE a.uuid=b.uuid
						AND b.orders_id > 0
				)
				GROUP BY a.uuid";
		//$rows1 = $db->getAll($sql, null, PDO::FETCH_NUM);

		$sql = "SELECT a.*, b.*
				FROM (
					SELECT uuid, MIN(orders_id) AS orders_id, MIN(time) AS time
					FROM priv_visitor_analysis
					WHERE orders_id > 0 AND `time` > '{$from} 00:00:00' AND `time` < '{$to} 23:59:59'
					GROUP BY uuid
				) AS a
				LEFT JOIN priv_visitor_analysis b ON a.uuid=b.uuid AND b.time <= a.time";
		$rows2 = $db->getAll($sql, null, PDO::FETCH_ASSOC);

		$reg = "/[\w][\w-]*\.((aero|biz|cc|co|com|coop|edu|gov|info|int|mil|museum|name|nato|net|org|tv)(\.(af|aq|at|au|be|bg|br|ca|ch|cl|cn|de|eg|es|fi|fr|gr|hk|hu|ie|il|in|iq|ir|is|it|jp|kr|mx|nl|no|nz|pe|ph|pr|pt|ru|se|sg|th|tr|tw|uk|us|za|lv|ve))*(\/|$))/isU";

		foreach ($rows2 as $row) {
			$source_domain = '';
			if (!empty($row['source'])) {
				$source_domain = preg_match($reg, $row['source'], $matchs);
				if (!empty($matchs[0])) {
					$source_domain = trim($matchs[0], '/');
					if (in_array($source_domain, array('google.com', 'yahoo.com', 'live.com')) && strpos($row['source'], 'mail') !== false) {
						$source_domain .= '[mail]';
					}
					if ($source_domain == 'google.com' && strpos($row['source'], 'aclk?') !== false) {
						$source_domain = 'google.com[ad]';
					}
				}
			}

			$result[$row['uuid']][] = $source_domain;
		}

		if (!empty($pre_source)) {
			foreach ($result as $k => $v) {
				$v = array_unique($v);

				if (in_array($pre_source, $v)) {
					$tt[$k] = $v;
				}
			}
		} else {
			foreach ($result as $k => $v) {
				$tt[$k] = $v;
			}
		}

		foreach ($tt as $t) {
			$count = count($t) - 1;
			if (isset($rows[$count])) {
				$rows[$count] += 1;
			} else {
				$rows[$count] = 1;
			}
		}

		arsort($rows);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Name', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }
		// draw graph
		$title = new title($pre_source . " Pie chart\r\r\r");

		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $k);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}

	public function pieChart2Action() {
		$from = $this->tpl->from;
		$to = $this->tpl->to;
		$pre_source = empty($_GET['source']) ? '' : $_GET['source'];

		// inlcude files
		require_once INC_DIR . "OFC2/open-flash-chart.php";

		$db = App_Db::getInstance();

		//SQL
		$sql = "SELECT a.uuid, COUNT(*) AS total
				FROM priv_visitor_analysis a
				WHERE NOT EXISTS(
					SELECT b.uuid FROM priv_visitor_analysis b
					WHERE a.uuid=b.uuid
						AND b.orders_id > 0
				)
				GROUP BY a.uuid";
		//$rows1 = $db->getAll($sql, null, PDO::FETCH_NUM);

		$sql = "SELECT a.*, b.*
				FROM (
					SELECT uuid, MIN(orders_id) AS orders_id, MIN(time) AS time
					FROM priv_visitor_analysis
					WHERE orders_id > 0 AND `time` > '{$from} 00:00:00' AND `time` < '{$to} 23:59:59'
					GROUP BY uuid
				) AS a
				LEFT JOIN priv_visitor_analysis b ON a.uuid=b.uuid AND b.time <= a.time";
		$rows2 = $db->getAll($sql, null, PDO::FETCH_ASSOC);

		$reg = "/[\w][\w-]*\.((aero|biz|cc|co|com|coop|edu|gov|info|int|mil|museum|name|nato|net|org|tv)(\.(af|aq|at|au|be|bg|br|ca|ch|cl|cn|de|eg|es|fi|fr|gr|hk|hu|ie|il|in|iq|ir|is|it|jp|kr|mx|nl|no|nz|pe|ph|pr|pt|ru|se|sg|th|tr|tw|uk|us|za|lv|ve))*(\/|$))/isU";

		foreach ($rows2 as $row) {
			$source_domain = '';
			if (!empty($row['source'])) {
				$source_domain = preg_match($reg, $row['source'], $matchs);
				if (!empty($matchs[0])) {
					$source_domain = trim($matchs[0], '/');
					if (in_array($source_domain, array('google.com', 'yahoo.com', 'live.com')) && strpos($row['source'], 'mail') !== false) {
						$source_domain .= '[mail]';
					}
					if ($source_domain == 'google.com' && strpos($row['source'], 'aclk?') !== false) {
						$source_domain = 'google.com[ad]';
					}
				}
			}

			$result[$row['uuid']][] = $source_domain;
		}

		if (!empty($pre_source)) {
			foreach ($result as $k => $v) {
				$v = array_unique($v);

				if (in_array($pre_source, $v)) {
					$tt[$k] = $v;
				}
			}
		} else {
			foreach ($result as $k => $v) {
				$tt[$k] = $v;
			}
		}
        $rows = array();
		foreach ($tt as $t) {
			foreach ($t as $v) {
				if ($v != '' && $v != '0' && $v != 'eyebuydirect.com' && $v != $pre_source) {
					$rows[] = $v;
				}
			}
		}

		$rows = array_count_values($rows);
		arsort($rows);
		$rows = array_slice($rows, 0, 20);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Name', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }
		// draw graph
		$title = new title($pre_source . " Plus\r\r\r");

		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $k);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}

	public function _pieChartAction() {
		$from = $this->tpl->from;
		$to = $this->tpl->to;

		// inlcude files
		require_once INC_DIR . "OFC2/open-flash-chart.php";

		$db = App_Db::getInstance();

		//SQL
		$sql = "SELECT a.uuid, COUNT(*) AS total
				FROM priv_visitor_analysis a
				WHERE NOT EXISTS(
					SELECT b.uuid FROM priv_visitor_analysis b
					WHERE a.uuid=b.uuid
						AND b.orders_id > 0
				)
				GROUP BY a.uuid";
		//$rows1 = $db->getAll($sql, null, PDO::FETCH_NUM);

		$sql = "SELECT a.*, COUNT(b.uuid) AS count
				FROM (
					SELECT uuid, MIN(orders_id) AS orders_id, MIN(time) AS time
					FROM priv_visitor_analysis
					WHERE orders_id > 0 AND `time` > '{$from} 00:00:00' AND `time` < '{$to} 23:59:59'
					GROUP BY uuid
				) AS a
				LEFT JOIN priv_visitor_analysis b ON a.uuid=b.uuid AND b.time < a.time
				GROUP BY b.uuid";
		$rows2 = $db->getAll($sql);

		foreach ($rows2 as $r) {
			$result[$r->count][] = $r->uuid;
		}

		foreach ($result as $k => $v) {
			$rows[$k] = count($v);
		}

		arsort($rows);

		// draw graph
		$title = new title("Pie chart\rHow many times customers access website befor ordered\r\r\r");

		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $k);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}

    public function registerFromAction() {
        $this->tpl->breadcrumb->add('Regist from Pie chart');

		$this->display();
    }

    public function registerFromChartAction() {
        $from = $this->tpl->from;
		$to = $this->tpl->to;

		// inlcude files
		require_once INC_DIR . "OFC2/open-flash-chart.php";

		$db = App_Db::getInstance();

		$sql = "SELECT c.reg_from
				FROM customers AS c
                LEFT JOIN customers_info AS ci ON c.customers_id = ci.customers_info_id
				WHERE c.reg_from <> ''
                    AND c.reg_from <> 'eyebuydirect.com'
                    AND ci.customers_info_date_account_created > '{$from} 00:00:00' AND ci.customers_info_date_account_created < '{$to} 23:59:59'
                ";
		$rows = $db->getAll($sql, null, PDO::FETCH_ASSOC);

        $result = array();
        $count = array();
        foreach ($rows as $row) {
            $row = explode('-', $row['reg_from']);
            $reg_from = $row[0];
            if (strpos($reg_from, 'google') !== false && strpos($reg_from, '[ad]') === false) {
                $reg_from = 'google.com';
            }
            if (strpos($reg_from, 'yahoo') !== false) {
                $reg_from = 'yahoo.com';
            }
            $keywords = empty($row[1]) ? '' : $row[1];

            if (isset($count[$reg_from])) {
                $count[$reg_from] = $count[$reg_from] + 1;
            } else {
                $count[$reg_from] = 1;
            }

            if ($keywords) {
                if (empty($result[$reg_from][$keywords])) {
                    $result[$reg_from][$keywords] = 1;
                } else {
                    $result[$reg_from][$keywords] = $result[$reg_from][$keywords] + 1;
                }
            }
        }

        arsort($count);
        $count = array_slice($count, 0, 20);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($count);
            $csvTitles = array('Name', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        if (!empty($_GET['keywords'])) {
            // keywords count
            $title = new title("\rKeywords from {$_GET['keywords']}");

            $tmp = array();
            if (!empty($result[$_GET['keywords']])) {
                arsort($result[$_GET['keywords']]);
                $result[$_GET['keywords']] = array_slice($result[$_GET['keywords']], 0, 30);

                foreach ($result[$_GET['keywords']] as $keywords => $c) {
                    $tmp[] = new pie_value(intval($c), $keywords);
                }
            }

        } else {
            //
            $title = new title("Register come from\r\r\r");

            $tmp = array();
            foreach ($count as $reg_from => $reg_count) {
                $tmp[] = new pie_value(intval($reg_count), $reg_from);
            }
        }

		// draw graph
		$pie = new pie();
		$pie->set_start_angle(35);

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
    }

	private function getDataFromDb($from, $to) {
		$db = App_Db::getInstance();

		$sql = "SELECT uuid, source, url
				FROM `priv_visitor_analysis`
				WHERE `time` > '{$from} 00:00:00'
					AND `time` < '{$to} 23:59:59'";
		$result_total = $db->getAll($sql, null, PDO::FETCH_ASSOC);

		$return_result = array();
		foreach ($result_total as $result) {
			$reg = "/[\w][\w-]*\.((aero|biz|cc|co|com|coop|edu|gov|info|int|mil|museum|name|nato|net|org|tv)(\.(af|aq|at|au|be|bg|br|ca|ch|cl|cn|de|eg|es|fi|fr|gr|hk|hu|ie|il|in|iq|ir|is|it|jp|kr|mx|nl|no|nz|pe|ph|pr|pt|ru|se|sg|th|tr|tw|uk|us|za|lv|ve))*(\/|$))/isU";

			$source_domain = 'not-record';
			if (!empty($result['source'])) {
				$source_domain = preg_match($reg, $result['source'], $matchs);
				if (!empty($matchs[0])) {
					$source_domain = trim($matchs[0], '/');
					if (in_array($source_domain, array('google.com', 'yahoo.com', 'live.com')) && strpos($result['source'], 'mail') !== false) {
						$source_domain .= '[mail]';
					}
					if ($source_domain == 'google.com' && strpos($result['source'], 'aclk?') !== false) {
						$source_domain = 'google.com[ad]';
					}
				}
			}
			if (empty($source_domain) || $source_domain == 'not-record' || $source_domain == 'eyebuydirect.com') {
				if (strpos($result['source'], 'google') !== false) {
					$source_domain = 'google.com';
				} else {
					$temp[] = $result['source'];
					continue;
				}
			}

			$url_domain = '';
			if (!empty($result['url'])) {
				$url_domain = preg_match($reg, $result['url'], $matchs);
				if (!empty($matchs[0])) {
					$url_domain = trim($matchs[0], '/');
				}
			}

			$uuid = $result['uuid'];

			$return_result[$source_domain][] = $uuid;
		}

		foreach ($return_result as $key => &$value) {
			$value = count($value);
		}

		arsort($return_result);
		$return_result = array_slice($return_result, 0, 50);

		foreach ($return_result as $key => &$value) {
			$value = array(
				$key,
				$value,
				'domain' => $key,
				'count' => $value
			);
		}

		return $return_result;
		//return array_slice($return_result, 0, 2);
	}
}