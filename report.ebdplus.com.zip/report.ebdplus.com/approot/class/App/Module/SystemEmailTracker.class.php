<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_SystemEmailTracker extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$chart =& $_GET['chart'];
		$type =& $_GET['type'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-1 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$chart) {
			$chart = 'line';
		}
        $graphby =& $_GET['graphby'];
        if (!$graphby) {
			$graphby = 'daily';
		}

		$db = App_Db::getInstance();
		$sql = "SELECT types_id, types_name
				FROM `priv_email_tracker_types`";
		$types_result = $db->getAll($sql, null, PDO::FETCH_NUM);

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign('type', addslashes($type));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
		$this->tpl->assign('types', $types_result);
	}

	public function indexAction()
	{
		$this->display();
	}

	public function reportAction() {
		$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
		$chartLabels = $labels;

		$from = $this->tpl->from;
		$to = $this->tpl->to;
		$type_id = $this->tpl->type;

		$db = App_Db::getInstance();

        //groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(track_time, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM track_time)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM track_time)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(track_time)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$sql = "SELECT $groupby as dt,'' as tem, count(*) as total
				FROM `priv_email_tracker`
				WHERE `track_time` > '{$from} 00:00:00'
					AND `track_time` < '{$to} 23:59:59'";
		if ($type_id != 0) {
			$sql .= ' AND `types_id` = ' . $type_id;
		}
		$sql .= " GROUP BY dt";
		$result_total = $db->getAll($sql, null, PDO::FETCH_NUM);

		$sql = "SELECT $groupby as dt, '' as tem, count(*) as total
				FROM `priv_email_tracker`
				WHERE `track_time` > '{$from} 00:00:00'
					AND `track_time` < '{$to} 23:59:59'
					AND `read_time` > '0000-00-00 00:00:00'";
		if ($type_id != 0) {
			$sql .= ' AND `types_id` = ' . $type_id;
		}
		$sql .= " GROUP BY dt";
		$result_open = $db->getAll($sql, null, PDO::FETCH_NUM);

        if(!empty($_GET['export'])) {
            $csvDatas = array();
            $csvDatas['total'] = $result_total;
            $csvDatas['open'] = $result_open;
            $csv = new App_Csv();
            $csvDatas = $csv->prepareCsvData($csvDatas);
            $csvTitles = array('Time', 'total', 'open');

			$csv->setHeader($csvTitles);
			$csv->setData($csvDatas, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }

		// chart
		$chart = new App_Chart();

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');

        $result_total = $chart->fixRows($result_total, $labels);

		$line->setValues($chart->fetchColumn($result_total, 1, '%.2f'), $chart->fetchColumn($result_total, 0));
		$line->setTip('#x_label#<br>Total: #val#');
        $line->setTitle('Total');
		$line->appendTo($chart);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#009922');

        $result_open = $chart->fixRows($result_open, $labels);

		$line->setValues($chart->fetchColumn($result_open, 1, '%.2f'), $chart->fetchColumn($result_open, 0));
		$line->setTip('#x_label#<br>Total: #val#');
        $line->setTitle('Open');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}