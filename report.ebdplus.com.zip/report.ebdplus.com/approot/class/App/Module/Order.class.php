<?php

class App_Module_Order extends App_Module
{
	public function statisticsAction()
	{
		$statusList = App_Model_Orders::getStatusList();

		if (Jcan_Http::isPost()) {
			//statusWhere
			$statusWhere = '';
			if (!empty($_POST['statuses'])) {
				$_statuses = array_map('intval', $_POST['statuses']);
				$_statuses = implode(', ', $_statuses);
				$statusWhere = "AND o.orders_status IN ({$_statuses})";
			}

			//beginDateWhere
			$beginDateWhere = '';
			if (!empty($_POST['beginDate'])) {
				$beginDate = addslashes($_POST['beginDate']);
				$beginDateWhere = "AND o.date_purchased >= '{$beginDate}'";
			}

			//endDateWhere
			$endDateWhere = '';
			if (!empty($_POST['endDate'])) {
				$endDate = addslashes($_POST['endDate']);
				$endDateWhere = "AND o.date_purchased <= ADDDATE('{$endDate}',1)";
			}

			//addressWhere
			$addressWhere = '';
			if (!empty($_POST['address'])) {
				$address = '%' . addslashes($_POST['address']) . '%';
				$addressWhere = "AND (o.customers_address_line1 LIKE '{$address}'
                    OR o.customers_address_line2 LIKE '{$address}'
					OR o.customers_city LIKE '{$address}'
					OR o.customers_state LIKE '{$address}'
					OR o.customers_country LIKE '{$address}'
					OR o.delivery_address_line1 LIKE '{$address}'
                    OR o.delivery_address_line2 LIKE '{$address}'
					OR o.delivery_city LIKE '{$address}'
					OR o.delivery_state LIKE '{$address}'
					OR o.delivery_country LIKE '{$address}'
					OR o.billing_address_line1 LIKE '{$address}'
                    OR o.billing_address_line2 LIKE '{$address}'
					OR o.billing_city LIKE '{$address}'
					OR o.billing_country LIKE '{$address}'
					OR o.billing_state LIKE '{$address}'
					OR o.delivery_postcode LIKE '{$address}'
					OR o.customers_postcode LIKE '{$address}'
					OR o.billing_postcode LIKE '{$address}')";
			}

			//sql
			/////o.*, s.orders_status_name, ot.value as order_total
			$sql = "SELECT SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") as total, count(*) as cnt
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE 1 = 1
				$statusWhere
				AND ot.class = 'total'
				$addressWhere
				$endDateWhere $beginDateWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				ORDER BY date_purchased DESC";

			//execute
			$row = App_Db::getInstance()->getRow($sql);

            if (isset($_POST['export'])) {
                $csvRows = array();
                $csvRows['total'] = $row->cnt;
                $csvRows['total_price'] = $row->total;
                $csvRows['aov'] = $row->cnt ? ($row->total / $row->cnt) : 0;
                $rows[] = $csvRows;

                $csvTitle = array('total', 'total_price', 'aov');
                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($rows, $csvTitle);
                $csv->setDataRange($beginDate, $endDate);$csv->output();
                exit;
            }

			$results = sprintf("Total <em>%u</em> orders<br />Total price: <em>\$%01.2f</em><br />Average price: <em>\$%01.2f</em>", $row->cnt, $row->total, $row->cnt ? ($row->total/$row->cnt) : 0);
		}

		$this->tpl->assign_by_ref('statusList', $statusList);
		$this->tpl->assign_by_ref('results', $results);
		$this->tpl->breadcrumb->add('Order Statistics');
		$this->display();
	}

	public function productreportAction()
	{
		if (Jcan_Http::isPost()) {
			$models = trim($_POST['models']);
			$from = addslashes(trim($_POST['from']));
			$to = addslashes(trim($_POST['to']));

			$db = App_Db::getInstance();

            // create tmp table
            $sql = "CREATE TEMPORARY TABLE IF NOT EXISTS tmp_models1 (id INT(11) NOT NULL AUTO_INCREMENT, model VARCHAR(12) NOT NULL, PRIMARY KEY (id), UNIQUE KEY (model));";
            $db->query($sql);
            $sql = "CREATE TEMPORARY TABLE IF NOT EXISTS tmp_models2 (id INT(11) NOT NULL AUTO_INCREMENT, model VARCHAR(12) NOT NULL, PRIMARY KEY (id), UNIQUE KEY (model));;";
            $db->query($sql);

			if ($models) {
				// get $modelArray
				$modelArray = preg_split("/\s+/", $models);
				$modelArray = Jcan_Array::unique($modelArray, false);
				foreach ($modelArray as &$_model) {
					$_model = addslashes($_model);
				}

				// insert table
				$_str = implode("'), ('", $modelArray);
				$sql = "INSERT IGNORE tmp_models1 (model) VALUES ('{$_str}')";
				$db->query($sql);
				$sql = "INSERT IGNORE tmp_models2 (model) VALUES ('{$_str}')";
				$db->query($sql);
			}

			// fetch report
			$dates = Jcan_Date::getDates($from, $to);
			$results = array();
			foreach ($dates as $date) {
				$sql = "SELECT IF(t.qty IS NULL, 0, t.qty) qty
                        FROM tmp_models1 mm
                        LEFT JOIN
                        (
                            SELECT m.model, SUM(op.products_quantity) qty
                            FROM tmp_models2 m
                            LEFT JOIN t_product p ON m.model = p.product_code
                            LEFT JOIN orders_products op ON p.product_id = op.products_id
                            LEFT JOIN orders o FORCE INDEX (date2status) ON op.orders_id = o.orders_id
                            LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                            WHERE
                            o.date_purchased >= '$date' AND o.date_purchased <= '$date 23:59:59'
                            AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            GROUP BY m.model
                        ) t
                        ON mm.model = t.model
                        ORDER BY mm.id ASC";
				$results[$date] = $db->getAll($sql, PDO::FETCH_COLUMN);
			}

			$this->tpl->assign_by_ref('dates', $dates);
			$this->tpl->assign_by_ref('results', $results);

			// fetch models
			$sql = "SELECT model FROM tmp_models1 ORDER BY id ASC";
			$models = $db->getAll($sql, PDO::FETCH_COLUMN);

            if (isset($_POST['export'])) {
                $csvRows = array();
                foreach ($models as $k => $model) {
                    $csvRows[$k]['Frame Code'] = $model;
                    foreach ($dates as $date){
                        $csvRows[$k][$date] = $results[$date][$k];
                    }
                }
                $csvTitle = array('Frame Code');
                $csvTitle = array_merge($csvTitle, $dates);

                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($csvRows, $csvTitle);
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
                exit;
            }
			$this->tpl->assign_by_ref('models', $models);
		}
		$this->tpl->breadcrumb->add('Product Report');
		$this->display();
	}

	public function jobsRevenueReportAction()
	{
		if (Jcan_Http::isPost()) {
			$models = trim($_POST['models']);
			$from = addslashes(trim($_POST['from']));
			$to = addslashes(trim($_POST['to']));

			$results = array();
			$db = App_Db::getInstance();
			if ($models) {
				// get $modelArray
				$modelArray = preg_split("/\s+/", $models);
				$modelArray = Jcan_Array::unique($modelArray, false);
				foreach ($modelArray as &$_model) {
					$_model = addslashes($_model);
				}
				$models_str = implode("','", $modelArray);

				$sql = "SELECT op.products_model, SUM(op.products_quantity) AS jobs, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") AS revenue
                        FROM orders_products op
                        LEFT JOIN orders o FORCE INDEX (date2status) ON op.orders_id=o.orders_id
                        LEFT JOIN orders_ext oe ON (op.orders_id = oe.orders_id)
                        WHERE o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                            AND o.date_purchased >= '{$from} 00:00:00'
                            AND o.date_purchased <= '{$to} 23:59:59'
                            AND op.products_model IN ('{$models_str}')
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY op.products_id";
				$results = $db->getAll($sql, PDO::FETCH_ASSOC);
			}

            if (isset($_POST['export'])) {
                $csvTitle = array('Frame Code', 'Jobs', 'Revenue');

                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($results, array('products_model', 'jobs', 'revenue'));
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
                exit;
            }

			$this->tpl->assign_by_ref('results', $results);
		}
		$this->tpl->breadcrumb->add('Product salse job and revenue report');
		$this->display();
	}

	public function jobsFrameRevenueReportAction()
	{
		if (Jcan_Http::isPost()) {
			$models = trim($_POST['models']);
			$from = addslashes(trim($_POST['from']));
			$to = addslashes(trim($_POST['to']));

			$results = array();
			$db = App_Db::getInstance();
			if ($models) {
				// get $modelArray
				$modelArray = preg_split("/\s+/", $models);
				$modelArray = Jcan_Array::unique($modelArray, false);
				foreach ($modelArray as &$_model) {
					$_model = addslashes($_model);
				}
				$models_str = implode("','", $modelArray);

				$sql = "SELECT op.products_model, SUM(op.products_quantity) AS jobs, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.products_price)', 'tax_rate') . ") AS revenue
                        FROM orders_products op
                        LEFT JOIN orders o FORCE INDEX (date2status) ON op.orders_id=o.orders_id
                        LEFT JOIN orders_ext oe ON (op.orders_id = oe.orders_id)
                        WHERE o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                            AND o.date_purchased >= '{$from} 00:00:00'
                            AND o.date_purchased <= '{$to} 23:59:59'
                            AND op.products_model IN ('{$models_str}')
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY op.products_model";
				$results = $db->getAll($sql, PDO::FETCH_ASSOC);
			}
            if (isset($_POST['export'])) {
                $csvTitle = array('Frame Code', 'Jobs', 'Revenue');

                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($results, array('products_model', 'jobs', 'revenue'));
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
                exit;
            }
			$this->tpl->assign_by_ref('results', $results);
		}
		$this->tpl->breadcrumb->add('Frame Revenue Report');
		$this->display();
	}
        
        public function customersReportAction()
	{
		if (Jcan_Http::isPost()) {
			$orders = trim($_POST['orders']);
//			$from = addslashes(trim($_POST['from']));
//			$to = addslashes(trim($_POST['to']));

			$results = array();
			$db = App_Db::getInstance();
                        
			if ($orders) {
				// get $modelArray
				$orderArray = preg_split("/\s+/", $orders);
				$orderArray = Jcan_Array::unique($orderArray, false);

//				$sql = "";
//				$results = $db->getAll($sql, PDO::FETCH_ASSOC);
                                $orderMes = array();
                                foreach($orderArray as $orderId) {
                                    $sql = "SELECT * FROM orders WHERE orders_id = '%s' LIMIT 1";
                                    $sql = sprintf($sql, $orderId);
                                    $info = $db->getRow($sql);
                                    $isNew = $previousCnt = $jobsCnt = $revenue = $shipPrice = '';
                                    if ($info) {
                                        $sql = "SELECT count(*)
                                                FROM orders
                                                WHERE customers_id = %d
                                                    AND date_purchased <= '%s'
                                                    AND orders_id != '%s'
                                                    AND orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                                                ORDER BY date_purchased DESC";
                                        $sql = sprintf($sql, $info->customers_id, $info->date_purchased, $orderId);
                                        $previousCnt = $db->getOne($sql);
                                        $isNew = $previousCnt ? 'Return' : 'New';
                                        
                                        $sql = "SELECT SUM(products_quantity) as jobscnt
                                                FROM orders_products
                                                WHERE orders_id = '%s'";
                                        $sql = sprintf($sql, $orderId);
                                        $jobsCnt = $db->getOne($sql);
                                        
                                        $sql = "SELECT class, value_usd
                                                FROM orders_total
                                                WHERE orders_id = '%s' AND class IN ('total', 'shipping')";
                                        $sql = sprintf($sql, $orderId);
                                        $totalMap = $db->getAll($sql);
                                        foreach($totalMap as $map) {
                                            if($map->class == 'total') {
                                                $revenue = $map->value_usd;
                                            } 
                                            if ($map->class == 'shipping') {
                                                $shipPrice = $map->value_usd;
                                            }
                                        }
                                        $orderMes[$orderId]['Order Id'] = $orderId;
                                        $orderMes[$orderId]['New/Return'] = $isNew;
                                        $orderMes[$orderId]['Previous Order Count'] = $previousCnt;
                                        $orderMes[$orderId]['Number of Jobs'] = $jobsCnt;
                                        $orderMes[$orderId]['EBD Revenue'] = $revenue;
                                        $orderMes[$orderId]['EBD Shipping Price'] = $shipPrice;
                                    }
                                }
                        } else {
                            $orderMes =array();
                        }
                       
            if (isset($_POST['export'])) {
                $csvTitle = array('Order Id', 'New/Return', 'Previous Order Count', 'Number of Jobs', 'EBD Revenue', 'EBD Shipping Price');

                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($orderMes, array('Order Id', 'New/Return', 'Previous Order Count', 'Number of Jobs', 'EBD Revenue', 'EBD Shipping Price'));
                //$csv->setDataRange($this->tpl->from, $this->tpl->to);
                $csv->output();
                exit;
            }
			$this->tpl->assign_by_ref('results', $results);
		}
		$this->tpl->breadcrumb->add('Customer Order Report');
		$this->display();
	}
}