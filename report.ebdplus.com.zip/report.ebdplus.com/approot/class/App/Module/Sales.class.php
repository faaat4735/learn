<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
//require_once LIB_CLASS_DIR . "gapi.class.php";
require_once LIB_CLASS_DIR . "GoogleAnalytics.class.php";

class App_Module_Sales extends App_Module {

    const addGiftVoucher = true;

    public function __construct($tpl) {
        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $localeId = & $_GET['localeId'];
        $graphby = & $_GET['graphby'];
        $stat = & $_GET['stat'];
        $chart = & $_GET['chart'];
        $payment = & $_GET['payment'];
        $isnew = & $_GET['isnew'];
        $visitors = & $_GET['visitors'];
        $test = & $_GET['test'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month'));
        }
        if (!$to) {
            $to = date('Y-m-d');
        }
        if (!$localeId) {
            $localeId = 0;
        }

        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$stat) {
            $stat = 'volume';
        }
        if (!$chart) {
            $chart = 'line';
        }
        if (!is_array($payment)) {
            $payment = array('total');
        }

        //sortby
        $sortby = & $_GET['sortby'];
        if (!$sortby) {
            $sortby = 'number';
        }

        $countryId = & $_GET['country'];
        $country = '';
        if ($countryId) {
            $country = App_Model_Orders::getCountryName($countryId);
        }

        $product_id = & $_GET['pid'];
        $this->tpl->assign('pid', addslashes($product_id));
        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign('localeId', $localeId);
        $this->tpl->assign('countryId', $countryId);
        $this->tpl->assign('country', $country);
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('sortby', $sortby);
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('chart', $chart);
        $this->tpl->assign_by_ref('payment', $payment);
        $this->tpl->assign_by_ref('isnew', $isnew);
        $this->tpl->assign_by_ref('visitors', $visitors);
        $this->tpl->assign_by_ref('test', $test);
    }

    public function indexAction() {
        $this->reflect('Sales', 'total');
    }

    public function totalAction() {
        $this->tpl->breadcrumb->add('Orders');
        $this->display();
    }

    public function manilaAction() {
        $this->tpl->breadcrumb->add('Manilar Order');
        $this->display();
    }

    public function trialAction() {
        $this->tpl->breadcrumb->add('Free Trial');
        $this->display();
    }

    public function crystalAction() {
        $this->tpl->breadcrumb->add('Crystal');
        $this->display();
    }

    public function averageAction() {
        $this->tpl->breadcrumb->add('Average');
        $this->display();
    }

    public function buysafeAction() {
        $this->tpl->breadcrumb->add('BuySAFE');
        $this->display();
    }

    public function shippingAction() {
        $this->tpl->breadcrumb->add('Shipping Fee');
        $this->display();
    }

    public function voucherAction() {
        $this->tpl->breadcrumb->add('Voucher');
        $this->display();
    }

    public function jobsAction() {
        $this->tpl->breadcrumb->add('Jobs');
        $this->display();
    }

    public function rflktAction() {
        $this->tpl->breadcrumb->add('Rflkt');
        $this->display();
    }

    
    public function packageAction()
    {
        $this->tpl->breadcrumb->add('Packaging');
        $this->display();
    }
    
    public function packageChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();
        $percents = array();
        
        //groupby, $labels
        $graphby = $this->tpl->graphby;
        
        switch ($graphby) 
        {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }
        
        //status
        $states =& $_GET['states'];
        if (empty($states))
        {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        //locale
        if($this->tpl->localeId)
        {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        
        if($this->tpl->country)
        {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }
        
        $chart = new App_Chart();
        //Package jobs
        if(!isset($_GET['packagelines']) || isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('packagejobs', $_GET['packagelines']))
        {
            $sql = "SELECT $groupby grp, date_purchased, SUM(op.products_quantity) total
                            FROM t_order_product_opackaging opo 
                            LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
                            LEFT JOIN orders o ON o.orders_id = op.orders_id
                            LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                            LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                            WHERE o.orders_status IN ($_states)
                            %s
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            AND ot.class = 'total'
                            GROUP BY grp";            
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $packageRows = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $rows = $packageRows;
            $rows = $chart->fixRows($rows, $labels);
            $percents['Jobs'] = $packageRows;
            $line = $chart->getShape('line', count($labels), '#66cccc');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("Total Jobs");
            $line->appendTo($chart);
        }
        
        //Orders
        if(isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('packageorder', $_GET['packagelines']))
        {
            $sql = "SELECT $groupby grp, date_purchased, COUNT( DISTINCT o.orders_id) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_opackaging po ON op.orders_products_id = po.order_product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total' 
                    AND op.orders_id = o.orders_id
                    AND op.orders_products_id = po.order_product_id 
                    GROUP BY grp";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $rows = $orderRows;
            $rows = $chart->fixRows($rows, $labels);
            $percents['Orders'] = $orderRows;
            $line = $chart->getShape('line', count($labels), '#ff3399');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("Orders");
            $line->appendTo($chart);
        }
        if(isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('packagerevenue', $_GET['packagelines'])) {
            $sql = "SELECT $groupby grp, date_purchased, SUM(".App_Model_Orders::excludeTax('packaging_price', 'tax_rate')." * op.products_quantity) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_opackaging po ON op.orders_products_id = po.order_product_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND op.orders_id = o.orders_id
                    AND op.orders_products_id = po.order_product_id 
                    GROUP BY grp";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $rows = $orderRows;
            $rows = $chart->fixRows($rows, $labels);
            $percents['Orders'] = $orderRows;
            $line = $chart->getShape('line', count($labels), '#ffee99');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>Revenue : $#val# ');
            $line->setTitle("Packageing Revenue");
            $line->appendTo($chart);
        }
        if(isset($_GET['isnew'])) {// when is new, only show orders
            $sqlNew = "SELECT $groupby grp, date_purchased, COUNT(DISTINCT o.orders_id) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN tv_order_first fo ON fo.order_id = o.orders_id
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_opackaging po ON op.orders_products_id = po.order_product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total'
                    AND fo.uuid IS NOT NULL 
                    AND op.orders_id = o.orders_id 
                    AND op.orders_products_id = po.order_product_id 
                    GROUP BY grp";
            $sqlNew = sprintf($sqlNew, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRowsNew = $db->getAll($sqlNew, null, PDO::FETCH_NUM);
            
            $percents['Orders New'] = $rows = $orderRowsNew;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#009922');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("New Customers Orders");
            $line->appendTo($chart);
            
            
            $sqlOld = "SELECT $groupby grp, date_purchased, COUNT(DISTINCT o.orders_id) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN tv_order_first fo ON fo.order_id = o.orders_id
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_opackaging po ON op.orders_products_id = po.order_product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total'
                    AND fo.uuid IS NULL
                    AND op.orders_id = o.orders_id 
                    AND op.orders_products_id = po.order_product_id 
                    GROUP BY grp";
            $sqlOld = sprintf($sqlOld, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRowsOld = $db->getAll($sqlOld, null, PDO::FETCH_NUM);
            
            $percents['Orders Old'] = $rows = $orderRowsOld;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#ff6600');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("Old Customers Orders");
            $line->appendTo($chart);
            
        } else {
            // AOV
            if((isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('packageaov', $_GET['packagelines'])) 
                || (isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('packageajv', $_GET['packagelines']))
                || (isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('totalrevenue', $_GET['packagelines']))
                    )  {
                $sql = "SELECT $groupby, date_purchased, IF(COUNT(*), SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . "), 0) total, COUNT(*) number
                        FROM orders o FORCE INDEX (date2status)
                        LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE o.orders_status IN ($_states)
                        %s
                        AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        AND EXISTS(
                            SELECT po.order_product_id FROM orders_products op 
                            LEFT JOIN t_order_product_opackaging po ON op.orders_products_id = po.order_product_id
                            WHERE op.orders_id = o.orders_id 
                                    AND op.orders_products_id = po.order_product_id 
                            )
                        GROUP BY $groupby
                        ORDER BY o.orders_id ASC";
                $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $forAovUsd = $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
                foreach ($rows as $key => $row) {
                    $rows[$key][2] = round($rows[$key][2] / $rows[$key][3], 6);
                }
                $percents['AOV'] = $rows;
                if(in_array('packageaov', $_GET['packagelines'])) {
                    $rows = $chart->fixRows($rows, $labels);
                    $line = $chart->getShape('line', count($labels), '#33cc66');
                    $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                    $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : "#x_label#<br>AOV : \$#val#");
                    $line->setTitle("AOV");
                    $line->appendTo($chart);
                }
            }
            
            // Total Revenue
            if(isset($_GET['packagelines']) && $_GET['packagelines'] && in_array('totalrevenue', $_GET['packagelines'])) {
                $packageRevene = array();
                foreach($forAovUsd as $k => $v) {
                    $packageRevene[$k] = array($v[0], $v[1], $v[2]);
                }
                $percents['Revenue'] = $packageRevene;
                $rows = $chart->fixRows($packageRevene, $labels);
                $line = $chart->getShape('line', count($labels), '#660066');
                $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : "#x_label#<br>Total Revenue : \$#val#");
                $line->setTitle("Revenue");
                $line->appendTo($chart); 
            }
        }

        if(!empty($_GET['export'])) {
           $temp = array_keys($percents);
           array_unshift($temp, 'Time');
           $csv = new App_Csv();
           $rows = $csv->prepareCsvData ($percents);
           $csv->setHeader($temp);
           $csv->setData($rows, $temp);
           $csv->setDataRange($this->tpl->from, $this->tpl->to);
           $csv->output();
           exit;
       } 
       
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output(); 
    }

    public function rflktChartAction()
    {
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();
        $percents = array();
        //groupby, $labels
        $graphby = $this->tpl->graphby;

        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }



        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        $chart = new App_Chart();
        if (!isset($_GET['rflktlines']) || isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktorder', $_GET['rflktlines'])) {
            $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : 'COUNT(*)';
            $sql = "SELECT $groupby grp, date_purchased, $fieldTotal total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_product p ON op.products_id = p.product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total'
                    AND FIND_IN_SET('rflkt', p.product_attrs)
                    GROUP BY grp";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);

            $rows = $orderRows;
            $rows = $chart->fixRows($rows, $labels);
            $percents['Orders'] = $orderRows;
            $line = $chart->getShape('line', count($labels), '#66cccc');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("Total Orders");
            $line->appendTo($chart);
        }

        if (isset($_GET['isnew'])) {// when is new, only show orders
            $sqlNew = "SELECT $groupby grp, date_purchased, COUNT(*) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN tv_order_first fo ON fo.order_id = o.orders_id
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_product p ON op.products_id = p.product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total'
                    AND FIND_IN_SET('rflkt', p.product_attrs)
                    AND fo.uuid IS NOT NULL
                    GROUP BY grp";
            $sqlNew = sprintf($sqlNew, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRowsNew = $db->getAll($sqlNew, null, PDO::FETCH_NUM);

            $percents['Orders New'] = $rows = $orderRowsNew;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#009922');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("New Customers Orders");
            $line->appendTo($chart);


            $sqlOld = "SELECT $groupby grp, date_purchased, COUNT(*) total
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN tv_order_first fo ON fo.order_id = o.orders_id
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_product p ON op.products_id = p.product_id
                    LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND ot.class = 'total'
                    AND FIND_IN_SET('rflkt', p.product_attrs)
                    AND fo.uuid IS NULL
                    GROUP BY grp";
            $sqlOld = sprintf($sqlOld, $localeWhere, $this->tpl->from, $this->tpl->to);
            $orderRowsOld = $db->getAll($sqlOld, null, PDO::FETCH_NUM);

            $percents['Orders Old'] = $rows = $orderRowsOld;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#ff6600');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
            $line->setTitle("Old Customers Orders");
            $line->appendTo($chart);
        } else {
            if (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktjobs', $_GET['rflktlines'])) {
                $delSql = "DROP TEMPORARY TABLE IF EXISTS rflkt_orders";
                $db->exec($delSql);

                $rflktOrderSql = "CREATE TEMPORARY TABLE rflkt_orders
                                  SELECT o.orders_id
                                  FROM orders o FORCE INDEX (date2status) 
                                  LEFT JOIN orders_products op ON op.orders_id = o.orders_id 
                                  LEFT JOIN t_product p ON op.products_id = p.product_id
                                  LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                                  WHERE o.orders_status IN ($_states) 
                                  %s
                                  AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                                  AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                                  AND FIND_IN_SET('rflkt', p.product_attrs)";
                $rflktOrderSql = sprintf($rflktOrderSql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $db->exec($rflktOrderSql);

                $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : 'SUM(op.products_quantity)';
                $sql = "SELECT $groupby grp, date_purchased, $fieldTotal total
                        FROM rflkt_orders ro
                        LEFT JOIN orders o ON o.orders_id = ro.orders_id
                        LEFT JOIN orders_products op ON op.orders_id = ro.orders_id
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY grp";
                $sql = sprintf($sql);

                $forAjv = $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);

                if (in_array('rflktjobs', $_GET['rflktlines'])) {
                    $percents['Jobs'] = $rows = $orderRows;
                    $rows = $chart->fixRows($rows, $labels);
                    $line = $chart->getShape('line', count($labels), '#ff3399');
                    $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                    $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs (include other frame)');
                    $line->setTitle("Jobs");
                    $line->appendTo($chart);
                }
            }

            if ((isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktrealjobs', $_GET['rflktlines'])) || (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktajv', $_GET['rflktlines']))) {
                $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : 'SUM(op.products_quantity)';
                $sql = "SELECT $groupby grp, date_purchased, $fieldTotal total
                        FROM orders o FORCE INDEX (date2status)
                        LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                        LEFT JOIN t_product p ON op.products_id = p.product_id
                        LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE o.orders_status IN ($_states)
                        %s
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        AND ot.class = 'total'
                        AND FIND_IN_SET('rflkt', p.product_attrs)
                        GROUP BY grp";
                $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $newRealJobs = $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);

                $percents['Real Jobs'] = $rows = $orderRows;

                if (in_array('rflktrealjobs', $_GET['rflktlines'])) {
                    $rows = $chart->fixRows($rows, $labels);
                    $line = $chart->getShape('line', count($labels), '#cc33ff');
                    $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                    $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs (only rflkt)');
                    $line->setTitle("Real Jobs");
                    $line->appendTo($chart);
                }
            }

            // AOV
            if ((isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktaov', $_GET['rflktlines'])) || (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktajv', $_GET['rflktlines'])) || (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktrevenue', $_GET['rflktlines']))
            ) {
                $jobRows = array();
                $sql = "SELECT $groupby, date_purchased, IF(COUNT(*), SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . "), 0) total, COUNT(*) number
                        FROM orders o FORCE INDEX (date2status)
                        LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                        LEFT JOIN t_product p ON op.products_id = p.product_id
                        LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE o.orders_status IN ($_states)
                        %s
                        AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        AND FIND_IN_SET('rflkt', p.product_attrs)
                        GROUP BY $groupby
                        ORDER BY o.orders_id ASC";
                $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $forAjvUsd = $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
                foreach ($rows as $key => $row) {
                    $rows[$key][2] = round($rows[$key][2] / $rows[$key][3], 6);
                }
                $percents['AOV'] = $rows;
                if (in_array('rflktaov', $_GET['rflktlines'])) {
                    $rows = $chart->fixRows($rows, $labels);
                    $line = $chart->getShape('line', count($labels), '#33cc66');
                    $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                    $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : "#x_label#<br>AOV : \$#val#");
                    $line->setTitle("AOV");
                    $line->appendTo($chart);
                }
            }



            // AJV
            if (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktajv', $_GET['rflktlines'])) {
                if ($newRealJobs && $forAjvUsd) {
                    $jobTemp = array();
                    foreach ($forAjvUsd as $key => $value) {
                        $jobTemp[$value[0]] = $value[2];
                    }
                    $ajvData = array();
                    foreach ($newRealJobs as $k => $v) {
                        if (isset($jobTemp[$v[0]])) {
                            $ajvData[$k] = array($v[0], $v[1], round($jobTemp[$v[0]] / $v[2], 2));
                        }
                    }
                    $percents['AJV'] = $ajvData;
                    if ($ajvData) {
                        $rows = $chart->fixRows($ajvData, $labels);
                        $line = $chart->getShape('line', count($labels), '#999966');
                        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : "#x_label#<br>AJV : \$#val#");
                        $line->setTitle("AJV");
                        $line->appendTo($chart);
                    }
                }
            }

            // Revenue
            if (isset($_GET['rflktlines']) && $_GET['rflktlines'] && in_array('rflktrevenue', $_GET['rflktlines'])) {
                $rflktRevene = array();
                foreach ($forAjvUsd as $k => $v) {
                    $rflktRevene[$k] = array($v[0], $v[1], $v[2]);
                }
                $percents['Revenue'] = $rflktRevene;
                $rows = $chart->fixRows($rflktRevene, $labels);
                $line = $chart->getShape('line', count($labels), '#660066');
                $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : "#x_label#<br>Revenue : \$#val#");
                $line->setTitle("Revenue");
                $line->appendTo($chart);
            }
        }

        if (!empty($_GET['export'])) {
            $temp = array_keys($percents);
            array_unshift($temp, 'Time');
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($percents);
            $csv->setHeader($temp);
            $csv->setData($rows, $temp);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function jobsChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        // orders SQL
        $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : "COUNT(*)";
        $sql = "SELECT $groupby grp, date_purchased, $fieldTotal total
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_total ot
				ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.orders_status IN ($_states)
                %s
				AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
				AND ot.class = 'total'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY grp";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);

        $orderRows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // jobs SQL
        $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.products_price', 'tax_rate') . ")" : "SUM(op.products_quantity)";
        $sql = "SELECT $groupby grp, date_purchased, $fieldTotal total
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_products op
				ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.orders_status IN ($_states)
                %s
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY grp";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
        $jobRows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if (!empty($_GET['export'])) {
            $csv = new App_Csv();
            if ($this->tpl->stat != 'value') {
                // CR
                $crRows = array();
                foreach ($orderRows as $k => $row) {
                    $crRows[] = array($row[0], $row[1], ($jobRows[$k][2] / $row[2]));
                }
                $rows = $csv->prepareCsvData(array('Orders' => $orderRows, 'Jobs' => $jobRows, 'Rate' => $crRows));
                $csv->setHeader(array('Time', 'Orders', 'Jobs', 'Rate'));
                $csv->setData($rows, array('Time', 'Orders', 'Jobs', 'Rate'));
            } else {
                $rows = $csv->prepareCsvData(array('Orders' => $orderRows, 'Jobs' => $jobRows));
                $csv->setHeader(array('Time', 'Orders', 'Jobs'));
                $csv->setData($rows, array('Time', 'Orders', 'Jobs'));
            }
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        // chart
        $chart = new App_Chart();

        // apped orders chart
        $rows = $orderRows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#cccccc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
        $line->appendTo($chart);

        // append jobs chart
        $rows = $jobRows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
        $line->appendTo($chart);

        // append CR chart
        if ($this->tpl->stat != 'value') {
            // CR
            $crRows = array();
            foreach ($orderRows as $k => $row) {
                $crRows[] = array($row[0], $row[1], ($jobRows[$k][2] / $row[2]) * 100);
            }

            $rows = $crRows;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), '#009933', 1);
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0), '#ff9900', 2);
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs / 100 orders');
            $line->appendTo($chart);
        }

        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function totalChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        if (!empty($_GET['manila'])) {
            /*
              BayanTel: 121.97.52.12
              TelstraGlobal: 203.190.72.211
              EasternTelecoms: 112.199.123.202
             */
            $localeWhere .= " AND o.ip IN ('121.97.52.12', '203.190.72.211', '112.199.123.202', '61.14.191.34', '103.236.177.98', '103.236.177.28')";
        }

        //SQL
        if ($this->tpl->stat == 'value') {
            if (in_array('total', $this->tpl->payment)) {
                $sqlTotal = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
                        %s
						%s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);

                if (count($this->tpl->payment) == 1 && $this->tpl->isnew) {
                    $sqlNew = "SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info c
						ON c.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						$statusWhere
                        $localeWhere
						AND ot.class = 'total'
                        AND o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.order_id IS NOT NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";

                    $sqlOld = "SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info c
						ON c.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						$statusWhere
                        $localeWhere
						AND ot.class = 'total'
                        AND o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.order_id IS NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";
                }
            }

            if (in_array('cc', $this->tpl->payment)) {
                $sqlCc = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND (payment_method = 'Credit Card (secured by Authorize.net)' or  payment_method = 'Credit Card')
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('paypal', $this->tpl->payment)) {
                $sqlPaypal = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'PayPal'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('google', $this->tpl->payment)) {
                $sqlGoogle = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'Google Wallet'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('amazon', $this->tpl->payment)) {
                $sqlAmazon = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'Amazon Payments'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('giftcard', $this->tpl->payment)) {
                $sqlGiftcard = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
                        AND ot.class = 'total'
						AND ot.orders_id IN (SELECT orders_id FROM orders_total WHERE class = 'giftcard')
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }
        } else {

            if (in_array('total', $this->tpl->payment)) {
                $sqlTotal = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
                        %s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby); //print_r($sqlTotal);die;

                if (count($this->tpl->payment) == 1 && $this->tpl->isnew) {

                    $sqlNew = "SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info c
						ON c.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						$statusWhere
                        $localeWhere
						AND ot.class = 'total'
                        AND o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.order_id IS NOT NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";

                    $sqlOld = "SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info c
						ON c.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						$statusWhere
                        $localeWhere
						AND ot.class = 'total'
                        AND o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.order_id IS NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";
                }
            }

            if (in_array('cc', $this->tpl->payment)) {
                $sqlCc = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
						%s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND (payment_method = 'Credit Card (secured by Authorize.net)' or  payment_method = 'Credit Card')
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('paypal', $this->tpl->payment)) {
                $sqlPaypal = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
						%s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'PayPal'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('google', $this->tpl->payment)) {
                $sqlGoogle = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
						%s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'Google Wallet'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('amazon', $this->tpl->payment)) {
                $sqlAmazon = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
						%s
						AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
						AND payment_method = 'Amazon Payments'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }

            if (in_array('giftcard', $this->tpl->payment)) {
                $sqlGiftcard = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1 = 1
						%s
						%s
                        AND ot.class = 'total'
						AND ot.orders_id IN (SELECT orders_id FROM orders_total WHERE class = 'giftcard')
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
            }
        }

        // chart
        $chart = new App_Chart();
        if (!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvData = array();
            $csvTitles = array('Time');
        }
        //GA
        if ($this->tpl->visitors) {
            if (isset($_GET['localeId']) && $_GET['localeId'] == '2') {
                $googleId = GA_PROFILE_ID_AU;
            } elseif (isset($_GET['localeId']) && $_GET['localeId'] == '3') {
                $googleId = GA_PROFILE_ID_CA;
            } elseif (isset($_GET['localeId']) && $_GET['localeId'] == '4') {
                $googleId = GA_PROFILE_ID_FR;
            } elseif (isset($_GET['localeId']) && $_GET['localeId'] == '6') {
                $googleId = GA_PROFILE_ID_DE;
            } else {
                $googleId = GA_PROFILE_ID_US;
            }
            $apiGA = new \GoogleAnalytics($googleId);
            $gaResults = $apiGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visits', 'visitors'), null, array('date'));
            $ga_rows = array();
            $ga_rows_tmp = array();

            if ($graphby == 'weekly') {
                foreach ($gaResults as $result) {
                    $t_key = date('oW', strtotime($result[0]));
                    //$result->dimensions['year'].date('W',strtotime($result->dimensions['date']));
                    $ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count']) ? ($ga_rows_tmp[$t_key]['count'] + $result[5]) : $result[5];
                    if (!isset($ga_rows_tmp[$t_key]['date']))
                        $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s', strtotime($result[0]) + 10);
                }
                foreach ($ga_rows_tmp as $_key => $_value) {
                    $ga_rows[] = array($_key, $_value['date'], ($this->tpl->stat == 'value') ? $_value['count'] : round($_value['count'] / 20));
                }
            } elseif ($graphby == 'monthly') {
                foreach ($ga->getResults() as $result) {
                    $t_key = $result[2];
                    $ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count']) ? ($ga_rows_tmp[$t_key]['count'] + $result[5]) : $result[5];
                    if (!isset($ga_rows_tmp[$t_key]['date']))
                        $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s', strtotime($result[0]) + 10);
                }
                foreach ($ga_rows_tmp as $_key => $_value) {
                    $ga_rows[] = array($_key, $_value['date'], ($this->tpl->stat == 'value') ? $_value['count'] : round($_value['count'] / 20));
                }
            } elseif ($graphby == 'yearly') {
                foreach ($ga->getResults() as $result) {
                    $t_key = $result[4];
                    $ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count']) ? ($ga_rows_tmp[$t_key]['count'] + $result[5]) : $result[5];
                    if (!isset($ga_rows_tmp[$t_key]['date']))
                        $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s', strtotime($result[0]) + 10);
                }
                foreach ($ga_rows_tmp as $_key => $_value) {
                    $ga_rows[] = array($_key, $_value['date'], ($this->tpl->stat == 'value') ? $_value['count'] : round($_value['count'] / 20));
                }
            } else {
                foreach ($gaResults as $result) {
                    $ga_rows[] = array(date('Y-m-d', strtotime($result[0])), date('Y-m-d H:i:s', strtotime($result[0]) + 10), ($this->tpl->stat == 'value') ? $result[5] : round($result[5] / 20));
                }
            }
            if (!empty($_GET['export'])) {
                if ($this->tpl->stat != 'value') {
                    foreach ($ga_rows as $k => $v) {
                        $ga_rows[$k][2] = $v[2] * 20;
                    }
                }
                $csvData['visitors'] = $ga_rows;
                $csvTitles[] = 'visitors';
            } else {
                $ga_rows = $chart->fixRows($ga_rows, $labels);
                $line = $chart->getShape($this->tpl->chart, count($labels), '#EC995D');
                $line->setValues($chart->fetchColumn($ga_rows, 1, 'intval'), $chart->fetchColumn($ga_rows, 0));
                $line->setTip('#x_label#<br>Visitors: #val#' . (($this->tpl->stat == 'value') ? '' : '*20'));
                $line->setTitle('Visitors');
                $line->appendTo($chart);
            }
        }

        // settings
        $settings = array(
            'total' => array('Total', '#0033cc'),
            'cc' => array('Credit Card', '#009922'),
            'paypal' => array('Paypal', '#ff6600'),
            'google' => array('Google Wallet', '#ff00ff'),
            'amazon' => array('Amazon Payments', '#00aaaa'),
            'giftcard' => array('Gift Card', '#999900'),
        );


        $num = 0;

        foreach ($settings as $_name => $_arr) {
            $num++;

            if (in_array($_name, $this->tpl->payment)) {
                $rows = $db->getAll(${'sql' . ucfirst($_name)}, null, PDO::FETCH_NUM);
                // if total add voucher price
                if ((true == self::addGiftVoucher) &&
                        ('total' == $_name) && ('value' == $this->tpl->stat)) {
                    if ($this->tpl->localeId) {
                        $vcLocaleWhere = " AND go.locale_id = {$this->tpl->localeId} ";
                    } else {
                        $vcLocaleWhere = "";
                    }
                    $sqlPurchased = sprintf("
                                        SELECT $groupby, go.date_purchased, SUM(go.amount_usd) total
                                        FROM customers_gv_orders go
                                        LEFT JOIN customers_gv_orders_detail god
                                        ON go.gv_orders_id = god.gv_orders_id
                                        WHERE god.coupon_code IS NOT NULL
                                        AND go.date_purchased >= '%s 00:00:00' AND go.date_purchased <= '%s 23:59:59'
                                        $vcLocaleWhere
                                        GROUP BY $groupby
                                        ORDER BY go.gv_orders_id ASC
                                        ", $this->tpl->from, $this->tpl->to);
                    $vcRows = $db->getAll(${'sqlPurchased'}, null, PDO::FETCH_NUM);
                    $keyRows = array();
                    foreach ($rows as $value) {
                        $keyRows[$value[0]] = $value;
                    }

                    foreach ($vcRows as $row) {
                        // if exsist then add
                        if (isset($keyRows[$row[0]])) {
                            $keyRows[$row[0]][2] += $row[2];
                        } else {
                            // if empty add voucher date of this day
                            $keyRows[$row[0]] = $row;
                        }
                    }
                    $rows = $keyRows;
                }

                if (!empty($_GET['export'])) {
                    $csvData[$_name] = $rows;
                    if (!in_array($_name, $csvTitles)) {
                        $csvTitles[] = $_name;
                    }
                    continue;
                }

                $rows = $chart->fixRows($rows, $labels);

                $line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
                $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
                $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#' : '#x_label#<br>Total: #val#');
                $line->setTitle($_arr[0]);
                $line->appendTo($chart);
            }
        }



        // chart by new / old customers
        if (isset($sqlNew)) {

            $rows = $db->getAll($sqlNew, null, PDO::FETCH_NUM);
            if (!empty($_GET['export'])) {
                $csvData['New Customers'] = $rows;
                $csvTitles[] = 'New Customers';
            }
            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), '#990000');
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>New Customers: #val#');
            $line->setTitle('New Customers');
            $line->appendTo($chart);
        }
        if (isset($sqlOld)) {
            $rows = $db->getAll($sqlOld, null, PDO::FETCH_NUM);
            if (!empty($_GET['export'])) {
                $csvData['Old Customers'] = $rows;
                $csvTitles[] = 'Old Customers';
            }
            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), '#009900');
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Old Customers: #val#');
            $line->setTitle('Old Customers');
            $line->appendTo($chart);
        }

        if (!empty($_GET['export'])) {
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function averageChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        //SQL
        $sql = sprintf("SELECT $groupby, date_purchased, IF(COUNT(*), SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") / COUNT(*), 0) total
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_total ot
				ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE 1 = 1
				%s
                %s
				AND ot.class = 'total'
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY %s
				ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // chart
        $chart = new App_Chart();

        // fix rows
        $rows = $chart->fixRows($rows, $labels);

        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total: $#val#');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function shippingChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        //SQL
        if ($this->tpl->stat == 'value') {
            $sql = sprintf("SELECT $groupby groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON o.orders_id = ot.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE 1 = 1
					%s
					%s
					AND ot.class = 'shipping'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
        } else {
            $sql = sprintf("SELECT $groupby groupby, date_purchased, COUNT(*) total
					FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE 1 = 1
					%s
					%s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
        }
        //echo $sql;

        if (!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null, PDO::FETCH_OBJ);
            $csv = new App_Csv();
            $csv->setHeader(array('Time', 'Total'));
            $csv->setData($rows, array('groupby', 'total'));
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

        // chart
        $chart = new App_Chart();

        // fix rows
        $rows = $chart->fixRows($rows, $labels);

        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total: #val#');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function voucherChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupbyPurchased = 'YEARWEEK(go.date_purchased, 3)';
                $groupbyUsed = 'YEARWEEK(ct.redeem_date, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupbyPurchased = 'EXTRACT(YEAR_MONTH FROM go.date_purchased)';
                $groupbyUsed = 'EXTRACT(YEAR_MONTH FROM ct.redeem_date)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupbyPurchased = 'EXTRACT(YEAR FROM go.date_purchased)';
                $groupbyUsed = 'EXTRACT(YEAR FROM ct.redeem_date)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupbyPurchased = 'DATE(go.date_purchased)';
                $groupbyUsed = 'DATE(ct.redeem_date)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        $sqlPurchased = sprintf("
				SELECT $groupbyPurchased, go.date_purchased, COUNT(*) total
				FROM customers_gv_orders go
				LEFT JOIN customers_gv_orders_detail god
				ON go.gv_orders_id = god.gv_orders_id
				WHERE god.coupon_code IS NOT NULL
                AND go.date_purchased >= '%s 00:00:00' AND go.date_purchased <= '%s 23:59:59'
				GROUP BY $groupbyPurchased
				ORDER BY go.gv_orders_id ASC
				", $this->tpl->from, $this->tpl->to);
        $sqlUsed = sprintf("
			SELECT $groupbyUsed, ct.redeem_date, COUNT(*) total
			FROM coupon_redeem_track ct
			LEFT JOIN coupons c
			ON c.coupon_id = ct.coupon_id
			LEFT JOIN customers_gv_orders_detail god
			ON god.coupon_code = c.coupon_code
			WHERE god.gv_orders_id IS NOT NULL
            AND ct.redeem_date >= '%s 00:00:00' AND ct.redeem_date <= '%s 23:59:59'
			GROUP BY $groupbyUsed
			ORDER BY unique_id ASC
			", $this->tpl->from, $this->tpl->to);

        // chart
        $chart = new App_Chart();

        // settings
        $settings = array(
            'purchased' => array('Purchased', '#0033cc'),
            'used' => array('Used', '#009922'),
        );

        // append to chart
        $num = 0;
        foreach ($settings as $_name => $_arr) {
            $num++;

            $rows = $db->getAll(${'sql' . ucfirst($_name)}, null, PDO::FETCH_NUM);
            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Total: #val#');
            $line->setTitle($_arr[0]);
            $line->appendTo($chart);
        }

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function trialChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        if ($this->tpl->stat == 'value') {
            $sqlAll = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE o.try_free = 1
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $this->tpl->from, $this->tpl->to, $groupby);
            $sqlCharged = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
					LEFT JOIN orders_free_trial t
					ON t.orders_id = o.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE o.try_free = 1 AND t.charged = 1
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
					AND cc_number != '' AND cc_number IS NOT NULL
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $this->tpl->from, $this->tpl->to, $groupby);
        } else {
            $sqlAll = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE o.try_free = 1
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $this->tpl->from, $this->tpl->to, $groupby);
            $sqlCharged = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
					LEFT JOIN orders_free_trial t
					ON t.orders_id = o.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE o.try_free = 1 AND t.charged = 1
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
					AND cc_number != '' AND cc_number IS NOT NULL
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $this->tpl->from, $this->tpl->to, $groupby);
        }
        $allRows = $db->getAll($sqlAll, null, PDO::FETCH_NUM);
        $chargedRows = $db->getAll($sqlCharged, null, PDO::FETCH_NUM);

        // chart
        $chart = new App_Chart();

        // fix rows
        $allRows = $chart->fixRows($allRows, $labels);
        $chargedRows = $chart->fixRows($chargedRows, $labels);

        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($allRows, 1, 'intval'), $chart->fetchColumn($allRows, 0));
        $line->setTip('#x_label#<br>Total: #val#');
        $line->setTitle("All Free Trial");
        $line->appendTo($chart);

        $line_charged = new App_Chart_Line('#009922');
        $line_charged->setType('solid');
        $line_charged->setValues($chart->fetchColumn($chargedRows, 1, 'intval'), $chart->fetchColumn($chargedRows, 0));
        $line_charged->set_width(1);
        $line_charged->setTip('#x_label#<br>Total: #val#');
        $line_charged->setTitle("Charged");
        $line_charged->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function crystalChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        //SQL
        if ($this->tpl->stat == 'value') {
            $sql = sprintf("SELECT $groupby groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
					LEFT JOIN orders_products op ON (o.orders_id = op.orders_id AND o.orders_id > 62692)
                    LEFT JOIN t_order_product_olens opo ON op.orders_products_id = opo.order_product_id
                    LEFT JOIN t_order_product_option opop ON opo.olens_id = opop.olens_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE option_id = '3'
					%s
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
        } else {
            $sql = sprintf("SELECT $groupby groupby, date_purchased, COUNT(*) total
					FROM orders o FORCE INDEX (date2status)
					LEFT JOIN orders_total ot
					ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_products op ON (o.orders_id = op.orders_id AND o.orders_id > 62692)
                    LEFT JOIN t_order_product_olens opo ON op.orders_products_id = opo.order_product_id
                    LEFT JOIN t_order_product_option opop ON opo.olens_id = opop.olens_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
					WHERE option_id = '3'
					%s
					%s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY %s
					ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);
        }

        if (!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null, PDO::FETCH_OBJ);
            $csv = new App_Csv();
            $csv->setHeader(array('Time', 'Total'));
            $csv->setData($rows, array('groupby', 'total'));
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

        // chart
        $chart = new App_Chart();
        // fix rows
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total: #val#');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function categorypiechartAction() {
        $this->tpl->breadcrumb->add('Category (Pie)');
        $this->display();
    }

    public function categorypiechartChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        // get total by product_type
        $sql = "SELECT pm.product_type, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                GROUP BY pm.product_type";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $functionsRows = $db->getAll($sql);

        // get eyeglasses frame total
        $sql = "SELECT SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.products_price)', 'tax_rate') . ") total
                FROM orders o  FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('eyeglasses', pm.product_type)";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $frameTotal = $db->getOne($sql);

        // get rx sunglasses total
        $sql = "SELECT SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") total
                FROM orders o  FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('sunglasses', pm.product_type) AND FIND_IN_SET('prescription', p.product_attrs)";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $rxSunglassesTotal = $db->getOne($sql);

        // shipping
        $sql = "
			SELECT SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
			FROM orders o  FORCE INDEX (date2status)
			LEFT JOIN orders_total ot
			ON o.orders_id = ot.orders_id AND class = 'shipping'
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			$statusWhere
            %s
            ";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $shippingTotal = $db->getOne($sql);

        // retval
        // $functions = array('eyeglasses','sports','reading','clip-on','sunglasses','accessory');
        $retval = array(
            'Shipping' => $shippingTotal,
            'Eyeglasses (only frame)' => $frameTotal,
            'Rx Sunglasses (including lens)' => $rxSunglassesTotal,
        );
        foreach ($functionsRows as $row) {
            switch ($row->product_type) {
                case 'eyeglasses':
                    $retval['Lens (only for eyeglasses)'] = $row->total - $frameTotal;
                    break;
                case 'sunglasses':
                    $retval['Non-Rx Sunglasses'] = $row->total - $rxSunglassesTotal;
                    break;
            }
        }

        // draw graph
        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        asort($retval);
        foreach ($retval as $k => $v) {
            if ($v) {
                $num = round($v, 2);
                $tmp[] = new pie_value($num, $k);
            }
        }

        $pie->values = $tmp;
        $pie->tip = '#label#<br> #percent#';

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function categorylinechartAction() {
        $this->tpl->breadcrumb->add('Category (Line)');
        $this->display();
    }

    public function categorylinechartChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'YEARWEEK(go.date_purchased, 3)';
                }
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'EXTRACT(YEAR_MONTH FROM go.date_purchased)';
                }
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'EXTRACT(YEAR FROM go.date_purchased)';
                }
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'DATE(go.date_purchased)';
                }
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        if ($this->tpl->country) {
            $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
        }

        // data
        $data = array();

        // shipping
        $sql = "
			SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
			FROM orders o FORCE INDEX (date2status)
			LEFT JOIN orders_total ot
			ON o.orders_id = ot.orders_id AND class = 'shipping'
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			$statusWhere
            %s
			GROUP BY grp
			ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Shipping'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // lens (only for eyeglasses)
        $sql = "SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * (op.final_price - op.products_price))', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('eyeglasses', pm.product_type)
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Lens'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // eyeglasses (only frame)
        $sql = "SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.products_price)', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('eyeglasses', pm.product_type)
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Eyeglasses'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // rx sunglasses
        $sql = "SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('sunglasses', pm.product_type) AND FIND_IN_SET('prescription', p.product_attrs)
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Rx Sunglasses'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // non-rx sunglasses
        $sql = " SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('sunglasses', pm.product_type) AND !FIND_IN_SET('prescription', p.product_attrs)
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Non-Rx Sunglasses'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // sports sunglasses
        $sql = "SELECT $groupby grp, o.date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ") total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                LEFT JOIN t_product p ON op.products_id = p.product_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                $statusWhere
                %s
                AND FIND_IN_SET('sport', p.product_attrs)
                GROUP BY grp
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $this->tpl->from, $this->tpl->to, $localeWhere);
        $data['Sports Sunglasses'] = $db->getAll($sql, null, PDO::FETCH_NUM);

        // _data
        $_data = array();
        foreach ($data as $name => $rows) {
            $tmp = array();
            foreach ($rows as $row) {
                $tmp[$row[0]] = array($row[1], $row[2]);
            }
            $_data[$name] = $tmp;
        }

        // percents
        $percents = array();

        // AOV
        $sql = "
			SELECT $groupby, date_purchased, IF(COUNT(*), SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . "), 0) total, COUNT(*) number
			FROM orders o FORCE INDEX (date2status)
			LEFT JOIN orders_total ot
			ON (o.orders_id = ot.orders_id)
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE 1 = 1
			$statusWhere
            %s
			AND ot.class = 'total'
			AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY $groupby
			ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);

        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // AJV
        $sql = "
			SELECT $groupby, date_purchased, SUM(op.products_quantity)
			FROM orders o FORCE INDEX (date2status)
            LEFT JOIN orders_products op ON op.orders_id = o.orders_id
            LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
			WHERE 1 = 1
			$statusWhere
            %s
			AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY $groupby
			ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);

        $jobs = $db->getAll($sql, null, PDO::FETCH_NUM);
        foreach ($jobs as $value) {
            $jobTemp[$value[0]] = $value[2];
        }
        $jobRows = array();
        foreach ($rows as $key => $row) {
            if (isset($jobTemp[$row[0]])) {
                $jobRows[$key] = array($row[0], $row[1], round($rows[$key][2] / $jobTemp[$row[0]], 2));
            }
        }
        $percents['AJV'] = $jobRows;

        if (true == self::addGiftVoucher) {
            // vclocale
            if ($this->tpl->localeId) {
                $vcLocaleWhere = " AND go.locale_id = {$this->tpl->localeId} ";
            } else {
                $vcLocaleWhere = "";
            }
            // add voucher price
            $sqlPurchased = sprintf("
                    SELECT $vcgroupby, go.date_purchased, SUM(go.amount_usd) total
                    FROM customers_gv_orders go
                    LEFT JOIN customers_gv_orders_detail god
                    ON go.gv_orders_id = god.gv_orders_id
                    WHERE god.coupon_code IS NOT NULL
            %s
                    AND go.date_purchased >= '%s 00:00:00' AND go.date_purchased <= '%s 23:59:59'
                    GROUP BY $vcgroupby
                    ORDER BY go.gv_orders_id ASC
                    ", $vcLocaleWhere, $this->tpl->from, $this->tpl->to);
            $vcRows = $db->getAll(${'sqlPurchased'}, null, PDO::FETCH_NUM);
            $keyRows = array();
            foreach ($vcRows as $value) {
                $keyRows[$value[0]] = $value[2];
            }

            foreach ($rows as $key => $row) {
                // if exsist then add
                if (isset($keyRows[$row[0]])) {
                    $rows[$key][2] = round(($rows[$key][2] + $keyRows[$row[0]]) / $rows[$key][3], 6);
                } else {
                    $rows[$key][2] = round($rows[$key][2] / $rows[$key][3], 6);
                }
            }
        }

        $percents['AOV'] = $rows;

        foreach ($_data as $name => $rows) {
            $p = array();
            foreach ($rows as $date => $item) {
                $total = 0;
                foreach ($_data as $_name => $_rows) {
                    if (isset($_rows[$date])) {
                        $total += $_rows[$date][1];
                    }
                }
                $percent = round(($item[1] / $total) * 100, 2);
                $p[] = array($date, $item[0], $percent);
            }
            $percents[$name] = $p;
        }

        if (!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($percents);
            $csv->setHeader(array('Time', 'AJV', 'AOV', 'Shipping', 'Lens', 'Eyeglasses', 'Rx Sunglasses', 'Non-Rx Sunglasses', 'Sports Sunglasses'));
            $csv->setData($rows, array('Time', 'AJV', 'AOV', 'Shipping', 'Lens', 'Eyeglasses', 'Rx Sunglasses', 'Non-Rx Sunglasses', 'Sports Sunglasses'));
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        // chart
        $chart = new App_Chart();

        // apped chart
        $colors = array(
            '#3333ff', '#cc33ff', '#ff3399', '#3399ff', '#33cc66',
            '#999966', '#996600',
            '#cc0066', '#660066');
        $i = 0;
        foreach ($percents as $title => $rows) {
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), $colors[$i]);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($title == 'AOV' || $title == 'AJV' ? "#x_label#<br>{$title}: \$#val#" : "#x_label#<br>{$title}: #val#%");
            $line->setTitle($title);
            $line->appendTo($chart);
            $i++;
        }

        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function frameAction() {
        //export to csv
        if (!empty($_GET['export'])) {
            //from date & end date
            $from = & $_GET['from'];
            $to = & $_GET['to'];
            $localeId = & $_GET['localeId'];
            if (empty($from)) {
                $from = date('Y-m-d', strtotime('-2 month'));
            }
            if (empty($to)) {
                $to = date('Y-m-d');
            }

            if (!$localeId) {
                $localeId = 0;
            }

            //status
            $states = & $_GET['states'];
            if (empty($states)) {
                $states = App_Model_Orders::getCommonStatusList();
            }
            $_states = array_map('intval', $states);
            $_states = implode(', ', $_states);
            $statusWhere = "AND o.orders_status IN ({$_states})";

            //locale
            if ($localeId) {
                $localeWhere = " AND o.locale_id = {$localeId} ";
            } else {
                $localeWhere = "";
            }
            if ($this->tpl->country) {
                $localeWhere .= " AND o.delivery_country = '{$this->tpl->country}' ";
            }

            //sortby
            $sortby = & $_GET['sortby'];
            switch ($sortby) {
                case 'id':
                    $sortbyWhere = 'ORDER BY p.product_id ASC';
                    break;
                case 'code':
                    $sortbyWhere = 'ORDER BY p.product_code ASC';
                    break;
                case 'name':
                    $sortbyWhere = 'ORDER BY pm.product_name ASC';
                    break;
                case 'stock':
                    $sortbyWhere = 'ORDER BY p.product_quantity ASC';
                    break;
                case 'number':
                default:
                    $sortbyWhere = 'ORDER BY total ASC';
                    break;
            }

            //SQL
            $sql = sprintf("SELECT SUM(op.products_quantity) total, p.product_id, p.product_code, p.product_color, p.product_price, pm.product_name, date_purchased, p.product_quantity
					FROM orders o force index (date2status)
					LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id)
					LEFT JOIN orders_products op ON (op.orders_id = o.orders_id)
					LEFT JOIN t_product p ON (p.product_id = op.products_id)
                    LEFT JOIN t_product_ext pd ON (pd.product_id = p.product_id)
                    LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                    LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
					WHERE p.product_id IS NOT NULL
					%s
                    %s
					AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
					GROUP BY p.product_id $sortbyWhere", $statusWhere, $localeWhere, $from, $to);
            //echo $sql;exit;
            $rows = App_Db::getInstance()->getAll($sql);
            $csv = new App_Csv();
            $csv->setHeader(array('Product Code', 'Product Name', 'Color Name', 'Price($)', 'Order', 'Stock'));
            $csv->setData($rows, array('product_code', 'product_name', 'product_color', 'product_price', 'total', 'product_quantity'));
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }


        $this->tpl->breadcrumb->add('Sales by frame');
        $this->display();
    }

    public function discountAction() {
        if (!empty($this->tpl->pid)) {
            $db = App_Db::getInstance();
            $sql = sprintf("SELECT p.product_id, p.product_code, p.product_price, DATE(p.product_added) as product_added
                            FROM t_product p
                            LEFT JOIN t_product_ext pd ON p.product_id = pd.product_id
                            WHERE p.product_id = %d or p.product_code = '%s'", $this->tpl->pid, $this->tpl->pid);

            $info = $db->getRow($sql, null);
            $info->product_price = sprintf('%01.2f', $info->product_price);
            $this->tpl->proinfo = $info;
        }
        $this->tpl->breadcrumb->add('Sales by discount');
        $this->display();
    }

    public function discountChartAction() {
        $this->tpl->graphby = 'daily';
        $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
        $chartLabels = $labels;
        $db = App_Db::getInstance();

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        $product_id = $this->tpl->pid;
        if (!empty($product_id)) {
            /* $sql = "select pr.*, sum(op.products_quantity) as cnt
              FROM g_products_price_logs pr
              LEFT JOIN orders o ON DATE_FORMAT(o.date_purchased, '%Y-%m-%d')=pr.log_date
              LEFT JOIN orders_products op ON o.orders_id = op.orders_id
              WHERE  pr.products_id = op.products_id and pr.products_id=" . $product_id . "
              and pr.log_date >= '" . $this->tpl->from . "' and pr.log_date <= '". $this->tpl->to . "'
              AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
              group by pr.log_date
              order by pr.log_date asc"; */
            $$sql = sprintf("select pr.*, t.cnt
				FROM g_products_price_logs pr
				LEFT JOIN (
					SELECT DATE(o.date_purchased) as date_purchased, SUM(op.products_quantity) as cnt
					FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON o.orders_id = op.orders_id
                    LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
					WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
					AND op.products_id = %d
                    AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    %s
					GROUP BY DATE(o.date_purchased)
					) t on t.date_purchased = pr.log_date
				WHERE pr.products_id = %d
				AND pr.log_date >= '%s 00:00:00' AND pr.log_date <= '%s 23:59:59'
                ORDER BY pr.log_date ASC", $this->tpl->from, $this->tpl->to, $product_id, $localeWhere, $product_id, $this->tpl->from, $this->tpl->to);
            //and o.orders_status=3

            $rows = $db->getAll($sql, null, PDO::FETCH_ASSOC);

            $price_temp = 0;
            $key = -1;
            $last = array(0, 0);
            foreach ($rows as $r) {
                if (empty($r['cnt']))
                    $r['cnt'] = 0;
                if ($r['products_price'] != $price_temp) {
                    $price_temp = $r['products_price'];
                    $key = $key + 1;
                    if ($key > 0) {
                        $xRows[$key][] = array($last[0], $r['products_price'], $last[1]);
                        $xRows_revenue[$key][] = array($last[0], $r['products_price'], $last[2]);
                    }
                }
                $xRows[$key][] = array($r['log_date'], $r['products_price'], $r['cnt']);
                $xRows_revenue[$key][] = array($r['log_date'], $r['products_price'], $r['cnt'] * $r['products_price']);
                $last = array($r['log_date'], $r['cnt'], $r['cnt'] * $r['products_price']);
            }

            $colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa', '#0033cc', '#009922', '#ff6600', '#ff00ff');
            //print_r($xRows);
            //print_r($xRows_revenue);
            $chart = new App_Chart();

            foreach ($xRows as $key => $v) {
                $title = '$' . $v[0][1];
                $start = $v[0][0];
                $end = $v[count($v) - 1][0];

                $rows = $this->tpl->stat == 'value' ? $xRows_revenue[$key] : $v;
                $tip = $this->tpl->stat == 'value' ? 'Revenue' : 'Jobs';
                $rows = $chart->fixRowsNull($rows, $labels, $start, $end);
                $line = $chart->getShape($this->tpl->chart, count($labels), $colors[$key]);
                $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
                $line->setTip('#x_label#(#key#)<br>' . $tip . ': #val# ');
                $line->setTitle($title);
                $line->appendTo($chart);
            }
        } else {
            $sqlSum = ($this->tpl->stat == 'value') ? "SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.products_price)', 'tax_rate') . ")" : "SUM(op.products_quantity)";

            $sql = sprintf("SELECT  DATE(o.date_purchased), DATE(o.date_purchased) as date_purchased, %s as revenue
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_products op ON o.orders_id=op.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE  o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
				AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                %s
				GROUP BY DATE(o.date_purchased)
				ORDER BY DATE(o.date_purchased) ASC", $sqlSum, $this->tpl->from, $this->tpl->to, $localeWhere);
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

            $chart = new App_Chart();

            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#(#key#)<br>Total: #val# ');
            $line->setTitle('Jobs');
            $line->appendTo($chart);
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
        //print_r($rows);
        // temp data create
        /* unset($rows);
          $k=0;
          foreach($labels as $a){
          if($k%10==0) $price=6.95+$k;
          if($price=='26.95')$price=6.95 ;
          $rows[]=array('products_id' => '2130',
          'products_price' => $price,
          'log_date' => date('Y-m-d',strtotime('-2 month')+($k++)*86400) ,
          'cnt' => 20+($k%5==0?$k:$k/5));
          }
         */
        //print_r($rows);
    }

}
