<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
require_once LIB_CLASS_DIR . "gapi.class.php";

class App_Module_Coupon extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$statusList = App_Model_Orders::getStatusList();
		$this->tpl->assign_by_ref('statusList', $statusList);

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
        $localeId = & $_GET['localeId'];
		$graphby =& $_GET['graphby'];
		$stat =& $_GET['stat'];
		$chart =& $_GET['chart'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$stat) {
			$stat = 'volume';
		}
		if (!$chart) {
			$chart = 'line';
		}
        
        if (!$localeId) {
            $localeId = 0;
        }
		//sortby
		$sortby =& $_GET['sortby'];
		if (!$sortby) {
			$sortby = 'number';
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
        $this->tpl->assign('localeId', $localeId);
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('sortby', $sortby);
		$this->tpl->assign_by_ref('stat', $stat);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
                $this->tpl->groupinfo = App_Model_Coupon::getGroupList();
		$this->tpl->breadcrumb->add('Overall');
		$this->display();
	}

	public function indexChartAction()
	{
		// DB hanlder
		$db = App_Db::getInstance();

		// begin date, end date
		$beginDate = date('Y-m-d', strtotime($this->tpl->from));
		$endDate = date('Y-m-d', strtotime($this->tpl->to));

		// groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(crt.redeem_date, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM crt.redeem_date)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM crt.redeem_date)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(crt.redeem_date)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		// status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";
        
        //locale
        if($this->tpl->localeId)
        {
            $statusWhere .= " AND o.locale_id = {$this->tpl->localeId} ";
        }
        
		// sql
        $whereSql = $title = array();
        $linq = '1=1';
        if(!empty($_GET['groupid'])){
            $groupid = trim($_GET['groupid']);                       
            $groupInfo = App_Model_Coupon::getGroup($groupid);
            $whereSql[] = "group_id = $groupid";
            $title[] = $groupInfo->group_name;
        }
		if (!empty($_GET['code'])) {
            $code = trim($_GET['code']);
			$whereSql[] = "coupon_code = '$code'";
			$title[] = $code;
		} 
        if(!empty($whereSql)){
            $linq = implode(' and ', $whereSql);
            $title = implode('-', $title);
        }else{
            $title = 'Total Report';    
        }
		if ($this->tpl->stat == 'value') {
			$stat = "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")";
		} else {
			$stat = "COUNT(*)";
		}
		$sql = "SELECT $groupby groupby, crt.redeem_date, $stat total, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") value
                FROM coupon_redeem_track crt
                LEFT JOIN orders o FORCE INDEX (PRIMARY)
                ON o.orders_id = crt.order_id
                LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id AND ot.class = 'total')
                LEFT JOIN t_coupon c
                ON c.coupon_id = crt.coupon_id
                WHERE crt.redeem_date BETWEEN '$beginDate 00:00:00' AND '$endDate 23:59:59'
                AND $linq
                $statusWhere
                GROUP BY $groupby
                ORDER BY crt.unique_id ASC";
		// coupon rows
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $tmpRows = array();
        foreach ($rows as $row) $tmpRows[] = array($row[0],$row[1],round($row[2] != 0 ? $row[3]/$row[2] : 1, 2));
        if($this->tpl->stat != 'value') $percents[] = array('AOV',$tmpRows);
        $percents[] = array($title,$rows);
        if(!empty($_GET['export'])) {
            $res = $this->getCsvData ($percents);
            $csvData = $res['results'];
            $csvTitles = $res['titles'];
            if ($csvTitles) {
                $csv = new App_Csv();
                $csv->setHeader($csvTitles);
                $csv->setData($csvData, $csvTitles);
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            }
            exit;
        }
		// chart
		$chart = new App_Chart();

		// colors
		$colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa');

		$i = 0;
        foreach ($percents as $title=>$rows){
                $title = $rows[0];
                $rows = $rows[1];
                $color = $colors[$i];
                $rows = $chart->fixRows($rows, $labels);
                $line = $chart->getShape($this->tpl->chart, count($labels), $color);
                $type = $title == 'AOV' ? '%.2f' : 'intval';               
                $line->setValues($chart->fetchColumn($rows, 1, $type), $chart->fetchColumn($rows, 0));
                $line->setTip($title == 'AOV' ? "#x_label#<br>{$title}: \$#val#" : "#x_label#<br>{$title}: #val#");
                $line->setTitle($title);
                $line->appendTo($chart);
                $i++;
        }

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function topnAction()
	{
		$this->tpl->breadcrumb->add('Top 8 (Coupon ID)');
		$this->display();
	}

	public function topnChartAction()
	{
		// DB hanlder
		$db = App_Db::getInstance();

		// begin date, end date
		$beginDate = date('Y-m-d', strtotime($this->tpl->from));
		$endDate = date('Y-m-d', strtotime($this->tpl->to));
        
        //locale
        $localeWhere = '';
        if($this->tpl->localeId)
        {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        }
		// top N coupons in the time
		$sql = "SELECT c.coupon_id, c.coupon_code, COUNT(*) cnt
			FROM coupon_redeem_track crt
            LEFT JOIN orders o FORCE INDEX (PRIMARY) ON o.orders_id = crt.order_id
			LEFT JOIN t_coupon c
			ON crt.coupon_id = c.coupon_id
			WHERE crt.redeem_date BETWEEN '$beginDate 00:00:00' AND '$endDate 23:59:59' AND c.coupon_id IS NOT NULL
            " . $localeWhere . "
			GROUP BY crt.coupon_id
			ORDER BY cnt DESC
			LIMIT 8";
		$couponArray = $db->getAll($sql);

		// groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(crt.redeem_date, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM crt.redeem_date)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM crt.redeem_date)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(crt.redeem_date)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		// status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";

		// sql template
		if ($this->tpl->stat == 'value') {
			$stat = "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")";
			$joinOrderTotal = "LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id AND ot.class = 'total')";
		} else {
			$stat = 'COUNT(*)';
			$joinOrderTotal = '';
		}
		$_sql = "SELECT $groupby, crt.redeem_date, $stat total
			FROM coupon_redeem_track crt
			LEFT JOIN orders o FORCE INDEX (PRIMARY)
			ON o.orders_id = crt.order_id
			$joinOrderTotal
			WHERE crt.redeem_date BETWEEN '$beginDate 00:00:00' AND '$endDate 23:59:59'
			AND crt.coupon_id = %d
			$statusWhere
            $localeWhere
			GROUP BY $groupby
			ORDER BY crt.unique_id ASC";

		// get coupon array
		$couponRows = array();
		foreach ($couponArray as $_coupon) {
			$sql = sprintf($_sql, $_coupon->coupon_id);
			$couponRows[] = array($_coupon->coupon_code, $db->getAll($sql, null, PDO::FETCH_NUM));
		}

        if(!empty($_GET['export'])) {
            $res = $this->getCsvData ($couponRows);
            $csvData = $res['results'];
            $csvTitles = $res['titles'];
            if ($csvTitles) {
                $csv = new App_Csv();
                $csv->setHeader($csvTitles);
                $csv->setData($csvData, $csvTitles);
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            }
            exit;
        }
		// chart
		$chart = new App_Chart();

		// colors
		$colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa');
		foreach ($couponRows as $key => $coupon) {
			$couponCode = $coupon[0];
			$rows = $coupon[1];
			$color = $colors[$key];

			$rows = $chart->fixRows($rows, $labels);
			$line = $chart->getShape($this->tpl->chart, true, $color);
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>Total: #val#');
			$line->setTitle($couponCode);
			$line->appendTo($chart);
		}
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function topngroupAction()
	{
		$this->tpl->breadcrumb->add('Top 8 (Coupon Group)');
		$this->display();
	}

	public function topngroupChartAction()
	{
		// DB hanlder
		$db = App_Db::getInstance();

		// begin date, end date
		$beginDate = date('Y-m-d', strtotime($this->tpl->from));
		$endDate = date('Y-m-d', strtotime($this->tpl->to));

        //locale
        $localeWhere = ' ';
        if($this->tpl->localeId)
        {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        }
        
		// top N coupons in the time
		$sql = "SELECT c.group_id, COUNT(*) cnt
			FROM coupon_redeem_track crt
            LEFT JOIN orders o FORCE INDEX (PRIMARY) ON o.orders_id = crt.order_id
			LEFT JOIN t_coupon c
			ON crt.coupon_id = c.coupon_id
			WHERE crt.redeem_date BETWEEN '$beginDate 00:00:00' AND '$endDate 23:59:59' AND c.coupon_id IS NOT NULL AND c.group_id != 0
            " . $localeWhere . "
			GROUP BY c.group_id
			ORDER BY cnt DESC
			LIMIT 8";
		$_couponArray = $db->getAll($sql);
		$couponArray = array();
		foreach ($_couponArray as $_row) {
                        $sqlGroup = "SELECT group_name FROM t_coupon_group WHERE group_id = ".$_row->group_id;
                        $group_name = $db->getOne($sqlGroup);
			$couponArray[] = array(
                                'group_id' => $_row->group_id,
				'group_name' => $group_name,
			);
		}


		// groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(crt.redeem_date, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM crt.redeem_date)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM crt.redeem_date)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(crt.redeem_date)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		// status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";

		// sql template
		if ($this->tpl->stat == 'value') {
			$stat = "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")";
			$joinOrderTotal = "LEFT JOIN orders_total ot ON (o.orders_id = ot.orders_id AND ot.class = 'total')";
		} else {
			$stat = 'COUNT(*)';
			$joinOrderTotal = '';
		}
                $joinOrderTotal .= ' LEFT JOIN t_coupon c ON c.`coupon_id` = crt.`coupon_id` ';
		$_sql = "SELECT $groupby, crt.redeem_date, $stat total
			FROM coupon_redeem_track crt
			LEFT JOIN orders o FORCE INDEX (PRIMARY)
			ON o.orders_id = crt.order_id
			$joinOrderTotal
			WHERE crt.redeem_date BETWEEN '$beginDate 00:00:00' AND '$endDate 23:59:59'
			AND c.group_id = %d 
			$statusWhere
            $localeWhere
			GROUP BY $groupby
			ORDER BY crt.unique_id ASC";

		// get coupon array
		$couponRows = array();
		foreach ($couponArray as $_coupon) {
			$sql = sprintf($_sql, $_coupon['group_id']);
			$couponRows[] = array($_coupon['group_name'], $db->getAll($sql, null, PDO::FETCH_NUM));
		}
        if(!empty($_GET['export'])) {
            $res = $this->getCsvData ($couponRows);
            $csvData = $res['results'];
            $csvTitles = $res['titles'];
            if ($csvTitles) {
                $csv = new App_Csv();
                $csv->setHeader($csvTitles);
                $csv->setData($csvData, $csvTitles);
                $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            }
            exit;
        }
		// chart
		$chart = new App_Chart();

		// colors
		$colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa');
		foreach ($couponRows as $key => $coupon) {
			$couponCode = $coupon[0];
			$rows = $coupon[1];
			$color = $colors[$key];

			$rows = $chart->fixRows($rows, $labels);
			$line = $chart->getShape($this->tpl->chart, true, $color);
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>Total: #val#');
			$line->setTitle($couponCode);
			$line->appendTo($chart);
		}
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

    /**
     * prepare data for exporting csv file
     *
     * @param array $datas
     * @return array
     */
    private function getCsvData ($datas) {
        $result = array();
        $titles = array('Time');
        foreach ($datas as  $data) {
            if ($data[0]) {
                $title = $data[0];
                if (!in_array($title, $titles)) {
                    $titles[] = $title;
                }
                foreach ($data[1] as $v) {
                    if (!isset( $result[$v[0]])){
                         $result[$v[0]]['Time'] = $v[0];
                    }
                    $result[$v[0]][$title] = number_format($v[2], 2);
                }
            }
        }

        return array('results' => $result, 'titles' => $titles);
    }
}