<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Package extends App_Module
{

    public function __construct($tpl)
    {
        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        
        //bundling
        $bundlingList = App_Model_Orders::getLensBundlingList();
        $this->tpl->assign_by_ref('bundlingList', $bundlingList);

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $localeId = & $_GET['localeId'];
        $graphby = & $_GET['graphby'];
        $stat = & $_GET['stat'];
        $chart = & $_GET['chart'];
        $payment = & $_GET['payment'];
        $isnew = & $_GET['isnew'];
        $visitors = & $_GET['visitors'];
        $test = & $_GET['test'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month'));
        }
        if (!$to) {
            $to = date('Y-m-d');
        }
        if (!$localeId) {
            $localeId = 0;
        }

        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$stat) {
            $stat = 'volume';
        }
        if (!$chart) {
            $chart = 'line';
        }
        if (!is_array($payment)) {
            $payment = array('total');
        }

        //sortby
        $sortby = & $_GET['sortby'];
        if (!$sortby) {
            $sortby = 'number';
        }

        $product_id = & $_GET['pid'];
        $this->tpl->assign('pid', addslashes($product_id));
        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign('localeId', $localeId);
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('sortby', $sortby);
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('chart', $chart);
        $this->tpl->assign_by_ref('payment', $payment);
        $this->tpl->assign_by_ref('isnew', $isnew);
        $this->tpl->assign_by_ref('visitors', $visitors);
        $this->tpl->assign_by_ref('test', $test);
    }

    public function indexAction() 
    {
        $this->reflect('Package', 'total');
    }

    public function totalAction()
    {
        $this->tpl->breadcrumb->add('Total');
        $this->display();
    }
    
    public function ajvAction() 
    {
        $this->tpl->breadcrumb->add('ajv');
        $this->display();
    }
    
    public function upgradeAction() 
    {
        $this->tpl->breadcrumb->add('upgrade');
        $this->display();
    }
    
    public function aovAction() 
    {
        $this->tpl->breadcrumb->add('aov');
        $this->display();
    }

    public function productAction()
    {
        if (Jcan_Http::isPost()) {
            $models = trim($_POST['models']);
            $from = addslashes(trim($_POST['from']));
            $to = addslashes(trim($_POST['to']));

            $db = App_Db::getInstance();

            // create tmp table
            $sql = "CREATE TEMPORARY TABLE IF NOT EXISTS tmp_models1 (id INT(11) NOT NULL AUTO_INCREMENT, model VARCHAR(12) NOT NULL, PRIMARY KEY (id), UNIQUE KEY (model));";
            $db->query($sql);
            $sql = "CREATE TEMPORARY TABLE IF NOT EXISTS tmp_models2 (id INT(11) NOT NULL AUTO_INCREMENT, model VARCHAR(12) NOT NULL, PRIMARY KEY (id), UNIQUE KEY (model));;";
            $db->query($sql);

            if ($models) {
                // get $modelArray
                $modelArray = preg_split("/\s+/", $models);
                $modelArray = Jcan_Array::unique($modelArray, false);
                foreach ($modelArray as &$_model) {
                    $_model = addslashes($_model);
                }

                // insert table
                $_str = implode("'), ('", $modelArray);
                $sql = "INSERT IGNORE tmp_models1 (model) VALUES ('{$_str}')";
                $db->query($sql);
                $sql = "INSERT IGNORE tmp_models2 (model) VALUES ('{$_str}')";
                $db->query($sql);
            }
            $results = array();
            // fetch report
            $sql = "SELECT mm.model, po.product_name, IF(t.qty IS NULL, 0, t.qty) qty
                    FROM tmp_models1 mm
                    LEFT JOIN
                    (
                        SELECT m.model, SUM(op.products_quantity) qty
                        FROM tmp_models2 m
                        LEFT JOIN t_product p ON m.model = p.product_code
                        LEFT JOIN orders_products op ON p.product_id = op.products_id
                        LEFT JOIN orders o FORCE INDEX (date2status) ON op.orders_id = o.orders_id
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE
                        o.date_purchased >= '{$from}' AND o.date_purchased <= '{$to} 23:59:59'
                        AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY m.model
                    ) t
                    ON mm.model = t.model
                    LEFT JOIN t_product p ON mm.model = p.product_code
                    LEFT JOIN t_product_model po ON p.model_id = po.model_id 
                    ORDER BY mm.id ASC";
            $rows = $db->getAll($sql, PDO::FETCH_ASSOC);
            foreach ($rows as $row){
                $results[$row['model']] = $row;
            }
            
            // upgrade model
            $sql = "SELECT mm.model, IF(t.qty IS NULL, 0, t.qty) upgrade_qty
                    FROM tmp_models1 mm
                    LEFT JOIN
                    (
                        SELECT m.model, SUM(op.products_quantity) qty
                        FROM tmp_models2 m
                        LEFT JOIN t_product p ON m.model = p.product_code
                        LEFT JOIN orders_products op ON p.product_id = op.products_id
                        LEFT JOIN orders o FORCE INDEX (date2status) ON op.orders_id = o.orders_id
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE
                        o.date_purchased >= '{$from}' AND o.date_purchased <= '{$to} 23:59:59'
                        AND o.orders_status IN (1, 2, 3, 4, 8, 9, 10, 12, 14, 16, 18, 20)
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        AND op.final_price > (op.products_price + op.bundling_price)
                        GROUP BY m.model
                    ) t
                    ON mm.model = t.model
                    LEFT JOIN t_product p ON mm.model = p.product_code
                    LEFT JOIN t_product_model po ON p.model_id = po.model_id 
                    ORDER BY mm.id ASC";
            $rows = $db->getAll($sql, PDO::FETCH_ASSOC);
            foreach ($rows as $row){
                $results[$row['model']]['upgrade_qty'] = $row['upgrade_qty'];
            }

            $this->tpl->assign_by_ref('results', $results);

            if (isset($_POST['export'])) {
                $csvRows = $results;
                $csvTitle = array('model', 'product_name', 'qty', 'upgrade_qty' );

                $csv = new App_Csv();
                $csv->setHeader($csvTitle);
                $csv->setData($csvRows, $csvTitle);
                $csv->setDataRange($this->tpl->from, $this->tpl->to);
                $csv->output();
                exit;
            }
            $this->tpl->assign_by_ref('models', $models);
        }
        $this->tpl->breadcrumb->add('product');
        $this->display();
    }

    public function totalChartAction() 
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";
        
        //bundling_id
        $bundlings = & $_GET['bundlings'];
        $bundlingList = App_Model_Orders::getLensBundlingList();

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        //jobs SQL
        $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ")" : "SUM(op.products_quantity)";
        if(empty($bundlings)) {
            $sql = "SELECT $groupby groupby, date_purchased, $fieldTotal total
                    FROM orders o force index(date2status)
                    LEFT JOIN orders_products op
                    ON o.orders_id = op.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
                    WHERE o.orders_status IN ($_states)
                    AND op.bundling_id IN (" . implode(",", array_keys($bundlingList)). ")
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    GROUP BY groupby";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $_data['All package'] = $db->getAll($sql, null, PDO::FETCH_NUM);
        } else {
            foreach ( $bundlingList as $bundlingId => $bundle) {
                if (in_array($bundlingId, $bundlings)) {
                    $sql = "SELECT $groupby groupby, date_purchased, $fieldTotal total
                            FROM orders o force index(date2status)
                            LEFT JOIN orders_products op
                            ON o.orders_id = op.orders_id
                            LEFT JOIN orders_ext oe
                            ON (o.orders_id = oe.orders_id)
                            WHERE o.orders_status IN ($_states)
                            AND op.bundling_id = " . $bundlingId . "
                            %s
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            GROUP BY groupby";
                    $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                    $_data[$bundle] = $db->getAll($sql, null, PDO::FETCH_NUM);
                }
            }
        }

        
        //Export
        
        if(!empty($_GET['export'])) {
            $csvTitle = array_merge(array('Time'), array_keys($_data));
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($_data);
            $csv->setHeader($csvTitle);
            $csv->setData($rows, $csvTitle);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
        //chart
        $chart = new App_Chart();
         
        // apped  total chart
		$colors = array(
				'#3333ff', '#cc33ff', '#ff3399', '#3399ff', '#33cc66',
				'#999966', '#996600',
				'#cc0066', '#660066');
		$i = 0;
		foreach ($_data as $title => $rows) {
			$rows = $chart->fixRows($rows, $labels);
			$line = $chart->getShape($this->tpl->chart, count($labels), $colors[$i]);
			$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
			$line->setTitle($title);
			$line->appendTo($chart);
			$i++;
		}
        
        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
    
    
    public function ajvChartAction() 
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

       //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";
        
        //bundling_id
        $bundlings = & $_GET['bundlings'];
        $bundlingList = App_Model_Orders::getLensBundlingList();

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        
        
        // ajv SQL
        if(empty($bundlings)) {
            $sql = "SELECT $groupby groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.final_price)', 'tax_rate') . ") / SUM(op.products_quantity) AS ajv
                    FROM orders o force index(date2status)
                    LEFT JOIN orders_products op
                    ON o.orders_id = op.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
                    WHERE o.orders_status IN ($_states)
                    AND op.bundling_id IN (" . implode(",", array_keys($bundlingList)). ")
                    %s
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    GROUP BY groupby";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $_data['All package'] = $db->getAll($sql, null, PDO::FETCH_NUM);
        } else {
            foreach ( $bundlingList as $bundlingId => $bundle) {
                if (in_array($bundlingId, $bundlings)) {
                    $sql = "SELECT $groupby groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('(op.final_price)', 'tax_rate') . ") / SUM(op.products_quantity) AS ajv
                            FROM orders o force index(date2status)
                            LEFT JOIN orders_products op
                            ON o.orders_id = op.orders_id
                            LEFT JOIN orders_ext oe
                            ON (o.orders_id = oe.orders_id)
                            WHERE o.orders_status IN ($_states)
                            AND op.bundling_id = " . $bundlingId . "
                            %s
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            GROUP BY groupby";
                    $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                    $_data[$bundle] = $db->getAll($sql, null, PDO::FETCH_NUM);
                }
            }
        }
        
        //Export
        
        if(!empty($_GET['export'])) {
            $csvTitle = array_merge(array('Time'), array_keys($_data));
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($_data);
            $csv->setHeader($csvTitle);
            $csv->setData($rows, $csvTitle);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
        // chart
        $chart = new App_Chart();
              
        // apped ajv chart
        $colors = array(
				'#3333ff', '#cc33ff', '#ff3399', 
                                '#3399ff', '#33cc66','#999966',
                                '#996600','#cc0066', '#660066');
		$i = 0;
		foreach ($_data as $title => $rows) {
			//$rows = $ajvRows;
            $rows = $chart->fixRows($rows, $labels);
			$line = $chart->getShape($this->tpl->chart, count($labels), $colors[$i]);
			$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
			$line->setTitle($title);
			$line->appendTo($chart);
			$i++;
		}
        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
    
    
    public function upgradeChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";
        
        //bundling_id
        $bundlings = & $_GET['bundlings'];
        $bundlingList = App_Model_Orders::getLensBundlingList();

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        // upgrade_total SQL
        $fieldTotal = $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * op.final_price)', 'tax_rate') . ")" : "SUM(op.products_quantity)";
        if(empty($bundlings)) {
            $sql = "SELECT $groupby groupby, date_purchased, $fieldTotal AS upgrade_total
                FROM orders o force index(date2status)
                LEFT JOIN orders_products op
                ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
		WHERE o.orders_status IN ($_states)
                AND op.bundling_id IN (" . implode(",", array_keys($bundlingList)). ")
                AND op.final_price > (op.products_price + op.bundling_price)
                %s
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
		GROUP BY groupby";
            $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
            $_data['upgrade_total'] = $db->getAll($sql, null, PDO::FETCH_NUM);
        }
         else{
                foreach ( $bundlingList as $bundlingId => $bundle) {
                if (in_array($bundlingId, $bundlings)) {
            $sql = "SELECT $groupby groupby, date_purchased, $fieldTotal  AS upgrade_total
                FROM orders o force index(date2status)
                LEFT JOIN orders_products op
                ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
		WHERE o.orders_status IN ($_states)
                AND op.bundling_id = " . $bundlingId . "
                AND op.final_price > (op.products_price + op.bundling_price)
                %s
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                GROUP BY groupby";
                $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $_data[$bundle] = $db->getAll($sql, null, PDO::FETCH_NUM);    
            
                }
            }
        }
        
        //percent sql
        if ($this->tpl->stat == 'percent') {
            if(empty($bundlings)) {
                $sql = "SELECT $groupby groupby, date_purchased,  SUM(op.products_quantity) AS all_total
                        FROM orders o force index(date2status)
                        LEFT JOIN orders_products op
                        ON o.orders_id = op.orders_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
                        WHERE o.orders_status IN ($_states)
                        AND op.bundling_id IN (" . implode(",", array_keys($bundlingList)). ")
                        %s
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY groupby";
                $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                $tmpRows['upgrade_total'] = $db->getAll($sql, null, PDO::FETCH_NUM);
            } else {
                foreach ( $bundlingList as $bundlingId => $bundle) {
                    if (in_array($bundlingId, $bundlings)) {
                        $sql = "SELECT $groupby groupby, date_purchased, SUM(op.products_quantity) AS all_total
                                FROM orders o force index(date2status)
                                LEFT JOIN orders_products op
                                ON o.orders_id = op.orders_id
                                LEFT JOIN orders_ext oe
                                ON (o.orders_id = oe.orders_id)
                                WHERE o.orders_status IN ($_states)
                                AND op.bundling_id = " . $bundlingId . "
                                %s
                                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                                GROUP BY groupby";
                        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                        $tmpRows[$bundle] = $db->getAll($sql, null, PDO::FETCH_NUM);
                    }
                }
            }
            foreach($_data  as $bundle => $data) {
                foreach ($data as $key => $row) {
                     $_temp[$bundle][$row[0]] = $row[2];
                }
            }

            foreach ($tmpRows as $bundle => $data) {
                foreach ($data as $key => $row) {
                    if (isset($_temp[$bundle][$row[0]])) {
                        $_data[$bundle][$key]= array($row[0], $row[1], round($_temp[$bundle][$row[0]] *100 / $row[2], 2));
                    } 
                }
            }
        }  
//            $percentRows = array();
//            foreach($jobRows as $key => $value) {
//                $jobs[$value[0]] = $value[3];
//            }
//            foreach ($tmpRows as $key => $row) {
//                if (isset($jobs[$row[0]])) {
//                    $percentRows[$key]= array($row[0], $row[1], round($jobs[$row[0]] *100 / $row[2], 2));
//                } 
//            }
//        }
        
        
        
        
        
        //Export
        /*if(!empty($_GET['export'])) {
            $csvTitle = array('Time', 'upgrade_total');
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData(array('upgrade_total' => $upgradeRows));
            $csv->setHeader($csvTitle);
            $csv->setData($rows, $csvTitle);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }*/
        if(!empty($_GET['export'])) {
            $csvTitle = array_merge(array('Time'), array_keys($_data));
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($_data);
            $csv->setHeader($csvTitle);
            $csv->setData($rows, $csvTitle);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
        // chart
        $chart = new App_Chart();
         
        // append jobs chart
        $colors = array(
                        '#3333ff', '#cc33ff', '#ff3399', 
                        '#3399ff', '#33cc66','#999966',
                        '#996600','#cc0066', '#660066');
        $i = 0;
        foreach ($_data as $title => $rows) {
                $rows = $chart->fixRows($rows, $labels);
                $line = $chart->getShape($this->tpl->chart, count($labels), $colors[$i]);
                $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                $line->setTitle($title);
                $line->appendTo($chart);
                $i++;
        }
        
        // apped percent chart
        /*$rows = $percentRows;
        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#cccccc');
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Percent: #val#%');
        $line->setTitle('Percent');
        $line->appendTo($chart);*/
        
        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
    
    public function aovChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";
        
        //bundling_id
        $bundlings = & $_GET['bundlings'];
        $bundlingList = App_Model_Orders::getLensBundlingList();

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        // AOV SQL
        $valueExcludetax = "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")";
        $sql = "SELECT $groupby, date_purchased, $valueExcludetax / COUNT(*)
                FROM orders o force index(date2status)
                LEFT JOIN orders_total ot
                ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
                WHERE 1 = 1
                $statusWhere
                %s
                AND ot.class = 'total'
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                GROUP BY $groupby
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
        $_data['Normal AOV'] = $db->getAll($sql, null, PDO::FETCH_NUM);
        
        if(empty($bundlings)) {
        $sql = "SELECT $groupby, date_purchased, $valueExcludetax / COUNT(*)
                FROM orders o force index(date2status)
                LEFT JOIN orders_total ot
                ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
                WHERE 1 = 1
                AND EXISTS (
                    SELECT orders_id 
                    FROM orders_products op
                    WHERE op.orders_id = o.orders_id
                    AND op.bundling_id IN (" . implode(",", array_keys($bundlingList)). ")
                )
                $statusWhere
                %s
                AND ot.class = 'total'
                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                GROUP BY $groupby
                ORDER BY o.orders_id ASC";
        $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
        $_data['package_aov'] = $db->getAll($sql, null, PDO::FETCH_NUM);
       } else {
            foreach ( $bundlingList as $bundlingId => $bundle) {
                if (in_array($bundlingId, $bundlings)) {
                    $sql = "SELECT $groupby, date_purchased, $valueExcludetax / COUNT(*)
                            FROM orders o force index(date2status)
                            LEFT JOIN orders_total ot
                            ON (o.orders_id = ot.orders_id)
                            LEFT JOIN orders_ext oe
                            ON (o.orders_id = oe.orders_id)
                            WHERE 1 = 1
                            AND EXISTS (
                                SELECT orders_id 
                                FROM orders_products op
                                WHERE op.orders_id = o.orders_id
                                AND op.bundling_id ={$bundlingId}
                            )
                            $statusWhere
                            %s
                            AND ot.class = 'total'
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            GROUP BY $groupby
                            ORDER BY o.orders_id ASC";
                    $sql = sprintf($sql, $localeWhere, $this->tpl->from, $this->tpl->to);
                    $_data[$bundle] = $db->getAll($sql, null, PDO::FETCH_NUM);
                }
            }
        }
       
        //Export
        if(!empty($_GET['export'])) {
            $csvTitle = array_merge(array('Time'), array_keys($_data));
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($_data);
            $csv->setHeader($csvTitle);
            $csv->setData($rows, $csvTitle);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
        
        // chart
        $chart = new App_Chart();
         
        // append aov chart
        $colors = array(
                        '#3333ff', '#cc33ff', '#ff3399', '#3399ff', '#33cc66',
                        '#999966', '#996600',
                        '#cc0066', '#660066');
        $i = 0;
        foreach ($_data as $title => $rows) {
                $rows = $chart->fixRows($rows, $labels);
                $line = $chart->getShape($this->tpl->chart, count($labels), $colors[$i]);
                $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
                $line->setTitle($title);
                $line->appendTo($chart);
                $i++;
        }
        // echo
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
}
