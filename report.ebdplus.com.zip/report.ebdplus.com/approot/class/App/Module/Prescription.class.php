<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Prescription extends App_Module
{

    public function __construct($tpl)
    {
        parent::__construct($tpl);

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $graphby = & $_GET['graphby'];
        $stat = & $_GET['stat'];
        $chart = & $_GET['chart'];
        $rflkt = & $_GET['rflkt'];// when checked, value is 1
        if (!$from) {
            $from = date('Y-m-d', strtotime('-1 month -1 day'));
        }
        if (!$to) {
            $to = date('Y-m-d', strtotime('-1 day'));
        }
        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$stat) {
            $stat = 'volume';
        }
        if (!$chart) {
            $chart = 'bar';
        }
        if (!$rflkt) {
            $rflkt = 0;
        }
        $digital = & $_GET['digital'];
        if (!is_array($digital)) {
            $digital = array('sbrc', 'brc', 'eyezen_nonrx', 'eyezen_rx', 'eyezen_super');
        }
        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        
        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);        
        
        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('chart', $chart);
        $this->tpl->assign_by_ref('rflkt', $rflkt);
        $this->tpl->assign_by_ref('digital', $digital);

        $this->tpl->breadcrumb->add('Prescription Analytics');
    }

    public function indexAction()
    {
        $this->reflect('Prescription', 'usefor');
    }

    public function useforAction()
    {
        $this->tpl->breadcrumb->add('Use For');
        $this->display();
    }
    
    public function eyezenAction()
    {
        $this->tpl->breadcrumb->add('Eyezen');
        $this->display();
    }
    
    public function digitalAction()
    {
        $this->tpl->breadcrumb->add('Digital');
        $this->display();
    }

    public function lenstypeAction()
    {
        $this->tpl->breadcrumb->add('Lens Type');
        $this->display();
    }

    public function thicknessAction()
    {
        $this->tpl->breadcrumb->add('Lens Thickness');
        $this->display();
    }

    public function extrasAction()
    {
        $this->tpl->breadcrumb->add('Extras');
        $this->display();
    }

    public function sphAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $statusWhere = "AND o.orders_status = 5";

        /**
         * for refund
         */
        $sql = "SELECT FLOOR(opo.od_sph) val, SUM(op.products_quantity) total
			FROM t_order_product_orx opo
			LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
			LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
			LEFT JOIN  orders_ext oe ON o.orders_id = oe.orders_id
            WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
			$statusWhere
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY FLOOR(opo.od_sph)";
        $rows = $db->getAll($sql);

        $refundRows = array();
        foreach ($rows as $row) {
            $key = sprintf('%+.2f ~ %+.2f', $row->val, $row->val < 0 ? ($row->val - 0.75) : ($row->val + 0.75));
            $refundRows[$key] = $row->total;
        }
        arsort($refundRows);

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        $sql = "SELECT FLOOR(opo.od_sph) val, SUM(op.products_quantity) total
			FROM t_order_product_orx opo
			LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
			LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
			LEFT JOIN  orders_ext oe ON o.orders_id = oe.orders_id
            WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
			$statusWhere
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY FLOOR(opo.od_sph)";
        $rows = $db->getAll($sql);

        $orderRows = array();
        foreach ($rows as $row) {
            $key = sprintf('%+.2f ~ %+.2f', $row->val, $row->val < 0 ? ($row->val - 0.75) : ($row->val + 0.75));
            $orderRows[$key] = $row->total;
        }
        arsort($orderRows);

        $this->tpl->breadcrumb->add('SPH Range');
        $this->tpl->assign_by_ref('refundRows', $refundRows);
        $this->tpl->assign_by_ref('orderRows', $orderRows);
        $this->display();
    }
    
    public function eyezenRefundChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $statusWhere = "AND o.orders_status = 5";

        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT  tolpo.index_id,orx.od_sph,orx.od_cyl,orx.os_sph,orx.os_cyl, op.products_quantity total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                                LEFT JOIN t_order_product_orx orx ON orx.order_product_id = op.orders_products_id 
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				AND tolpo.use_id = 19";
        } else {
            $sql = "SELECT tolpo.index_id,orx.od_sph,orx.od_cyl,orx.os_sph,orx.os_cyl, ot.value total
				FROM t_order_product_olens tolpo
                                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                                LEFT JOIN t_order_product_orx orx ON orx.order_product_id = op.orders_products_id 
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				AND tolpo.use_id = 19";
        }

        $rows = $db->getAll($sql, null);
        $data = array();
        $data['prescription(1.67)'] = 0;
        $data['prescription(1.59)'] = 0;
        $data['plano'] = 0;
        foreach($rows as $k => $row) {
            if (($row->od_sph && $row->od_sph != '0.00') || ($row->od_cyl && $row->od_cyl != '0.00') || ($row->os_sph && $row->os_sph != '0.00') || ($row->os_cyl && $row->os_cyl != '0.00')) {
                if (isset($data['prescription(' . $row->index_id . ')'])) {
                    $data['prescription(' . $row->index_id . ')'] += $row->total;
                } else {
                    $data['prescription(' . $row->index_id . ')'] = 0;
                    $data['prescription(' . $row->index_id . ')'] += $row->total;
                }
            } else {
                $data['plano'] += $row->total;
            }
        }

        arsort($data);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($data);
            $csvTitles = array('Eyezen', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Eyezen Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($data as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }
    
    public function eyezenOrderChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.index_id,orx.od_sph,orx.od_cyl,orx.os_sph,orx.os_cyl,op.products_quantity total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op
				ON op.orders_products_id = tolpo.order_product_id
                                LEFT JOIN t_order_product_orx orx ON orx.order_product_id = op.orders_products_id 
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				AND tolpo.use_id = 19";
        } else {
            $sql = "SELECT tolpo.index_id,orx.od_sph,orx.od_cyl,orx.os_sph,orx.os_cyl, ot.value_usd total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op
                ON op.orders_products_id = tolpo.order_product_id
                LEFT JOIN t_order_product_orx orx ON orx.order_product_id = op.orders_products_id 
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				AND tolpo.use_id = 19";
        }
        $rows = $db->getAll($sql, null);
        $data = array();
        $data['prescription(1.67)'] = 0;
        $data['prescription(1.59)'] = 0;
        $data['plano'] = 0;
        foreach($rows as $k => $row) {
            if (($row->od_sph && $row->od_sph != '0.00') || ($row->od_cyl && $row->od_cyl != '0.00') || ($row->os_sph && $row->os_sph != '0.00') || ($row->os_cyl && $row->os_cyl != '0.00')) {
                if (isset($data['prescription(' . $row->index_id . ')'])) {
                    $data['prescription(' . $row->index_id . ')'] += $row->total;
                } else {
                    $data['prescription(' . $row->index_id . ')'] = 0;
                    $data['prescription(' . $row->index_id . ')'] += $row->total;
                }
            } else {
                $data['plano'] += $row->total;
            }
        }

        arsort($data);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($data);
            $csvTitles = array('Eyezen', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Eyezen Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($data as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }
    
    public function useforRefundChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $statusWhere = "AND o.orders_status = 5";

        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.use_id, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.use_id";
        } else {
            $sql = "SELECT tolpo.use_id, SUM(" . App_Model_Orders::excludeTax('ot.value', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.use_id";
        }
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
		$usefor = array(
            'Distance' => [1, 15, 17],
            'Reading' => [13],
            'Bifocal' => [3],
            //'Progressive' => [5],
            //'Computer' => [11],
            'Fashion' => [9],
			//'Trifocal' => [],
            'Free Form' => [7],
            'Eyezen' => [19]
        );
		
        $useforArray = array(
            'Distance' => 0,
            'Reading' => 0,
            'Bifocal' => 0,
            //'Progressive' => 0,
            //'Computer' => 0,
            'Fashion' => 0,
            //'Trifocal' => 0,
            'Free Form' => 0,
            'Eyezen' => 0
        );
        foreach ($rows as $row) {
            /*
              $row[0]:
              Bifocal/progressive	=> Bifocal/Progressive
              Bifocal/Progressive (Both distance and reading)	=> Bifocal/Progressive
              Computer (Intermediate)	=> Computer
              Computer Work (FREE)	=> Computer
              Distance (To see far)	=> Distance
              Everything/Distance (FREE)	=> Distance
              Fashion (Without prescription)	=> Fashion
              Fashion only (FREE)		=> Fashion
              Reading (FREE)			=> Reading
              Reading (To see near)		=> Reading

              Distance - Single vision (General use)	=> Distance
              Reading - To see near			=> Reading
              Bifocal - Both distance and reading with a line	=> Bifocal/Progressive
              Progressive - Bifocal without a line	=> Bifocal/Progressive
             */
            /*
              foreach ($useforArray as $key => $value) {
              if (stripos($row[0], $key) === 0 || ($key == 'Distance' && stripos($row[0], 'Everything') === 0)) {
              $useforArray[$key] += $row[1];
              break;
              }
              }
             */
//            foreach ($useforArray as $key => $value) {
//                if (strncasecmp($key, $row[0], strlen($key)) == 0) {
//                    $useforArray[$key] += $row[1];
//                    break;
//                }
//            }
			 foreach ($usefor as $key => $value) {
                if (in_array($row[0], $value)) {
                    $useforArray[$key] += $row[1];
                    break;
                }
            }
        }
        $rows = $useforArray;
        arsort($rows);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Use For', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function useforOrderChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.use_id, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op
				ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.use_id";
            //echo $sql;exit();
        } else {
            $sql = "SELECT tolpo.use_id, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op
                ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.use_id";
        }
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

		$usefor = array(
            'Distance' => [1, 15, 17],
            'Reading' => [13],
            'Bifocal' => [3],
            //'Progressive' => [5],
            //'Computer' => [11],
            'Fashion' => [9],
			//'Trifocal' => [],
            'Free Form' => [7],
            'Eyezen' => [19]
        );
		
        $useforArray = array(
            'Distance' => 0,
            'Reading' => 0,
            'Bifocal' => 0,
            //'Progressive' => 0,
            //'Computer' => 0,
            'Fashion' => 0,
            //'Trifocal' => 0,
            'Free Form' => 0,
            'Eyezen' => 0
        );
        foreach ($rows as $row) {
            foreach ($usefor as $key => $value) {
                if (in_array($row[0], $value)) {
                    $useforArray[$key] += $row[1];
                    break;
                }
            }
        }
        $rows = $useforArray;
        arsort($rows);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Use For', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function useforRedoChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        $url = "http://crm.eyebuydirect.com/webmail2/interface_report_get_return_info.php?action=Replacement";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($ch);
        curl_close($ch);

        $order_ids = $response;

        $insertsql = "('" . implode("'), ('", explode(",", $order_ids)) . "')";
        $db->query('CREATE TEMPORARY TABLE temp_redo_orders( `orders_id` char( 13 ) NOT NULL, INDEX (orders_id))');
        $db->query("insert into temp_redo_orders(orders_id)  VALUES " . $insertsql);

        /**
         * for redo
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT topo.use_name, SUM(op.products_quantity) total
				FROM t_order_product_olens topo
				LEFT JOIN orders_products op ON op.orders_products_id = topo.order_product_id
				LEFT JOIN temp_redo_orders tro ON tro.orders_id=op.orders_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = tro.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY topo.use_name";
        } else {
            $sql = "SELECT topo.use_name, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens topo
                LEFT JOIN orders_products op ON op.orders_products_id = topo.order_product_id
				LEFT JOIN temp_redo_orders tro ON tro.orders_id = op.orders_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = tro.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY topo.use_name";
        }

        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $useforArray = array(
            'Distance' => 0,
            'Reading' => 0,
            'Bifocal' => 0,
            'Progressive' => 0,
            'Computer' => 0,
            'Fashion' => 0,
            'Trifocal' => 0,
            'Free Form' => 0,
        );
        foreach ($rows as $row) {

            foreach ($useforArray as $key => $value) {
                if (strncasecmp($key, $row[0], strlen($key)) == 0) {
                    $useforArray[$key] += $row[1];
                    break;
                }
            }
        }
        $rows = $useforArray;
        arsort($rows);
        // draw graph
        $title = new title('Replacement Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function lenstypeRefundChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $statusWhere = "AND o.orders_status = 5";
        $rflktJoin = $this->tpl->rflkt == 1 ? "LEFT JOIN t_product p ON op.products_id = p.product_id" : '';
        $rflktWhere = $this->tpl->rflkt == 1 ? "AND FIND_IN_SET('rflkt', p.product_attrs)" : ''; 
        
        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT opo.lens_type, SUM(op.products_quantity) total
				FROM t_order_product_olens opo
				LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY opo.lens_type";
        } else {
            $sql = "SELECT opo.lens_type, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens opo
                LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY opo.lens_type";
            //(opa.products_options = 'Lens upgrades 4' OR opa.products_options = 'Lens upgrades 5' OR opa.products_options = 'Lens upgrades 6' OR opa.products_options = 'Lens upgrades 9' OR opa.products_options = 'Lens upgrades 13')
        }
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $typeArray = array(
            'Single Vision' => 0,
            'Bifocal' => 0,
            //'Progressive' => 0,
            'Free Form' => 0,
            'Eyezen' => 0,
        );
        foreach ($rows as $row) {
            /*
              $row[0]:
              Lens upgrades 6		Single Vision
              Lens upgrades 5		Progressive Lens (no line)
              Lens upgrades 4		Bifocal Lens (with line)
             */
            if ($row[0] == 'bifocal') {
                $typeArray['Bifocal'] += $row[1];
            } elseif ($row[0] == 'single-vision') {
                $typeArray['Single Vision'] += $row[1];
            } elseif ($row[0] == 'free-form') {
                $typeArray['Free Form'] += $row[1];
            } else {
                $typeArray['Eyezen'] += $row[1];
            }
        }
        $rows = $typeArray;
        arsort($rows);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Lens Type', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function lenstypeOrderChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        $rflktJoin = $this->tpl->rflkt == 1 ? "LEFT JOIN t_product p ON op.products_id = p.product_id" : '';
        $rflktWhere = $this->tpl->rflkt == 1 ? "AND FIND_IN_SET('rflkt', p.product_attrs)" : ''; 
        
        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.lens_type, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.lens_type";
        } else {
            $sql = "SELECT tolpo.lens_type, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.lens_type";
        }
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $typeArray = array(
            'Single Vision' => 0,
            'Bifocal' => 0,
            //'Progressive' => 0,
            'Free Form' => 0,
            'Eyezen' => 0,
        );
        foreach ($rows as $row) {
            /*
              $row[0]:
              Lens upgrades 6		Single Vision
              Lens upgrades 5		Progressive Lens (no line)
              Lens upgrades 4		Bifocal Lens (with line)
             */
            if ($row[0] == 'bifocal') {
                $typeArray['Bifocal'] += $row[1];
            } elseif ($row[0] == 'single-vision') {
                $typeArray['Single Vision'] += $row[1];
            } elseif ($row[0] == 'free-form') {
                $typeArray['Free Form'] += $row[1];
            } else {
                $typeArray['Eyezen'] += $row[1];
            }
        }
        $rows = $typeArray;
        arsort($rows);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Lens Type', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function sphRefundChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $statusWhere = "AND o.orders_status = 5";

        /**
         * for refund
         */
        $sql = "SELECT FLOOR(opo.od_sph) val, SUM(op.products_quantity) total
			FROM t_order_product_orx opo
			LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
			LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
			LEFT JOIN  orders_ext oe ON o.orders_id = oe.orders_id
			WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
			$statusWhere
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY FLOOR(opo.od_sph)";
        $rows = $db->getAll($sql);

        $data = array();
        foreach ($rows as $row) {
            $key = sprintf('%+.2f ~ %+.2f', $row->val, $row->val < 0 ? ($row->val - 0.75) : ($row->val + 0.75));
            $data[$key] = $row->total;
        }
        $rows = $data;
        arsort($rows);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('SPH', 'Jobs', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function sphOrderChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        $sql = "SELECT FLOOR(opo.od_sph) val, SUM(op.products_quantity) total
			FROM t_order_product_orx opo
			LEFT JOIN orders_products op ON op.orders_products_id = opo.order_product_id
			LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
			LEFT JOIN  orders_ext oe ON o.orders_id = oe.orders_id
			WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
			$statusWhere
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY FLOOR(opo.od_sph)";
        //opa.products_options = 'Right Sphere(SPH)'
        $rows = $db->getAll($sql);

        $data = array();
        foreach ($rows as $row) {
            $key = sprintf('%+.2f ~ %+.2f', $row->val, $row->val < 0 ? ($row->val - 0.75) : ($row->val + 0.75));
            $data[$key] = $row->total;
        }
        $rows = $data;
        arsort($rows);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('SPH', 'Jobs', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');
        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        $pie->tip = '#label#<br>#val# of #total# (#percent#)';

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function thicknessOrderChartAction()
    {
        $rows = $this->_getThicknessRows();
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Lens Thinkness', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function thicknessRefundChartAction()
    {
        $rows = $this->_getThicknessRows(true);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Lens Thinkness', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    protected function _getThicknessRows($refund = false)
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        if ($refund) {
            $statusWhere = "AND o.orders_status = 5";
        } else {
            $states = App_Model_Orders::getCommonStatusList();
            $_states = array_map('intval', $states);
            $_states = implode(', ', $_states);
            $statusWhere = "AND o.orders_status IN ({$_states})";
        }

        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.index_id, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.index_id";
            /*
              opa.products_options = 'Lens upgrades 1'
              OR opa.products_options = 'Lens upgrades 2'
              OR opa.products_options = 'Lens upgrades 3'
              OR opa.products_options = 'Lens upgrades 7'
              OR opa.products_options = 'Lens upgrades 8'
              OR opa.products_options = 'Lens upgrades 9'
              OR opa.products_options = 'Lens upgrades 10'
              OR opa.products_options = 'Lens upgrades 18'
              OR opa.products_options = 'Lens upgrades 19'
             * *
             */
        } else {
            $sql = "SELECT tolpo.index_id, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.index_id";
        }

        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $typeArray = array(
            '1.5' => 0,
            '1.57' => 0,
            '1.59' => 0,
            '1.6' => 0,
            '1.67' => 0,
            '1.74' => 0
        );
        foreach ($rows as $row) {
            /*
              $row[0]:
              Lens upgrades 1		Standard (1.5)
              Lens upgrades 2		Thin and Lite (1.57)
              Lens upgrades 10	Polycarbonate (1.59)
              Lens upgrades 9		Polycarbonate Bifocal
              Lens upgrades 3		Super Thin (1.6)
              Lens upgrades 7		Ultra Thin (1.67)
              Lens upgrades 8		As Thin as possible (1.74)
             */
            $row[0] = trim($row[0]);

            if ($row[0] == '1.5') {
                $typeArray['1.5'] += $row[1];
            } else if ($row[0] == '1.57') {
                $typeArray['1.57'] += $row[1];
            } else if ($row[0] == '1.59') {
                $typeArray['1.59'] += $row[1];
            } else if ($row[0] == '1.6') {
                $typeArray['1.6'] += $row[1];
            } else if ($row[0] == '1.67') {
                $typeArray['1.67'] += $row[1];
            } else if ($row[0] == '1.74') {
                $typeArray['1.74'] += $row[1];
            }
        }
        foreach ($typeArray as $k => $v) {
            if ($v == 0) {
                unset($typeArray[$k]);
            }
        }
        $rows = $typeArray;
        arsort($rows);
        return $rows;
    }

    public function colortypeAction()
    {
        $this->tpl->breadcrumb->add('Color Type');
        $this->display();
    }

    public function colortypeRefundChartAction()
    {
        $rows = $this->_getColorTypeRows(true);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Color Type', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }
        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function colortypeOrderChartAction()
    {
        $rows = $this->_getColorTypeRows();

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Color Type', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }
        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    protected function _getColorTypeRows($refund = false)
    {
        $db = App_Db::getInstance();

        // status
        if ($refund) {
            $statusWhere = "AND o.orders_status = 5";
        } else {
            $states = App_Model_Orders::getCommonStatusList();
            $_states = array_map('intval', $states);
            $_states = implode(', ', $_states);
            $statusWhere = "AND o.orders_status IN ({$_states})";
        }
        $rflktJoin = $this->tpl->rflkt == 1 ? "LEFT JOIN t_product p ON op.products_id = p.product_id" : '';
        $rflktWhere = $this->tpl->rflkt == 1 ? "AND FIND_IN_SET('rflkt', p.product_attrs)" : '';         

        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.color_type_name, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.color_type_name";
        } else {
            $sql = "SELECT tolpo.color_type_name, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                $rflktJoin
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                $rflktWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.color_type_name";
        }

        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $typeArray = array(
            'Clear Lens' => 0,
            'Tint' => 0,
            'Photochromic' => 0,
            'Transitions' => 0,
            'Polarized' => 0,
            'Gradient Tint' => 0,
            'Mirrored' => 0,
        );
        foreach ($rows as $row) {
            $row[0] = trim($row[0]);
            if (stripos($row[0], 'Gradient') !== false) {
                $typeArray['Gradient Tint'] += $row[1];
            } else if (stripos($row[0], 'Polarized') !== false) {
                $typeArray['Polarized'] += $row[1];
            } else if (stripos($row[0], 'Transitions') !== false) {
                $typeArray['Transitions'] += $row[1];
            } else if (stripos($row[0], 'Photochromic') !== false) {
                $typeArray['Photochromic'] += $row[1];
            } else if (stripos($row[0], 'Tint') !== false) {
                $typeArray['Tint'] += $row[1];
            } else if (stripos($row[0], 'Mirrored') !== false) {
                $typeArray['Mirrored'] += $row[1];
            } else {
                $typeArray['Clear Lens'] += $row[1];
            }
        }
        $rows = $typeArray;
        arsort($rows);
        return $rows;
    }

    public function coatingAction()
    {
        $this->tpl->breadcrumb->add('Coating');
        $this->display();
    }

    public function coatingOrderChartAction()
    {
        $rows = $this->_getCoatingRows();
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Coating', 'Count', 'Percent');

            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function coatingRefundChartAction()
    {
        $rows = $this->_getCoatingRows(true);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Coating', 'Count', 'Percent');
            
            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }
        // draw graph
        $title = new title('Refund Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    protected function _getCoatingRows($refund = false)
    {
        $db = App_Db::getInstance();

        // status
        if ($refund) {
            $statusWhere = "AND o.orders_status = 5";
        } else {
            $states = App_Model_Orders::getCommonStatusList();
            $_states = array_map('intval', $states);
            $_states = implode(', ', $_states);
            $statusWhere = "AND o.orders_status IN ({$_states})";
        }

        /**
         * for refund
         */
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.coating_id, SUM(op.products_quantity) total
                    FROM t_order_product_olens tolpo
                    LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
                    LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
                    WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
                    $statusWhere
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    GROUP BY tolpo.coating_id";
        } else {
            $sql = "SELECT tolpo.coating_id, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
                LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
				LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				AND ot.class = 'total'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY tolpo.coating_id";
        }

        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        $typeArray = array(
            'Anti-Scratch'  => 0,
            'Anti-Glare'    => 0,
            'SHMC'          => 0,
            'Blue-Cut'      => 0,
            "EBD Blue"      => 0,
        );
        foreach ($rows as $row) {
            $row[0] = trim($row[0]);

            if (in_array($row[0], [1, 9])) {
                $typeArray['Anti-Scratch'] += $row[1];
            } else if (in_array($row[0], [3, 11])) {
                $typeArray['Anti-Glare'] += $row[1];
            } else if (in_array($row[0], [5, 13])) {
                $typeArray['SHMC'] += $row[1];
            } else if (in_array($row[0], [7, 15])) {
                $typeArray['Blue-Cut'] += $row[1];
            } else if (in_array($row[0], [17])) {
                $typeArray['EBD Blue'] += $row[1];
            } else {
                $typeArray['Anti-Scratch'] += $row[1];
            }
        }
        $rows = $typeArray;
        arsort($rows);
        return $rows;
    }

    public function packageAction()
    {
        $this->tpl->breadcrumb->add('Package');
        $this->display();
    }

    public function packageOrderChartAction()
    {
        $db = App_Db::getInstance();

        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = "DATE_FORMAT(date_purchased, '%Y-%m-%d') ";
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }
        $sql = "SELECT $groupby groupby, DATE_FORMAT(date_purchased, '%Y-%m-%d'), "
                .
                ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('(topo.package_price * op.products_quantity)', 'tax_rate') . ") total"  : "SUM(op.products_quantity) total ")
                . "
            FROM t_order_product_olens topo
            LEFT JOIN orders_products op ON op.orders_products_id = topo.order_product_id
            LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
            LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id AND ot.class = 'total'
            WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
            $statusWhere
            AND topo.package_id != 0
            AND topo.color_value = ''
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
            GROUP BY $groupby
        ";

        if(!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null,PDO::FETCH_OBJ);
            $csv = new App_Csv();
			$csv->setHeader(array('Time', 'Total'));
			$csv->setData($rows, array('groupby', 'total'));
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

        // chart
        $chart = new App_Chart();

        $title = $this->tpl->stat == 'value' ? 'Package Revenue' : 'Package Jobs';

        $rows = $chart->fixRows($rows, $labels);
        $line = $chart->getShape($this->tpl->chart, true, '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#' : '#x_label#<br>Total: #val#');
        $line->setTitle($title);
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function packageCategoryAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        // status
        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        if ($this->tpl->stat == 'volume') {
            $sql = "SELECT tolpo.lens_type, tolpo.package_name, tolpo.index_id, SUM(op.products_quantity) total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                AND tolpo.package_id != 0
                AND tolpo.color_value = ''
				GROUP BY tolpo.lens_type, tolpo.index_id , tolpo.package_name";
        } else {
            $sql = "SELECT tolpo.lens_type, tolpo.package_name, tolpo.index_id, SUM(" . App_Model_Orders::excludeTax('(op.products_quantity * tolpo.package_price)', 'tax_rate') . ") total
				FROM t_order_product_olens tolpo
				LEFT JOIN orders_products op ON op.orders_products_id = tolpo.order_product_id
				LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
                LEFT JOIN orders_ext oe ON (o.orders_id = oe.orders_id)
				WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
				$statusWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                AND tolpo.package_id != 0
                AND tolpo.color_value = ''
				GROUP BY tolpo.lens_type, tolpo.index_id , tolpo.package_name";
        }
        $rows = $db->getAll($sql, null, PDO::FETCH_NAMED);

        $result = [];
        foreach ($rows as $row) {
            $type = str_replace(['single-vision', 'bifocal', 'progressive', 'free-form'], ['SV', 'BF', 'PG', 'FF'], $row['lens_type']);
            $type = $row['package_name'] . '(' . $type . ':' . $row['index_id'] . ')';
            isset($result[$type]) ? ($result[$type] += $row['total']) : ($result[$type] = $row['total']);
        }
        $rows = $result;
        arsort($rows);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvPieData($rows);
            $csvTitles = array('Name', 'Count', 'Percent');
            $csv->setHeader($csvTitles);
			$csv->setData($csvRows);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit();
        }

        // draw graph
        $title = new title('Order Pie');

        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        foreach ($rows as $k => $v) {
            $num = intval($v);
            $tmp[] = new pie_value($num, $k);
        }

        $pie->values = $tmp;
        if ($this->tpl->stat == 'volume') {
            $pie->tip = '#label#<br>#val# of #total# (#percent#)';
        } else {
            $pie->tip = '#label#<br>$#val# of $#total# (#percent#)';
        }

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->set_title($title);
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function optionsAction()
    {
        $this->tpl->breadcrumb->add('Len Options');
        $this->display();
    }

    public function optionsOrderChartAction()
    {
        $db = App_Db::getInstance();

        $states = App_Model_Orders::getCommonStatusList();
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = "DATE_FORMAT(date_purchased, '%Y-%m-%d') ";
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        $sql = "SELECT $groupby, DATE_FORMAT(date_purchased, '%Y-%m-%d'), "
                .
                ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total " : "SUM(op.products_quantity) total ")
                . "
            FROM t_order_product_option toption
            LEFT JOIN  t_order_product_olens topo ON toption.olens_id = topo.olens_id
            LEFT JOIN orders_products op ON op.orders_products_id = topo.order_product_id
            LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
            LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id AND ot.class = 'total'
            WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
            $statusWhere
            AND toption.option_id = 1
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
            GROUP BY $groupby
        ";
        $uv = $db->getAll($sql, null, PDO::FETCH_NUM);


        $sql = "SELECT $groupby, DATE_FORMAT(date_purchased, '%Y-%m-%d'), "
                .
                ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total " : "SUM(op.products_quantity) total ")
                . "
            FROM t_order_product_option toption
            LEFT JOIN  t_order_product_olens topo ON toption.olens_id = topo.olens_id
            LEFT JOIN orders_products op ON op.orders_products_id = topo.order_product_id
            LEFT JOIN orders o FORCE INDEX (date2status) ON o.orders_id = op.orders_id
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
            LEFT JOIN orders_total ot ON ot.orders_id = o.orders_id AND ot.class = 'total'
            WHERE o.date_purchased >= '{$this->tpl->from} 00:00:00' AND o.date_purchased <= '{$this->tpl->to} 23:59:59'
            $statusWhere
            AND toption.option_id = 3
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
            GROUP BY $groupby
        ";
        $party = $db->getAll($sql, null, PDO::FETCH_NUM);

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvTitles = array();
            $rows = array();
            $title = $this->tpl->stat == 'value' ? 'UV Revenue' : 'UV Jobs';
            foreach ($uv as $v) {
               if(!isset($row[$v[0]])){
                   $rows[$v[0]]['Time'] = $v[0];
               }
               $rows[$v[0]][$title] = number_format($v[2],2 );
            }

            $title = $this->tpl->stat == 'value' ? 'Party  Revenue' : 'Party Jobs';
            foreach ($party as $v) {
             if(!isset($row[$v[0]])){
                     $rows[$v[0]]['Time'] = $v[0];
                 }
                 $rows[$v[0]][$title] = number_format($v[2],2 );
             }

            $rows = array_values($rows);
            $csvTitles =  $this->tpl->stat == 'value' ? array('Time', 'UV Revenue', 'Party  Revenue') : array('Time', 'UV Jobs', 'Party  Jobs');

			$csv->setHeader($csvTitles);
			$csv->setData($rows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;

        }
        // chart
        $chart = new App_Chart();

        $title = $this->tpl->stat == 'value' ? 'UV Revenue' : 'UV Jobs';

        $rows = $chart->fixRows($uv, $labels);
        $line = $chart->getShape($this->tpl->chart, true, '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#(UV)' : '#x_label#<br>Total: #val#(UV)');
        $line->setTitle($title);
        $line->appendTo($chart);

        $title = $this->tpl->stat == 'value' ? 'Party  Revenue' : 'Party Jobs';

        $rows = $chart->fixRows($party, $labels);
        $line = $chart->getShape($this->tpl->chart, true, '#009922');
        $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#(Party)' : '#x_label#<br>Total: #val#(Party)');
        $line->setTitle($title);
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
    
    public function digitalChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();
        $percents = array();
        //groupby, $labels
        $graphby = $this->tpl->graphby;
        $types = $this->tpl->digital;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        
        $chart = new App_Chart();

        if(in_array('sbrc', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.index_id = 1.57
                    AND opo.coating_id = 7
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $sbrc = $db->getAll($sql, null, PDO::FETCH_NUM);

            $percents['SBRC'] = $rows = $sbrc;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#009922');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("SBRC jobs");
            $line->appendTo($chart);
        }
        
        if(in_array('brc', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.index_id = 1.6
                    AND opo.coating_id = 17
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $brc = $db->getAll($sql, null, PDO::FETCH_NUM);

            $percents['EBD_BLUE'] = $rows = $brc;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#ff3399');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("EBD BLUE jobs");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_nonrx', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 308
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $nonrx = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.59 NONRX'] = $rows = $nonrx;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#ff6600');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("Eyezen 1.59 Non-Rx");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_rx', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 309
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $rx = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.59'] = $rows = $rx;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#660066');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("Eyezen 1.59 Rx");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_super', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 310
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $rxSuper = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.67'] = $rows = $rxSuper;
            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape('line', count($labels), '#cc33ff');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# jobs');
            $line->setTitle("Eyezen 1.67");
            $line->appendTo($chart);
        }
        
        if (!empty($_GET['export'])) {
            $temp = array_keys($percents);
            array_unshift($temp, 'Time');
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($percents);
            $csv->setHeader($temp);
            $csv->setData($rows, $temp);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }        
        
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();        
        
    }
    
    public function digitalChartPercentAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();
        $percents = array();
        //groupby, $labels
        $graphby = $this->tpl->graphby;
        $types = $this->tpl->digital;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        
        $allJobsSql =  "SELECT $groupby grp, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                        FROM orders o FORCE INDEX (date2status)
                        LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                        LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                        WHERE o.orders_status IN ($_states)
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        GROUP BY grp";
        $allJobsSql = sprintf($allJobsSql, $this->tpl->from, $this->tpl->to);
        $allJobs = $db->getAll($allJobsSql, null, PDO::FETCH_NUM);
        foreach($allJobs as $k => $v) {
            $jobsMap[$v[0]] = $v[1];
        }
        
        $chart = new App_Chart();

        if(in_array('sbrc', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.index_id = 1.57
                    AND opo.coating_id = 7
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $sbrc = $db->getAll($sql, null, PDO::FETCH_NUM);

            $percents['SBRC'] = $rows = $sbrc;
            $rows = $chart->fixRowsPercent($rows, $labels, $jobsMap);

            $line = $chart->getShape('line', count($labels), '#009922');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>#val# %');
            $line->setTitle("SBRC");
            $line->appendTo($chart);
        }
        
        if(in_array('brc', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.index_id = 1.6
                    AND opo.coating_id = 17
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $brc = $db->getAll($sql, null, PDO::FETCH_NUM);

            $percents['EBD_BLUE'] = $rows = $brc;
            $rows = $chart->fixRowsPercent($rows, $labels, $jobsMap);
            $line = $chart->getShape('line', count($labels), '#ff3399');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>#val# %');
            $line->setTitle("EBD BLUE");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_nonrx', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 308
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $nonrx = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.59 NONRX'] = $rows = $nonrx;
            $rows = $chart->fixRowsPercent($rows, $labels, $jobsMap);
            $line = $chart->getShape('line', count($labels), '#ff6600');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>#val# %');
            $line->setTitle("Eyezen 1.59 Non-Rx");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_rx', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 309
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $rx = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.59'] = $rows = $rx;
            $rows = $chart->fixRowsPercent($rows, $labels, $jobsMap);
            $line = $chart->getShape('line', count($labels), '#660066');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>#val# %');
            $line->setTitle("Eyezen 1.59 Rx");
            $line->appendTo($chart);
        }
        
        if(in_array('eyezen_super', $types)) {
            $sql = "SELECT $groupby grp, date_purchased, " . ($this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.final_price', 'tax_rate').") total" : "SUM(op.products_quantity) total") . "
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_products op ON op.orders_id = o.orders_id
                    LEFT JOIN t_order_product_olens opo ON opo.order_product_id = op.orders_products_id
                    LEFT JOIN orders_ext oe ON oe.orders_id = o.orders_id
                    WHERE o.orders_status IN ($_states)
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    AND opo.use_id = 19
                    AND opo.lens_id = 310
                    GROUP BY grp";
            $sql = sprintf($sql, $this->tpl->from, $this->tpl->to);
            $rxSuper = $db->getAll($sql, null, PDO::FETCH_NUM);
            
            $percents['EYEZEN 1.67'] = $rows = $rxSuper;
            $rows = $chart->fixRowsPercent($rows, $labels, $jobsMap);
            $line = $chart->getShape('line', count($labels), '#cc33ff');
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>#val# %');
            $line->setTitle("Eyezen 1.67");
            $line->appendTo($chart);
        }
        
        if (!empty($_GET['export'])) {
            $temp = array_keys($percents);
            array_unshift($temp, 'Time');
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($percents);
            $csv->setHeader($temp);
            $csv->setData($rows, $temp);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }        
        
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();        
        
    }    
    
}
