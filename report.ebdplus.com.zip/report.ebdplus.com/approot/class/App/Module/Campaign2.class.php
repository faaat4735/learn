<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
//require_once LIB_CLASS_DIR . "gapi.class.php";
require_once LIB_CLASS_DIR . "GoogleAnalytics.class.php";
class App_Module_Campaign2 extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$statusList = App_Model_Orders::getStatusList();
		$this->tpl->assign_by_ref('statusList', $statusList);

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}

		//customer source

		$sourceList = App_Model_Customers::getUtmSource();
		$this->tpl->assign_by_ref('sourceList', $sourceList);

		$sourceList = App_Model_Customers::getUtmCampaign();
		$this->tpl->assign_by_ref('campaignList', $sourceList);

		$sourceList = App_Model_Customers::getUtmMedium();
		$this->tpl->assign_by_ref('mediumList', $sourceList);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$stat =& $_GET['stat'];
		$chart =& $_GET['chart'];
		$payment =& $_GET['payment'];
		$isnew =& $_GET['isnew'];
		$isreg =& $_GET['isreg'];
		$visitor =& $_GET['visitor'];

		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];

		$visitor_google =& $_GET['visitor_google'];
		$new_visitor_google =& $_GET['new_visitor_google'];

		if (!$from) {
			$from = '2009-12-01';
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$stat) {
			$stat = 'volume';
		}
		if (!$chart) {
			$chart = 'line';
		}
		if (!is_array($payment)) {
			$payment = array('total');
		}

		//sortby
		$sortby =& $_GET['sortby'];
		if (!$sortby) {
			$sortby = 'number';
		}

		$this->tpl->assign_by_ref('source', $source);
		$this->tpl->assign_by_ref('campaign', $campaign);
		$this->tpl->assign_by_ref('medium', $medium);

		$this->tpl->assign_by_ref('visitor_google', $visitor_google);
		$this->tpl->assign_by_ref('new_visitor_google', $new_visitor_google);

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('sortby', $sortby);
		$this->tpl->assign_by_ref('stat', $stat);
		$this->tpl->assign_by_ref('chart', $chart);
		$this->tpl->assign_by_ref('payment', $payment);
		$this->tpl->assign_by_ref('isnew', $isnew);
		$this->tpl->assign_by_ref('isreg', $isreg);
		//$this->tpl->assign_by_ref('visitor', $visitor);
	}

	public function indexAction()
	{
		$this->reflect('Campaign2', 'total');
	}

	public function totalAction()
	{
		$this->tpl->breadcrumb->add('Total Sales');
		$this->display();
	}

	public function totalChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		// chart
		$chart = new App_Chart();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date_purchased, 3)';
				$groupbyCustomers = 'YEARWEEK(customers_info_date_account_created, 3)';
				$groupbyVisitor = 'YEARWEEK(visit_time, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
				$groupbyCustomers = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
				$groupbyVisitor = 'EXTRACT(YEAR_MONTH FROM visit_time)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM date_purchased)';
				$groupbyCustomers = 'EXTRACT(YEARH FROM customers_info_date_account_created)';
				$groupbyVisitor = 'EXTRACT(YEAR FROM visit_time)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date_purchased)';
				$groupbyCustomers = 'DATE(customers_info_date_account_created)';
				$groupbyVisitor = 'DATE(visit_time)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";

		//source
		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];

		$sourceTab = '';
		$customersWhere = '';
//		$filter = '';
		if (!empty($source) || !empty($campaign) || !empty($medium)) {
			$sourceTab = "LEFT JOIN customers_info cus ON o.customers_id = cus.customers_info_id";
			$filter_arr = array();
			if (!empty($source))
			{
				$tmp_where = '';
				$tmp_filter = '';
				foreach ($source as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " cus.utm_source = '" . addslashes($v) . "'";
					$tmp_filter .= (($k == 0) ? "" : " ||") . " source == " . addslashes($v) ;
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
				$filter_arr[] = $tmp_filter;
			}

			if (!empty($campaign))
			{
				$tmp_where = " AND cus.utm_campaign = '" . addslashes($campaign) . "'";
				$tmp_filter = " campaign == " . addslashes($campaign) ;
//				foreach ($campaign as $k=>$v) {
//					$tmp_where .= (($k == 0) ? "" : " or") . " cus.utm_campaign = '" . addslashes($v) . "'";
//					$tmp_filter .= (($k == 0) ? "" : " ||") . " campaign == " . addslashes($v) ;
//				}
//				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
				$filter_arr[] = $tmp_filter;
			}

			if (!empty($medium))
			{
				$tmp_where = '';
				$tmp_filter = '';
				foreach ($medium as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " cus.utm_medium = '" . addslashes($v) . "'";
					$tmp_filter .= (($k == 0) ? "" : " ||") . " medium == " . addslashes($v);
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
				$filter_arr[] = $tmp_filter;
			}
			$statusWhere .= $customersWhere;
			$filter = implode(" && ", $filter_arr);
			if (isset($_GET['visitor_google']) || isset($_GET['new_visitor_google'])) {
                $apiGA = new \GoogleAnalytics(GA_PROFILE_ID_US);
                $filter = "medium==organic";
                $gaResults = $apiGA->getReport($this->tpl->from, $this->tpl->to, array('date','month','year','campaign','medium','source'), array('visits','newVisits'), null, array('date'));

				if($gaResults)
				{
					$ga_rows = array();
					$ga_rows_new = array();

					$ga_rows_tmp = array();
					if ($graphby == 'weekly') {
						foreach($gaResults as $result)
						{

							$t_key = date('oW',strtotime($result[0]));
							//$result->dimensions['year'].date('W',strtotime($result->dimensions['date']));
							$ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count'])?($ga_rows_tmp[$t_key]['count']+$result[6]):$result[6];
							$ga_rows_tmp[$t_key]['count2'] = isset($ga_rows_tmp[$t_key]['count2'])?($ga_rows_tmp[$t_key]['count2']+$result[7]):$result[7];
							if(!isset($ga_rows_tmp[$t_key]['date'])) $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s',strtotime($result[0])+10);
						}
//						foreach ($ga_rows_tmp as $_key => $_value) {
//							$ga_rows[] = array($_key,$_value['date'],$_value['count']);
//							$ga_rows_new[] = array($_key,$_value['date'],$_value['count2']);
//						}
					}
					elseif ($graphby == 'monthly') {
						foreach($gaResults as $result)
						{
							$t_key = $result[1];
							$ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count'])?($ga_rows_tmp[$t_key]['count']+$result[6]):$result[6];
							$ga_rows_tmp[$t_key]['count2'] = isset($ga_rows_tmp[$t_key]['count2'])?($ga_rows_tmp[$t_key]['count2']+$result[7]):$result[7];
							if(!isset($ga_rows_tmp[$t_key]['date'])) $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s',strtotime($result[0])+10);
						}

					}
					elseif ($graphby == 'yearly') {
						foreach($gaResults as $result)
						{
							$t_key = $result->dimensions['year'];
							$ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count'])?($ga_rows_tmp[$t_key]['count']+$result[6]):$result[6];
							$ga_rows_tmp[$t_key]['count2'] = isset($ga_rows_tmp[$t_key]['count2'])?($ga_rows_tmp[$t_key]['count2']+$result[7]):$result[7];
							if(!isset($ga_rows_tmp[$t_key]['date'])) $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s',strtotime($result[0])+10);
						}

					}
					else {
						foreach($gaResults as $result)
						{
							$t_key = date('Y-m-d',strtotime($result[0]));
							$ga_rows_tmp[$t_key]['count'] = isset($ga_rows_tmp[$t_key]['count'])?($ga_rows_tmp[$t_key]['count']+$result[6]):$result[6];
							$ga_rows_tmp[$t_key]['count2'] = isset($ga_rows_tmp[$t_key]['count2'])?($ga_rows_tmp[$t_key]['count2']+$result[7]):$result[7];
							if(!isset($ga_rows_tmp[$t_key]['date'])) $ga_rows_tmp[$t_key]['date'] = date('Y-m-d H:i:s',strtotime($result[0])+10);
						}
//						foreach($ga->getResults() as $result)
//						{
//							$ga_rows[] = array(date('Y-m-d',strtotime($result->dimensions['date'])),date('Y-m-d H:i:s',strtotime($result->dimensions['date'])+10),$result->metrics['visits']);
//							$ga_rows_new[] = array(date('Y-m-d',strtotime($result->dimensions['date'])),date('Y-m-d H:i:s',strtotime($result->dimensions['date'])+10),$result->metrics['newVisits']);
//						}
					}
					foreach ($ga_rows_tmp as $_key => $_value) {
						$ga_rows[] = array($_key,$_value['date'],$_value['count']);
						$ga_rows_new[] = array($_key,$_value['date'],$_value['count2']);
					}
					if(isset($_GET['visitor_google']))
					{
						$ga_rows = $chart->fixRows($ga_rows, $labels);
						$line = $chart->getShape($this->tpl->chart, count($labels), '#EC995D');
						$line->setValues($chart->fetchColumn($ga_rows, 1, 'intval'), $chart->fetchColumn($ga_rows, 0));
						$line->setTip('#x_label#<br>Visits: #val#');
						$line->setTitle('Visits');
						$line->appendTo($chart);
					}
					if(isset($_GET['new_visitor_google']))
					{
						$ga_rows_new = $chart->fixRows($ga_rows_new, $labels);
						$line = $chart->getShape($this->tpl->chart, count($labels), '#009999');
						$line->setValues($chart->fetchColumn($ga_rows_new, 1, 'intval'), $chart->fetchColumn($ga_rows_new, 0));
						$line->setTip('#x_label#<br>new Visits: #val#');
						$line->setTitle('new Visits');
						$line->appendTo($chart);
					}
				}
			}

		}

		//register
		if ($_GET['isreg']) {
			$sqlCustomers = sprintf("SELECT $groupbyCustomers, customers_info_date_account_created, COUNT(*) total
						FROM customers c, customers_info cus
						WHERE c.customers_id = cus.customers_info_id
						%s
						AND cus.customers_info_date_account_created <= '%s 23:59:59' AND cus.customers_info_date_account_created >= '%s 00:00:00'
						GROUP BY %s",
						$customersWhere, $this->tpl->to, $this->tpl->from, $groupbyCustomers);
		}

		//SQL
		if ($this->tpl->stat == 'value') {
			if (in_array('total', $this->tpl->payment)) {
				$sqlTotal = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);

				if (count($this->tpl->payment) == 1 && $this->tpl->isnew) {
					$sqlNew = "SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info cus
						ON cus.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						$statusWhere
						AND ot.class = 'total'
						AND date_purchased >= '{$this->tpl->from} 00:00:00' AND date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.orders_id IS NOT NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";

					$sqlOld = "SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tmp_orders t
						ON o.orders_id = t.orders_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info cus
						ON cus.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						$statusWhere
						AND ot.class = 'total'
						AND date_purchased >= '{$this->tpl->from} 00:00:00' AND date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.orders_id IS NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";
				}
			}

			if (in_array('cc', $this->tpl->payment)) {
				$sqlCC = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						AND cc_number
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('paypal', $this->tpl->payment)) {
				$sqlPaypal = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'PayPal'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('google', $this->tpl->payment)) {
				$sqlGoogle = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'Google Checkout IPN'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('free', $this->tpl->payment)) {
				$sqlFree = sprintf("SELECT $groupby, date_purchased, SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'Free Voucher'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}
		} else {

			if (in_array('total', $this->tpl->payment)) {
				$sqlTotal = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);

				if (count($this->tpl->payment) == 1 && $this->tpl->isnew) {
					$sqlNew = "SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info cus
						ON cus.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						$statusWhere
						AND ot.class = 'total'
						AND date_purchased >= '{$this->tpl->from} 00:00:00' AND date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.orders_id IS NOT NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";

					$sqlOld = "SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						LEFT JOIN tv_order_first t
						ON o.orders_id = t.order_id
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
						LEFT JOIN customers_info cus
						ON cus.customers_info_id = o.customers_id
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						$statusWhere
						AND ot.class = 'total'
						AND date_purchased >= '{$this->tpl->from} 00:00:00' AND date_purchased <= '{$this->tpl->to} 23:59:59'
						AND t.orders_id IS NULL
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY $groupby
						ORDER BY o.orders_id ASC";
				}
			}

			if (in_array('cc', $this->tpl->payment)) {
				$sqlCc = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						AND cc_number
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('paypal', $this->tpl->payment)) {
				$sqlPaypal = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'PayPal'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('google', $this->tpl->payment)) {
				$sqlGoogle = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'Google Checkout IPN'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}

			if (in_array('free', $this->tpl->payment)) {
				$sqlFree = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
						FROM orders o FORCE INDEX (date2status)
						%s
						LEFT JOIN orders_total ot
						ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
						WHERE 1=1
						%s
						AND ot.class = 'total'
						AND o.date_purchased <= '%s 23:59:59' AND o.date_purchased >= '%s 00:00:00'
						AND payment_method = 'Free Voucher'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
						GROUP BY %s
						ORDER BY o.orders_id ASC",
						$sourceTab, $statusWhere, $this->tpl->to, $this->tpl->from, $groupby);
			}
		}

		// settings
		$settings = array(
			'total' => array('Total', '#0033cc'),
			'cc' => array('Credit Card', '#009922'),
			'paypal' => array('Paypal', '#ff6600'),
			'google' => array('Google Checkout', '#d758df'),
			'free' => array('Free Voucher', '#999900'),
		);
        if(!empty($_GET['export'])) {
            $csvData = array();
            $csvTitles = array('Time');
        }

		// append to chart
		$num = 0;
		foreach ($settings as $_name => $_arr) {
			$num++;

			if (in_array($_name, $this->tpl->payment)) {

                $res  = $db->query(${'sql' . ucfirst($_name)});
                $rows = $res->fetchAll(PDO::FETCH_NUM);
                                //var_dump($rows);
				//$rows = $db->getAll(${'sql' . ucfirst($_name)}, null, PDO::FETCH_NUM);
                if(!empty($_GET['export'])) {
                    $csvData[$_name] = $rows;
                    if (!in_array($_name, $csvTitles)) {
                        $csvTitles[] = $_name;
                    }
                    continue;
                }
				$rows = $chart->fixRows($rows, $labels);

				$line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
				$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
				$line->setTip('#x_label#<br>Total: #val#');
				$line->setTitle($_arr[0]);
				$line->appendTo($chart);
			}
		}

		// chart by new / old customers
		if (isset($sqlNew)) {
            $res  = $db->query($sqlNew);
            $rows = $res->fetchAll(PDO::FETCH_NUM);

            if(!empty($_GET['export'])) {
                $csvData['New Customers'] = $rows;
                $csvTitles[] = 'New Customers';
            }

			//$rows = $db->getAll($sqlNew, null, PDO::FETCH_NUM);
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), '#990000');
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>New Customers: #val#');
			$line->setTitle('New Customers');
			$line->appendTo($chart);
		}
		if (isset($sqlOld)) {
            $res  = $db->query($sqlOld);
            $rows = $res->fetchAll(PDO::FETCH_NUM);

            if(!empty($_GET['export'])) {
                $csvData['Old Customers'] = $rows;
                $csvTitles[] = 'Old Customers';
            }
			//$rows = $db->getAll($sqlOld, null, PDO::FETCH_NUM);
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), '#009900');
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>Old Customers: #val#');
			$line->setTitle('Old Customers');
			$line->appendTo($chart);
		}
		if (isset($sqlCustomers)) {
            $res  = $db->query($sqlCustomers);
            $rows = $res->fetchAll(PDO::FETCH_NUM);

            if(!empty($_GET['export'])) {
                $csvData['Customers'] = $rows;
                $csvTitles[] = 'Customers';
            }
			//$rows = $db->getAll($sqlCustomers, null, PDO::FETCH_NUM);
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), '#000099');
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>New Accounts: #val#');
			$line->setTitle('New Accounts');
			$line->appendTo($chart);
		}
		/*
		if (isset($sqlVisitor)) {
                        $res  = $db->query($sqlVisitor);
                        $rows = $res->fetchAll(PDO::FETCH_NUM);
			//$rows = $db->getAll($sqlVisitor, null, PDO::FETCH_NUM);
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), '#009999');
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip('#x_label#<br>Total: #val#');
			$line->setTitle('New Visitors');
			$line->appendTo($chart);
		}
		*/
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}