<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Voucher extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$statusList = App_Model_Orders::getStatusList();
		$this->tpl->assign_by_ref('statusList', $statusList);

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$stat =& $_GET['stat'];
		$chart =& $_GET['chart'];
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month'));
		}
		if (!$to) {
			$to = date('Y-m-d');
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$stat) {
			$stat = 'volume';
		}
		if (!$chart) {
			$chart = 'line';
		}

		//sortby
		$sortby =& $_GET['sortby'];
		if (!$sortby) {
			$sortby = 'number';
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('sortby', $sortby);
		$this->tpl->assign_by_ref('stat', $stat);
		$this->tpl->assign_by_ref('chart', $chart);

		// coupon amount
		$couponAmount =& $_GET['coupon_amount'];
		$couponAmount = intval($couponAmount);
		$this->tpl->assign_by_ref('couponAmount', $couponAmount);
	}

	public function indexAction()
	{
		$this->tpl->breadcrumb->add('Voucher Report');
		$this->display();
	}

	public function indexChartAction()
	{
		$usedCouponAmount = $purchasedCouponAmount = '';
		if ($this->tpl->couponAmount) {
			$usedCouponAmount = 'AND c.coupon_amount = ' . $this->tpl->couponAmount;
			$purchasedCouponAmount = 'AND go.amount_usd = ' . $this->tpl->couponAmount;
		}

		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupbyPurchased = 'YEARWEEK(go.date_purchased, 3)';
				$groupbyUsed = 'YEARWEEK(ct.redeem_date, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupbyPurchased = 'EXTRACT(YEAR_MONTH FROM go.date_purchased)';
				$groupbyUsed = 'EXTRACT(YEAR_MONTH FROM ct.redeem_date)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupbyPurchased = 'EXTRACT(YEAR FROM go.date_purchased)';
				$groupbyUsed = 'EXTRACT(YEAR FROM ct.redeem_date)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupbyPurchased = 'DATE(go.date_purchased)';
				$groupbyUsed = 'DATE(ct.redeem_date)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$sqlPurchased = sprintf("
				SELECT $groupbyPurchased, go.date_purchased, %s total
				FROM customers_gv_orders go
				LEFT JOIN customers_gv_orders_detail god
				ON go.gv_orders_id = god.gv_orders_id
				WHERE god.coupon_code IS NOT NULL
				$purchasedCouponAmount
				AND go.date_purchased >= '%s 00:00:00' AND go.date_purchased <= '%s 23:59:59'
				GROUP BY $groupbyPurchased
				ORDER BY go.gv_orders_id ASC
				", $this->tpl->stat == 'value' ? 'SUM(go.amount_usd)' : 'COUNT(*)', $this->tpl->from, $this->tpl->to);
		$sqlUsed = sprintf("
			SELECT $groupbyUsed, ct.redeem_date, %s total
			FROM coupon_redeem_track ct
			LEFT JOIN coupons c
			ON c.coupon_id = ct.coupon_id
			LEFT JOIN customers_gv_orders_detail god
			ON god.coupon_code = c.coupon_code
			WHERE god.gv_orders_id IS NOT NULL
			$usedCouponAmount
			AND ct.redeem_date >= '%s 00:00:00' AND ct.redeem_date <= '%s 23:59:59'
			GROUP BY $groupbyUsed
			ORDER BY ct.unique_id ASC
			", $this->tpl->stat == 'value' ? 'SUM(c.coupon_amount)' : 'COUNT(*)', $this->tpl->from, $this->tpl->to);

		// chart
		$chart = new App_Chart();

		// settings
		$settings = array(
			'purchased' => array('Purchased', '#0033cc'),
			'used' => array('Used', '#009922'),
		);

        if(!empty($_GET['export'])) {
            $csvData = array();
            $csvTitles = array('Time');
        }

		// append to chart
		$num = 0;
		foreach ($settings as $_name => $_arr) {
			$num++;

			$rows = $db->getAll(${'sql' . ucfirst($_name)}, null, PDO::FETCH_NUM);
            if(!empty($_GET['export'])) {
                $csvData[$_name] = $rows;
                if (!in_array($_name, $csvTitles)) {
                    $csvTitles[] = $_name;
                }
                continue;
            }
			$rows = $chart->fixRows($rows, $labels);

			$line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
			$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
			$line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val# (#key#)' : '#x_label#<br>Total: #val# (#key#)');
			$line->setTitle($_arr[0]);
			$line->appendTo($chart);
		}

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function ordersAction()
	{
		$this->tpl->breadcrumb->add('Voucher Orders');
		$this->display();
	}

	public function ordersChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(ct.redeem_date, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM ct.redeem_date)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM ct.redeem_date)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(ct.redeem_date)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$whereCouponAmount = $this->tpl->couponAmount ? 'AND c.coupon_amount = ' . $this->tpl->couponAmount : '';
		$sql = sprintf("
			SELECT $groupby groupby, ct.redeem_date, %s total
			FROM coupon_redeem_track ct
			LEFT JOIN coupons c
			ON c.coupon_id = ct.coupon_id
			LEFT JOIN customers_gv_orders_detail god
			ON god.coupon_code = c.coupon_code
			LEFT JOIN orders o
			ON o.orders_id = ct.order_id
			LEFT JOIN orders_total ot
			ON ot.orders_id = o.orders_id
			WHERE god.gv_orders_id IS NOT NULL
			$whereCouponAmount
			AND ct.redeem_date >= '%s 00:00:00' AND ct.redeem_date <= '%s 23:59:59'
			AND ot.class = 'total'
			GROUP BY $groupby
			ORDER BY ct.unique_id ASC
			", $this->tpl->stat == 'value' ? 'SUM(ot.value)' : 'COUNT(*)', $this->tpl->from, $this->tpl->to);

		// chart
		$chart = new App_Chart();

		// append to chart
        if(!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null,PDO::FETCH_OBJ);
            $csv = new App_Csv();
			$csv->setHeader(array('Time', 'Total'));
			$csv->setData($rows, array('groupby', 'total'));
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels));
		$line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
		$line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val#' : '#x_label#<br>Total: #val#');
		$line->setTitle('Voucher Orders');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}