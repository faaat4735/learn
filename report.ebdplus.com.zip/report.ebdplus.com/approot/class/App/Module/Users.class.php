<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Users extends App_Module
{
	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$stat =& $_GET['stat'];
		$graphby =& $_GET['graphby'];
		$chart =& $_GET['chart'];

		if (empty($stat)) {
			$stat = 'volume';
		}
		if (empty($graphby)) {
			$graphby = 'daily';
		}
		if (empty($chart)) {
			$chart = 'line';
		}
		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}

		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];
		$this->tpl->assign_by_ref('source', $source);
		$this->tpl->assign_by_ref('campaign', $campaign);
		$this->tpl->assign_by_ref('medium', $medium);

		$sourceList = App_Model_Customers::getUtmSource();
		//print_r($sourceList);
		$this->tpl->assign_by_ref('sourceList', $sourceList);

		$sourceList = App_Model_Customers::getUtmCampaign();
		//print_r($sourceList);
		$this->tpl->assign_by_ref('campaignList', $sourceList);

		$sourceList = App_Model_Customers::getUtmMedium();
		//print_r($sourceList);
		$this->tpl->assign_by_ref('mediumList', $sourceList);

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('stat', $stat);
		$this->tpl->assign_by_ref('gender', $gender);
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
	}

	public function indexAction()
	{
		$this->tpl->breadcrumb->add('Customer Report');
		$this->display();
	}

	public function onlineAction()
	{
		$this->tpl->breadcrumb->add('Online Users');
		$this->display();
	}

	public function indexChartAction()
	{
		$db = App_Db::getInstance();

		//groupby
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(customers_info_date_account_created, 3)';
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM customers_info_date_account_created)';
				break;
			case 'daily':
			default:
				$groupby = 'DATE(customers_info_date_account_created)';
				break;
		}

		$sql = "SELECT COUNT(*) total, DATE(customers_info_date_account_created) time
			FROM customers c
			LEFT JOIN customers_info i
			ON (c.customers_id = i.customers_info_id)
			WHERE customers_info_date_account_created <= ADDDATE(:enddate, 1) AND customers_info_date_account_created > :begindate
			AND customers_gender = :gender
			GROUP BY $groupby
			ORDER BY time ASC";

		$allSql = "SELECT COUNT(*) total, DATE(customers_info_date_account_created) time
			FROM customers c
			LEFT JOIN customers_info i
			ON (c.customers_id = i.customers_info_id)
			WHERE DATE(customers_info_date_account_created) BETWEEN DATE(:begindate) AND DATE(:enddate)
			GROUP BY $groupby
			ORDER BY time ASC";

		// prepare
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->bindParam(':gender', $gender);

		// get male
		$gender = 'm';
		$stmt->execute();
		$maleRows = $stmt->fetchAll(PDO::FETCH_NUM);

		// get female
		$gender = 'f';
		$stmt->execute();
		$femaleRows = $stmt->fetchAll(PDO::FETCH_NUM);

		// get all
		$stmt = $db->prepare($allSql);
		$stmt->bindParam(':begindate', $this->tpl->from);
		$stmt->bindParam(':enddate', $this->tpl->to);
		$stmt->execute();
		$rows = $stmt->fetchAll(PDO::FETCH_NUM);


		/////////////////

		//$s = new star();
		//$s->size(5)->halo_size(2)->on_click("line_1");
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = array(
                'Male' => $maleRows,
                'Female' => $femaleRows,
                'All' => $rows
            );
            $csvRows = $csv->prepareCsvData($csvRows, 1, 0);
            $csvTitles = array('Time', 'Male', 'Female', 'All');

			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }

		$chart = new App_Chart();

		$data_1 = $chart->fetchColumn($maleRows, 0, 'intval');
		$line_1 = $chart->getShape($this->tpl->chart, count($rows), '#0000ff');
		$line_1->setValues($data_1, $chart->fetchColumn($maleRows, 1));
		$line_1->setTip('#x_label#<br>Total: #val#');
		$line_1->setTitle("Male");
		$line_1->appendTo($chart);

		$data_2 = $chart->fetchColumn($femaleRows, 0, 'intval');
		$line_2 = $chart->getShape($this->tpl->chart, count($rows), '#ff0000');
		$line_2->setValues($data_2, $chart->fetchColumn($femaleRows, 1));
		$line_2->setTip('#x_label#<br>Total: #val#');
		$line_2->setTitle("Female");
		$line_2->appendTo($chart);

		$data_3 = $chart->fetchColumn($rows, 0, 'intval');
		$line_3 = $chart->getShape($this->tpl->chart, count($rows), '#aaaa33');
		$line_3->setValues($data_3, $chart->fetchColumn($rows, 1));
		$line_3->setTip('#x_label#<br>Total: #val#');
		$line_3->setTitle("All");
		$line_3->appendTo($chart);

		$chart->setLabels($chart->fetchColumn($rows, 1))->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function avgcreateAction()
	{
		$this->tpl->breadcrumb->add('Average time to create account');
		$this->display();
	}

	public function avgcreateChartAction()
	{
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(customers_info_date_account_created, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM customers_info_date_account_created)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(customers_info_date_account_created)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];

		$customersWhere = '';
		if (!empty($source) || !empty($campaign) || !empty($medium)) {
			if (!empty($source))
			{
				$tmp_where = '';
				foreach ($source as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_source = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($campaign))
			{
				$tmp_where = '';
				foreach ($campaign as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_campaign = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($medium))
			{
				$tmp_where = '';
				foreach ($medium as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_medium = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}
		}

		// sql
		$sql = "SELECT $groupby, customers_info_date_account_created, AVG(UNIX_TIMESTAMP(customers_info_date_account_created) - UNIX_TIMESTAMP(customers_info_date_come_first_time))/86400 total
			FROM customers_info i
			WHERE customers_info_id > 113133 AND customers_info_date_account_created <= '{$this->tpl->to} 23:59:59' AND customers_info_date_account_created >= '{$this->tpl->from} 00:00:00'
			$customersWhere
			GROUP BY $groupby
			ORDER BY customers_info_id ASC";

		// prepare
		$rows = $db->getAll($sql, null, PDO::FETCH_NUM);

		/////////////////
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = array('Number' => $rows);
            $csvRows = $csv->prepareCsvData($csvRows);

            $csvTitles = array('Time', 'Number');

			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;

        }

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Average: #val# days');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function avgorderAction()
	{
		$this->tpl->breadcrumb->add('Average time to order (from creating account)');
		$this->display();
	}

	public function avgorderChartAction()
	{
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(o.date_purchased, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(o.date_purchased)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];

		$customersWhere = '';
		if (!empty($source) || !empty($campaign) || !empty($medium)) {
			if (!empty($source))
			{
				$tmp_where = '';
				foreach ($source as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_source = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($campaign))
			{
				$tmp_where = '';
				foreach ($campaign as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_campaign = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($medium))
			{
				$tmp_where = '';
				foreach ($medium as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_medium = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}
		}


		$sql = "SELECT $groupby, o.date_purchased, AVG(UNIX_TIMESTAMP(o.date_purchased) - UNIX_TIMESTAMP(i.customers_info_date_account_created))/86400 total
			FROM tv_order_first t
			LEFT JOIN orders o 
			ON o.orders_id = t.order_id
			LEFT JOIN customers c
			ON c.customers_id = o.customers_id
			LEFT JOIN customers_info i
			ON i.customers_info_id = c.customers_id
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE o.date_purchased <= '{$this->tpl->to} 23:59:59' AND o.date_purchased >= '{$this->tpl->from} 00:00:00'
			$customersWhere
			AND i.customers_info_date_account_created IS NOT NULL AND o.date_purchased IS NOT NULL
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY $groupby
			ORDER BY o.orders_id ASC";
		// prepare
		$rows = $db->getAll($sql, null, PDO::FETCH_NUM);
         if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = array('Number' => $rows);
            $csvRows = $csv->prepareCsvData($csvRows);
            $csvTitles = array('Time', 'Number');

			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }


		/////////////////

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Average: #val# days');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function avgorderfromvisitAction()
	{
		$this->tpl->breadcrumb->add('Average time to order (from the 1st visit)');
		$this->display();
	}

	public function avgorderfromvisitChartAction()
	{
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(o.date_purchased, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(o.date_purchased)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		$source =& $_GET['source'];
		$campaign =& $_GET['campaign'];
		$medium =& $_GET['medium'];

		$customersWhere = '';
		if (!empty($source) || !empty($campaign) || !empty($medium)) {
			if (!empty($source))
			{
				$tmp_where = '';
				foreach ($source as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_source = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($campaign))
			{
				$tmp_where = '';
				foreach ($campaign as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_campaign = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}

			if (!empty($medium))
			{
				$tmp_where = '';
				foreach ($medium as $k=>$v) {
					$tmp_where .= (($k == 0) ? "" : " or") . " i.utm_medium = '" . addslashes($v) . "'";
				}
				$tmp_where = " AND (".$tmp_where.")";
				$customersWhere .= $tmp_where;
			}
		}

		$sql = "SELECT $groupby, o.date_purchased, AVG(UNIX_TIMESTAMP(o.date_purchased) - UNIX_TIMESTAMP(i.customers_info_date_come_first_time))/86400 total
			FROM tv_order_first t
			LEFT JOIN orders o 
			ON o.orders_id = t.order_id
			LEFT JOIN customers c
			ON c.customers_id = o.customers_id
			LEFT JOIN customers_info i
			ON i.customers_info_id = c.customers_id
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE o.date_purchased <= '{$this->tpl->to} 23:59:59' AND o.date_purchased >= '{$this->tpl->from} 00:00:00'
			$customersWhere
			AND o.customers_id > 113133
			AND i.customers_info_date_account_created IS NOT NULL AND o.date_purchased IS NOT NULL
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY $groupby
			ORDER BY o.orders_id ASC";

		// prepare
		$rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = array('Number' => $rows);
            $csvRows = $csv->prepareCsvData($csvRows);

            $csvTitles = array('Time', 'Number');
			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }

		/////////////////

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Average: #val# days');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}
}