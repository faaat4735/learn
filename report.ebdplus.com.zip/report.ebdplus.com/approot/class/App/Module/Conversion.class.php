<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";
//require_once LIB_CLASS_DIR . "gapi.class.php";
require_once LIB_CLASS_DIR . "GoogleAnalytics.class.php";

class App_Module_Conversion extends App_Module {

    public function __construct($tpl) {

        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $localeId = & $_GET['localeId'];
        $graphby = & $_GET['graphby'];
        $chart = & $_GET['chart'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month -1 day'));
        }
        if (!$to) {
            $to = date('Y-m-d', strtotime('-1 day'));
        }
        if (!$localeId) {
            $localeId = 0;
        }

        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$chart) {
            $chart = 'bar';
        }

        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign('localeId', $localeId);
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('chart', $chart);

        $this->tpl->breadcrumb->add('Conversion Rate');
    }

    public function indexAction() {
        $this->reflect('Conversion', 'total');
    }

    public function totalAction() {
        $this->tpl->breadcrumb->add('Order CR (by database)');
        $this->display();
    }

    public function totalChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        //SQL
        $sqlTotal = sprintf("SELECT $groupby, date_purchased, COUNT(*) total
			FROM orders o FORCE INDEX (date2status)
			LEFT JOIN orders_total ot
			ON (o.orders_id = ot.orders_id)
            LEFT JOIN orders_ext oe
            ON (o.orders_id = oe.orders_id)
			WHERE 1 = 1
			%s
			%s
			AND ot.class = 'total'
			AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
			GROUP BY %s
			ORDER BY o.orders_id ASC", $statusWhere, $localeWhere, $this->tpl->from, $this->tpl->to, $groupby);

        $rows = $db->getAll($sqlTotal, null, PDO::FETCH_NUM);

        $ga_rows = array();

        if ($this->tpl->localeId == 1) { //US
            $usGA = new \GoogleAnalytics();
            $pairs_us =array();
            $gaResult = $usGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else if ($this->tpl->localeId == 2) { //AU
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);

            $gaResult = $auGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else if ($this->tpl->localeId == 3) { //CA
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);

            $gaResult = $caGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else if ($this->tpl->localeId == 4) { //FR
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);

            $gaResult = $frGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else if ($this->tpl->localeId == 6) { //DE
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);

            $gaResult = $deGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else if ($this->tpl->localeId == 7) { //GB
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);

            $gaResult = $gbGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($ga_rows[$group])) {
                    $ga_rows[$group] = 0;
                }
                $ga_rows[$group] += $result[4];
            }
        } else { //ALL
            $usGA = new \GoogleAnalytics();
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);
            
            $pairs_us = array();
            $gaResult = $usGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_us[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_us[$group] = 0;
                }
                $pairs_us[$group] += $result[4];
            }
            
            $pairs_au = array();
            $gaResult = $auGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_au[$group])) {
                    $pairs_au[$group] = 0;
                }
                $pairs_au[$group] += $result[4];
            }
            
            $pairs_ca = array();
            $gaResult = $caGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_ca[$group])) {
                    $pairs_ca[$group] = 0;
                }
                $pairs_ca[$group] += $result[4];
            }
            
            $pairs_fr = array();
            $gaResult = $frGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_fr[$group])) {
                    $pairs_fr[$group] = 0;
                }
                $pairs_fr[$group] += $result[4];
            }
            
            $pairs_de = array();
            $gaResult = $deGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_de[$group])) {
                    $pairs_de[$group] = 0;
                }
                $pairs_de[$group] += $result[4];
            }
            
            $pairs_gb = array();
            $gaResult = $gbGA->getReport($this->tpl->from, $this->tpl->to, array('date', 'week', 'month', 'year'), array('visitors'), null, array('date'));
            foreach ($gaResult as $result) {
                switch ($graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;
                    case 'monthly':
                        $group = $result[2];
                        break;
                    case 'yearly':
                        $group = $result[3];
                        break;
                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }
                if (!isset($pairs_gb[$group])) {
                    $pairs_gb[$group] = 0;
                }
                $pairs_gb[$group] += $result[4];
            }
            
            foreach ($pairs_us as $key => $value) {
                $ga_rows[$key] = $value;
                if (isset($pairs_au[$key])) {
                    $ga_rows[$key] += $pairs_au[$key];
                }
                if (isset($pairs_ca[$key])) {
                    $ga_rows[$key] += $pairs_ca[$key];
                }
                if (isset($pairs_fr[$key])) {
                    $ga_rows[$key] += $pairs_fr[$key];
                }
                if (isset($pairs_de[$key])) {
                    $ga_rows[$key] += $pairs_de[$key];
                }
                if (isset($pairs_gb[$key])) {
                    $ga_rows[$key] += $pairs_gb[$key];
                }
            }
        }

        $t_rows = array();

        foreach ($rows as $_value) {
            $rate = (!empty($ga_rows[$_value[0]])) ? sprintf('%01.2f', ($_value[2] / $ga_rows[$_value[0]]) * 100) : 0;
            $_value[2] = $rate ? $rate : 0;
            $t_rows[] = $_value;
        }

        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = array('Conversion Rate' => $t_rows);
            $csvRows = $csv->prepareCsvData($rows);
            $csvTitles = array('Time', 'Conversion Rate');

			$csv->setHeader($csvTitles);
			$csv->setData($csvRows, $csvTitles);
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        }
        // chart

        $chart = new App_Chart();
        $rows = $chart->fixRows($t_rows, $labels);

        //print_r($t_rows);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, 'floatval'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Orders/Vistors: #val#%');
        $line->setTitle('Conversion Rate');
        $line->appendTo($chart);

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function visitsAction() {
        $this->tpl->breadcrumb->add('Order CR (by Google)');
        $this->display();
    }

    public function visitsChartAction() {
        $this->tpl->chart = 'line';

        // get google data
        $dimensions = array('date', 'month', 'year');
        $metrics = array('visits', 'transactions');

        // get pairs
        $pairs = array();
        if ($this->tpl->localeId == 1) { //US
            $usGA = new \GoogleAnalytics();
            $filter = null;
            $results = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'visitorType=~New.*';
            $newResults = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter, array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter, array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }
        } else if ($this->tpl->localeId == 2) { //AU
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);

            $filter = null;
            $results = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResults = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }

        } else if ($this->tpl->localeId == 3) { //CA
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);

            $filter = null;
            $results = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResults = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }

        } else if ($this->tpl->localeId == 4) { // FR
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);

            $filter = null;
            $results = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResults = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }            
        } else if ($this->tpl->localeId == 6) { // DE
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);

            $filter = null;
            $results = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResults = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                } 

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }            
        } else if ($this->tpl->localeId == 7) { // GB
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);

            $filter = null;
            $results = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResults = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResults = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            foreach ($results as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                } 

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs[$group]['new'][1] += $newResults[$k][3];
                $pairs[$group]['new'][2] += $newResults[$k][4];

                $pairs[$group]['returning'][1] += $returningResults[$k][3];
                $pairs[$group]['returning'][2] += $returningResults[$k][4];

                $pairs[$group]['all'][1] += $result[3];
                $pairs[$group]['all'][2] += $result[4];
            }            
        } else { //ALL
            $usGA = new \GoogleAnalytics();
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);

            $filter = null;
            $resultsUS = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $resultsAU = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $resultsCA = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $resultsFR = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $resultsDE = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $resultsGB = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~New.*';
            $newResultsUS = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $newResultsAU = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $newResultsCA = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $newResultsFR = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $newResultsDE = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $newResultsGB = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $filter = 'userType=~Returning.*';
            $returningResultsUS = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $returningResultsAU = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $returningResultsCA = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $returningResultsFR = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $returningResultsDE = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $returningResultsGB = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));

            $pairs_us = array();
            $pairs_au = array();
            $pairs_au = array();
            $pairs_fr = array();
            $pairs_de = array();
            $pairs_gb = array();

            foreach ($resultsUS as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_us[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_us[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_us[$group]['new'][1] += $newResultsUS[$k][3];
                $pairs_us[$group]['new'][2] += $newResultsUS[$k][4];

                $pairs_us[$group]['returning'][1] += $returningResultsUS[$k][3];
                $pairs_us[$group]['returning'][2] += $returningResultsUS[$k][4];

                $pairs_us[$group]['all'][1] += $result[3];
                $pairs_us[$group]['all'][2] += $result[4];
            }

            foreach ($resultsAU as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_au[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_au[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_au[$group]['new'][1] += $newResultsAU[$k][3];
                $pairs_au[$group]['new'][2] += $newResultsAU[$k][4];

                $pairs_au[$group]['returning'][1] += $returningResultsAU[$k][3];
                $pairs_au[$group]['returning'][2] += $returningResultsAU[$k][4];

                $pairs_au[$group]['all'][1] += $result[3];
                $pairs_au[$group]['all'][2] += $result[4];
            }

            foreach ($resultsCA as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_ca[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_ca[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_ca[$group]['new'][1] += $newResultsCA[$k][3];
                $pairs_ca[$group]['new'][2] += $newResultsCA[$k][4];

                $pairs_ca[$group]['returning'][1] += $returningResultsCA[$k][3];
                $pairs_ca[$group]['returning'][2] += $returningResultsCA[$k][4];

                $pairs_ca[$group]['all'][1] += $result[3];
                $pairs_ca[$group]['all'][2] += $result[4];
            }
            
            foreach ($resultsFR as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_fr[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_fr[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_fr[$group]['new'][1] += $newResultsFR[$k][3];
                $pairs_fr[$group]['new'][2] += $newResultsFR[$k][4];

                $pairs_fr[$group]['returning'][1] += $returningResultsFR[$k][3];
                $pairs_fr[$group]['returning'][2] += $returningResultsFR[$k][4];

                $pairs_fr[$group]['all'][1] += $result[3];
                $pairs_fr[$group]['all'][2] += $result[4];
            }
            
            foreach ($resultsDE as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_de[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_de[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_de[$group]['new'][1] += $newResultsDE[$k][3];
                $pairs_de[$group]['new'][2] += $newResultsDE[$k][4];

                $pairs_de[$group]['returning'][1] += $returningResultsDE[$k][3];
                $pairs_de[$group]['returning'][2] += $returningResultsDE[$k][4];

                $pairs_de[$group]['all'][1] += $result[3];
                $pairs_de[$group]['all'][2] += $result[4];
            }
            
            foreach ($resultsGB as $k => $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[1];
                        break;

                    case 'yearly':
                        $group = $result[2];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_gb[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_gb[$group] = array('new' => array($date, 0, 0), 'returning' => array($date, 0, 0), 'all' => array($date, 0, 0));
                }

                $pairs_gb[$group]['new'][1] += $newResultsGB[$k][3];
                $pairs_gb[$group]['new'][2] += $newResultsGB[$k][4];

                $pairs_gb[$group]['returning'][1] += $returningResultsGB[$k][3];
                $pairs_gb[$group]['returning'][2] += $returningResultsGB[$k][4];

                $pairs_gb[$group]['all'][1] += $result[3];
                $pairs_gb[$group]['all'][2] += $result[4];
            }

            //union two array to make a new array
            foreach ($pairs_us as $key => $value)
            {
                $pairs[$key]['new'][0] = $pairs_au[$key]['new'][0];
                $pairs[$key]['new'][1] = $pairs_au[$key]['new'][1] + $pairs_ca[$key]['new'][1] + $pairs_fr[$key]['new'][1] + $pairs_de[$key]['new'][1] + $pairs_gb[$key]['new'][1] + $value['new'][1];
                $pairs[$key]['new'][2] = $pairs_au[$key]['new'][2] + $pairs_ca[$key]['new'][2] + $pairs_fr[$key]['new'][2] + $pairs_de[$key]['new'][2] + $pairs_gb[$key]['new'][2] + $value['new'][2];

                $pairs[$key]['returning'][0] = $pairs_au[$key]['returning'][0];
                $pairs[$key]['returning'][1] = $pairs_au[$key]['returning'][1] + $pairs_ca[$key]['returning'][1] + $pairs_fr[$key]['returning'][1] + $pairs_de[$key]['returning'][1] + $pairs_gb[$key]['returning'][1] + $value['returning'][1];
                $pairs[$key]['returning'][2] = $pairs_au[$key]['returning'][2] + $pairs_ca[$key]['returning'][2] + $pairs_fr[$key]['returning'][2] + $pairs_de[$key]['returning'][2] + $pairs_gb[$key]['returning'][2] + $value['returning'][2];

                $pairs[$key]['all'][0] = $pairs_au[$key]['all'][0];
                $pairs[$key]['all'][1] = $pairs_au[$key]['all'][1] + $pairs_ca[$key]['all'][1] + $pairs_fr[$key]['all'][1] + $pairs_de[$key]['all'][1] + $pairs_gb[$key]['all'][1] + $value['all'][1];
                $pairs[$key]['all'][2] = $pairs_au[$key]['all'][2] + $pairs_ca[$key]['all'][2] + $pairs_fr[$key]['all'][2] + $pairs_de[$key]['all'][2] + $pairs_gb[$key]['all'][2] + $value['all'][2];
            }
        }

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                // $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                // $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                // $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                // $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // chart
        $chart = new App_Chart();

        // settings
        $settings = array(
            'all' => array('All Visits', '#0033cc'),
            'new' => array('New Visits', '#009922'),
            'returning' => array('Returning Visits', '#ff6600'),
        );

        if(!empty($_GET['export'])) {
            $csvData = array();
            $csvTitles = array('Time');
        }
        // append to chart
        $num = 0;
        foreach ($settings as $_name => $_arr) {
            $num++;

            $rows = array();
            foreach ($pairs as $k => $pair) {
                if ($pair[$_name][1] == 0) {
                    $rate = 0;
                } else {
                    $rate = sprintf('%01.2f', ($pair[$_name][2] / $pair[$_name][1]) * 100);
                }

                $rows[] = array($k, $pair[$_name][0], $rate);
            }
            if(!empty($_GET['export'])) {
                $csvData[$_name] = $rows;
                if (!in_array($_name, $csvTitles)) {
                    $csvTitles[] = $_name;
                }
                continue;
            }
            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
            $line->setValues($chart->fetchColumn($rows, 1, 'floatval'), $chart->fetchColumn($rows, 0));
            $line->setTip("#x_label#<br>{$_arr[0]} CR (Orders/Visits): #val#%");
            $line->setTitle($_arr[0]);
            $line->appendTo($chart);
        }
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function accountAction() {
        $this->tpl->breadcrumb->add('New Account');
        $this->display();
    }

    public function accountChartAction() {
        // get google data
        $dimensions = array('date', 'week', 'month', 'year');
        $metrics = array('visits', 'visitors');

        $pairs = array();
        if ($this->tpl->localeId == 1) {
            $usGA = new \GoogleAnalytics();
            $results = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else if ($this->tpl->localeId == 2) {
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);

            $results = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else if ($this->tpl->localeId == 3) {
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);

            $results = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else if ($this->tpl->localeId == 4) {
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);

            $results = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else if ($this->tpl->localeId == 6) {
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);

            $results = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else if ($this->tpl->localeId == 7) {
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);

            $results = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, null ,array('date'));
            // get pairs
            foreach ($results as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs[$group] = 0;
                }
                $pairs[$group] += $result[5];
            }
        } else {
            $usGA = new \GoogleAnalytics();
            $auGA = new \GoogleAnalytics(GA_PROFILE_ID_AU);
            $caGA = new \GoogleAnalytics(GA_PROFILE_ID_CA);
            $frGA = new \GoogleAnalytics(GA_PROFILE_ID_FR);
            $deGA = new \GoogleAnalytics(GA_PROFILE_ID_DE);
            $gbGA = new \GoogleAnalytics(GA_PROFILE_ID_GB);

            $pairs_us = array();
            $pairs_au = array();
            $pairs_ca = array();
            $pairs_fr = array();
            $pairs_de = array();
            $pairs_gb = array();

            $filter = null;
            $results_us = $usGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $results_au = $auGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $results_ca = $caGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $results_fr = $frGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $results_de = $deGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            $results_gb = $gbGA->getReport($this->tpl->from, $this->tpl->to, $dimensions, $metrics, $filter ,array('date'));
            // get us pairs
            foreach ($results_us as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_us[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_us[$group] = 0;
                }
                $pairs_us[$group] += $result[5];
            }

            // get au pairs
            foreach ($results_au as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_au[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_au[$group] = 0;
                }
                $pairs_au[$group] += $result[5];
            }

            // get au pairs
            foreach ($results_ca as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_ca[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_ca[$group] = 0;
                }
                $pairs_ca[$group] += $result[5];
            }
            
            // get fr pairs
            foreach ($results_fr as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_fr[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_fr[$group] = 0;
                }
                $pairs_fr[$group] += $result[5];
            }
            
            // get de pairs
            foreach ($results_de as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_de[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_de[$group] = 0;
                }
                $pairs_de[$group] += $result[5];
            }
            
            // get gb pairs
            foreach ($results_gb as $result) {
                switch ($this->tpl->graphby) {
                    case 'weekly':
                        $group = date('oW', strtotime($result[0]));
                        break;

                    case 'monthly':
                        $group = $result[2];
                        break;

                    case 'yearly':
                        $group = $result[3];
                        break;

                    case 'daily':
                    default:
                        $group = date('Y-m-d', strtotime($result[0]));
                        break;
                }

                if (!isset($pairs_gb[$group])) {
                    $date = date('Y-m-d', strtotime($result[0]));
                    $pairs_gb[$group] = 0;
                }
                $pairs_gb[$group] += $result[5];
            }

            //union two array to make a new array
            foreach ($pairs_us as $key => $value) {
                $pairs[$key] = $value + $pairs_au[$key] + $pairs_ca[$key] + $pairs_fr[$key] + $pairs_de[$key] + $pairs_gb[$key] ;
            }
        }

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(customers_info_date_account_created, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM customers_info_date_account_created)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(customers_info_date_account_created)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND c.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }

        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //SQL
        $sql = "SELECT $groupby, customers_info_date_account_created, COUNT(*) total
                FROM customers c
                LEFT JOIN customers_info i
                ON (c.customers_id = i.customers_info_id)
                WHERE customers_info_date_account_created >= '{$this->tpl->from} 00:00:00' AND customers_info_date_account_created <= '{$this->tpl->to} 23:59:59'
                $localeWhere
                GROUP BY $groupby
                ORDER BY c.customers_id ASC";
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        // chart
        $chart = new App_Chart();

        // get CR
        foreach ($rows as &$row) {
            if (!isset($pairs[$row[0]]) || ($pairs[$row[0]] == 0)) {
                $row[2] = 0;
            } else {
                $row[2] = sprintf('%01.2f', ($row[2] / $pairs[$row[0]]) * 100);
            }
        }

        // chart
        $chart = new App_Chart();

        // settings
        $settings = array(
            'visitors' => array('Conversion Rate', '#0033cc'),
                /*
                  'visits' => array('All Visits', '#0033cc'),
                  'new' => array('New Visits', '#009922'),
                  'returning' => array('Returning Visits', '#ff6600'),
                 */
        );
        if(!empty($_GET['export'])) {
            $csvData = array();
            $csvTitles = array('Time');
        }
        // append to chart
        $num = 0;
        foreach ($settings as $_name => $_arr) {
            $num++;
            if(!empty($_GET['export'])) {
                $csvData[$_name] = $rows;
                if (!in_array($_name, $csvTitles)) {
                    $csvTitles[] = $_name;
                }
                continue;
            }
            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
            $line->setValues($chart->fetchColumn($rows, 1, 'floatval'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>New Account/Vistors: #val#%');
            $line->setTitle($_arr[0]);
            $line->appendTo($chart);
        }
        if(!empty($_GET['export'])) {
            $csv = new App_Csv();
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader(array('Time', 'Conversion Rate'));
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
            exit;
        }

        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }
}