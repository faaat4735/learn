<?php

set_include_path(get_include_path() . PATH_SEPARATOR . INC_DIR);
require_once 'OFC/OFC_Chart.php';

class App_Module_Chart extends App_Module
{
	public function frameAction()
	{
		//configs
		$ysize = 5;
		$ftime = 'M j, Y';

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
        $localeId =& $_GET['localeId'];
		$from = addslashes($from);
		$to = addslashes($to);
		if (empty($from)) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (empty($to)) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
        if ( !$localeId ){
            $localeId = 0;
        }
		//stat
		$stat =& $_GET['stat'];

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";

        //locale
        if($localeId){
            $localeWhere = " AND o.locale_id = {$localeId} ";
        } else {
            $localeWhere = "";
        }
        $countryId =& $_GET['country'];
        $country ='';
		if ($countryId) {
			$country = App_Model_Orders::getCountryName($countryId);
		}
        if (!empty($country)) {
            $localeWhere .= " AND o.delivery_country = '{$country}' ";
        }

		//sortby
		$sortby =& $_GET['sortby'];
		switch ($sortby) {
			case 'id':
				$sortbyWhere = 'ORDER BY p.product_id ASC';
				break;
			case 'code':
				$sortbyWhere = 'ORDER BY p.product_code ASC';
				break;
			case 'name':
				$sortbyWhere = 'ORDER BY pm.product_name ASC';
				break;
			case 'stock':
				$sortbyWhere = 'ORDER BY p.product_quantity ASC';
				break;
			case 'number':
			default:
				$sortbyWhere = 'ORDER BY total ASC';
				break;
		}

		//SQL
		$sql = sprintf("SELECT " . ($stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : "COUNT(*)") . " total,
                    p.product_id, p.product_code, p.product_price, pm.product_name, date_purchased, p.product_quantity
                    FROM orders o FORCE INDEX (date2status)
                    LEFT JOIN orders_total ot
                    ON (o.orders_id = ot.orders_id)
                    LEFT JOIN orders_ext oe
                    ON (o.orders_id = oe.orders_id)
                    LEFT JOIN orders_products op
                    ON (op.orders_id = o.orders_id)
                    LEFT JOIN t_product p ON (p.product_id = op.products_id)
                    LEFT JOIN t_product_model pm ON pm.model_id = p.model_id
                    WHERE p.product_id IS NOT NULL
                    %s
                    %s
                    AND ot.class = 'total'
                    AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                    GROUP BY p.product_id $sortbyWhere",
                    $statusWhere, $localeWhere, $from, $to );
		$rows = App_Db::getInstance()->getAll($sql);

		$values = array();
		$labels = array();
		$max = 0;
		foreach ($rows as $row) {
			$total = intval($row->total);
			$max = $total > $max ? $total : $max;
			$values[] = $total;
			$labels[] = $row->product_name . ' - $' . sprintf('%.2f', $row->product_price)
				. '<br>Model: ' . $row->product_code . ', ID:' . $row->product_id
				. '<br><br>Stock: ' . $row->product_quantity;
		}
		$yunit = ceil($max / $ysize);
		$yunit = max($yunit, 1);

		//draw graph
		$title = new OFC_Elements_Title('');

		$x = new OFC_Elements_Axis_X();
		$x->set_grid_colour('#ffffff');
		$x->set_range(0, count($rows));
		$x->set_stroke(1);

		$x_labels = new OFC_Elements_Axis_X_Label_Set();
		$x_labels->set_colour('#ffffff');
		$x_labels->set_labels($labels);
		$x_labels->set_size(1);
		$x->set_labels($x_labels);

		$y = new OFC_Elements_Axis_Y();
		$y->set_range(0, $yunit*$ysize, $yunit);
		$y->set_grid_colour('#eeeeee');
		$y->set_stroke(1);

		$bar = new OFC_Charts_Bar();
		$bar->set_values($values);
		$bar->tip = '#x_label#<br>Order Total: #val#';

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_x_axis($x);
		$chart->set_y_axis($y);
		$chart->set_title($title);
		$chart->add_element($bar);
		echo $chart->toPrettyString();
	}

	public function totalAction()
	{
		//configs
		$xsize = 5;
		$ysize = 5;
		$ftime = 'M j, Y';

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$from = addslashes($from);
		$to = addslashes($to);
		if (empty($from)) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (empty($to)) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}

		$fromTimestamp = strtotime($from);
		$toTimestamp = strtotime($to);

		//graphby
		$graphby =& $_GET['graphby'];
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(date_purchased, 3)';
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
				break;
			case 'daily':
			default:
				$groupby = 'DATE(date_purchased)';
				$graphby = 'daily';
				break;
		}

		//status
		$states =& $_GET['states'];
		if (empty($states)) {
			$states = App_Model_Orders::getCommonStatusList();
		}
		$_states = array_map('intval', $states);
		$_states = implode(', ', $_states);
		$statusWhere = "AND o.orders_status IN ({$_states})";

		//SQL
		$sql = sprintf("SELECT COUNT(*) total, date_purchased
				FROM orders o FORCE INDEX (date2status)
				LEFT JOIN orders_total ot
				ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
				WHERE 1 = 1
				%s
				AND ot.class = 'total'
				AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
				GROUP BY %s
				ORDER BY o.orders_id ASC",
				$statusWhere, $from, $to, $groupby);

		$rows = App_Db::getInstance()->getAll($sql);
		$count = count($rows);
		$xunit = ceil($count / $xsize);
		$xunit = max($xunit, 1);
//		$xunit = ceil($xunit / 7) * 7;

		$labels = array();
		$data = array();
		$max = 0;
		for( $i=0; $i<$count; $i++ ) {
			$total = intval($rows[$i]->total);

			$max = $total > $max ? $total : $max;

			switch ($graphby) {
				case 'weekly':
					$_tmp = Jcan_Date::aweek(strtotime($rows[$i]->date_purchased), 1);
					if ($_tmp[0] < $fromTimestamp) {
						$_tmp[0] = $fromTimestamp;
					}
					if ($_tmp[1] > $toTimestamp) {
						$_tmp[1] = $toTimestamp;
					}
					$labels[] = date($ftime, $_tmp[0]) . ' - ' . date($ftime, $_tmp[1]);
					break;
				case 'monthly':
					$_tmp = Jcan_Date::amonth(strtotime($rows[$i]->date_purchased));
					if ($_tmp[0] < $fromTimestamp) {
						$_tmp[0] = $fromTimestamp;
					}
					if ($_tmp[1] > $toTimestamp) {
						$_tmp[1] = $toTimestamp;
					}
					$labels[] = date($ftime, $_tmp[0]) . ' - ' . date($ftime, $_tmp[1]);
					break;
				case 'daily':
				default:
					$whichDay = date('N', strtotime($rows[$i]->date_purchased));
					if ($whichDay == 6 || $whichDay == 7) {
						$x = new stdClass;
						$x->value = $total;
						$x->colour = '#ff6600';
						$total = $x;
					}
					$labels[] = date($ftime . ' - l', strtotime($rows[$i]->date_purchased));
					break;
			}
			$data[] = $total;
		}
		$yunit = ceil($max / $ysize);
		$yunit = max($yunit, 1);
		if ($yunit > 100000) {
			$yunit = ceil($yunit/1000) * 1000;
		} elseif ($yunit > 1000) {
			$yunit = ceil($yunit/100) * 100;
		} elseif ($yunit > 10) {
			$yunit = ceil($yunit/10) * 10;
		}

		if ($count > 60) {
			$line_dot = new OFC_Charts_Line();
		} else {
			$line_dot = new OFC_Charts_Line_Dot();
		}
		$line_dot->set_width(3);
		$line_dot->set_dot_size(3);
		$line_dot->set_colour('#0077cc');
		$line_dot->set_values($data);
		$line_dot->tip = '#x_label#<br>Order Total: #val#';

		$x = new OFC_Elements_Axis_X();
		$x->set_grid_colour('#eeeeee');
		$x->set_stroke(1);
		$x->set_steps($xunit);

		$x_labels = new OFC_Elements_Axis_X_Label_Set();
		$x_labels->set_steps($xunit);
//		$x_labels->rotate = "vertical";
//		$tmp = $labels;
//		$labels = array();
//		foreach ($tmp as $_label) {
//			$labels[] = array(
//				'text' => $_label,
//				'rotate' => 'diagonal',
//			);
//		}
		$x_labels->set_labels($labels);
		$x->set_labels($x_labels);

		$y = new OFC_Elements_Axis_Y();
		$y->set_range(0, $yunit * $ysize, $yunit);
		$y->set_grid_colour('#f3f3f3');
		$y->set_stroke(1);

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title(new OFC_Elements_Title(''));
		$chart->set_y_axis($y);
		$chart->set_x_axis($x);
		$chart->add_element($line_dot);

		echo $chart->toPrettyString();
	}


	public function usersAction()
	{
		//configs
		$xsize = 5;
		$ysize = 5;
		$ftime = 'M j, Y';

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$from = addslashes($from);
		$to = addslashes($to);
		if (empty($from)) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (empty($to)) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}

		$fromTimestamp = strtotime($from);
		$toTimestamp = strtotime($to);

		//graphby
		$graphby =& $_GET['graphby'];
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(customers_info_date_account_created, 3)';
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
				break;
			case 'daily':
			default:
				$groupby = 'DATE(customers_info_date_account_created)';
				$graphby = 'daily';
				break;
		}

		//gender
		$genderWhere = '';
		$gender =& $_GET['gender'];
		if ($gender == 'm' || $gender == 'f') {
			$genderWhere = "AND customers_gender = '$gender'";
		}

		//SQL
		$sql = sprintf("SELECT COUNT(*) total, DATE(customers_info_date_account_created) time
				FROM customers c
				LEFT JOIN customers_info i
				ON (c.customers_id = i.customers_info_id)
				WHERE DATE(customers_info_date_account_created) BETWEEN DATE('%s') AND DATE('%s') $genderWhere
				GROUP BY %s
				ORDER BY c.customers_id ASC",
				$from, $to, $groupby);

		$rows = App_Db::getInstance()->getAll($sql);
		$count = count($rows);
		$xunit = ceil($count / $xsize);
		$xunit = max($xunit, 1);
//		$xunit = ceil($xunit / 7) * 7;

		$labels = array();
		$data = array();
		$max = 0;
		for( $i=0; $i<$count; $i++ ) {
			$total = intval($rows[$i]->total);

			$max = $total > $max ? $total : $max;
			$data[] = $total;

			switch ($graphby) {
				case 'weekly':
					$_tmp = Jcan_Date::aweek(strtotime($rows[$i]->time), 1);
					if ($_tmp[0] < $fromTimestamp) {
						$_tmp[0] = $fromTimestamp;
					}
					if ($_tmp[1] > $toTimestamp) {
						$_tmp[1] = $toTimestamp;
					}
					$labels[] = date($ftime, $_tmp[0]) . ' - ' . date($ftime, $_tmp[1]);
					break;
				case 'monthly':
					$_tmp = Jcan_Date::amonth(strtotime($rows[$i]->time));
					if ($_tmp[0] < $fromTimestamp) {
						$_tmp[0] = $fromTimestamp;
					}
					if ($_tmp[1] > $toTimestamp) {
						$_tmp[1] = $toTimestamp;
					}
					$labels[] = date($ftime, $_tmp[0]) . ' - ' . date($ftime, $_tmp[1]);
					break;
				case 'daily':
				default:
					$labels[] = date($ftime, strtotime($rows[$i]->time));
					break;
			}
		}
		$yunit = ceil($max / $ysize);
		$yunit = max($yunit, 1);
		if ($yunit > 100000) {
			$yunit = ceil($yunit/1000) * 1000;
		} elseif ($yunit > 1000) {
			$yunit = ceil($yunit/100) * 100;
		} elseif ($yunit > 10) {
			$yunit = ceil($yunit/10) * 10;
		}

		if ($count > 60) {
			$line_dot = new OFC_Charts_Line();
		} else {
			$line_dot = new OFC_Charts_Line_Dot();
		}
		$line_dot->set_width(3);
		$line_dot->set_dot_size(3);
		$line_dot->set_colour('#0077cc');
		$line_dot->set_values($data);
		$line_dot->tip = '#x_label#<br>Order Total: #val#';

		$x = new OFC_Elements_Axis_X();
		$x->set_grid_colour('#eeeeee');
		$x->set_stroke(1);
		$x->set_steps($xunit);

		$x_labels = new OFC_Elements_Axis_X_Label_Set();
		$x_labels->set_steps($xunit);
		$x_labels->set_labels($labels);
		$x->set_labels($x_labels);

		$y = new OFC_Elements_Axis_Y();
		$y->set_range(0, $yunit * $ysize, $yunit);
		$y->set_grid_colour('#f3f3f3');
		$y->set_stroke(1);

		$chart = new OFC_Chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title(new OFC_Elements_Title(''));
		$chart->set_y_axis($y);
		$chart->set_x_axis($x);
		$chart->add_element($line_dot);

		echo $chart->toPrettyString();
	}

	public function keywordAction()
	{

		//configs
		$xsize = 5;

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$from = addslashes($from);
		$to = addslashes($to);
		if (empty($from)) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (empty($to)) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}

		//orderby
		$orderbyWhere = '';
		$orderby =& $_GET['orderby'];
		if ($orderby == 'a') {
			$orderbyWhere = "ORDER BY keyword DESC";
		}elseif ($orderby == 'c') {
			$orderbyWhere = "ORDER BY total DESC";
		}else{
			$orderbyWhere = "ORDER BY keyword_id DESC";
		}

		//SQL
		$sql = sprintf("SELECT keyword, COUNT(*) total
				FROM priv_search_keywords
				WHERE DATE(createtime) BETWEEN DATE('%s') AND DATE('%s')
				GROUP BY keyword
				$orderbyWhere",
				$from, $to);
		$rows = App_Db::getInstance()->getAll($sql);

		$count = count($rows);
		$xunit = ceil($count / $xsize);
		$xunit = max($xunit, 1);
		if (isset($_GET['getcount']) && $_GET['getcount']==1){
			echo 'var t_count = ' . $count . ';';
			return;
		}
		$y_labels = array();
		$data = array();
		$max = 0;
		for( $i=0; $i<$count; $i++ ) {
			$total = intval($rows[$i]->total);
			$max = $total > $max ? $total : $max;
			$data[] = new OFC_Charts_Bar_Horizontal_Value(0,$total);
			$y_labels[] = $rows[$i]->keyword;
		}
		$xunit = ceil($max / $xsize);
		$xunit = max($xunit, 1);
		if ($xunit > 100000) {
			$xunit = ceil($xunit/1000) * 1000;
		} elseif ($xunit > 1000) {
			$xunit = ceil($xunit/100) * 100;
		} elseif ($xunit > 10) {
			$xunit = ceil($xunit/10) * 10;
		}
		$title = new OFC_Elements_Title( '' );
		$hbar = new OFC_Charts_Bar_Horizontal();
		$hbar->colour    = "blue";
		$hbar->values	= $data;
		$hbar->text = 'Search Count';
		$hbar->tip = 'Search Count: #val#';
		$chart = new OFC_Chart();
		$chart->set_title( $title );
		$chart->add_element( $hbar );

		$x = new OFC_Elements_Axis_X();
		$x->set_offset( false );
		$x->set_range(0, $xunit * $xsize, $xunit);
		$x->set_stroke(1);
		$x->set_grid_colour('#eeeeee');

		$y = new OFC_Elements_Axis_Y();
		$y->set_offset( true );
		$y->set_grid_colour('#f3f3f3');
		$y->set_stroke(1);
		$y->set_labels( $y_labels );

		$chart->set_x_axis( $x );
		$chart->add_y_axis( $y );
		$chart->set_bg_colour('#ffffff');

		echo $chart->toPrettyString();
	}
}