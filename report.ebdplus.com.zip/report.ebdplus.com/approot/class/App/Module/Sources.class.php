<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Sources extends App_Module
{
	public $sources = array(
		'News Article'		=> 'News Article',
		'Postcard Mailer'	=> 'Postcard Mailer',
		'Wall Street Journal'	=> 'Wall Street Journal',
		'Friend/WordofMouth'	=> 'Friend/Word of Mouth',
		'MessageBoards'		=> 'Message Boards',
		'Search Engine'		=> 'Search Engine',
		'Shopping Comparison Sit'	=> 'Shopping Comparison Site',
		'Amazon'		=> 'Amazon',
		'Facebook'		=> 'Facebook',
		'PackageBoxInsert'	=> 'Package/Box Insert',
		'CouponWebsite'		=> 'Coupon Website',
		'LoyaltyRewardsWebsite'	=> 'Loyalty/Rewards Website',
		'Manufacturer Website'	=> 'Manufacturer Website',
		'ReferralEmail'		=> 'Referral Email/Coupon',
		'Other'			=> 'Other',
	);

	public function __construct($tpl)
	{
		parent::__construct($tpl);

		//from date & end date
		$from =& $_GET['from'];
		$to =& $_GET['to'];
		$graphby =& $_GET['graphby'];
		$chart =& $_GET['chart'];
		$source = empty($_GET['source']) ? array() : $_GET['source'];

		if (!$from) {
			$from = date('Y-m-d', strtotime('-2 month -1 day'));
		}
		if (!$to) {
			$to = date('Y-m-d', strtotime('-1 day'));
		}
		if (!$graphby) {
			$graphby = 'daily';
		}
		if (!$chart) {
			$chart = 'line';
		}
		if (empty($source)) {
			$source = array_keys($this->sources);
		}

		$this->tpl->assign('from', addslashes($from));
		$this->tpl->assign('to', addslashes($to));
		$this->tpl->assign_by_ref('graphby', $graphby);
		$this->tpl->assign_by_ref('chart', $chart);
		$this->tpl->assign_by_ref('source', $source);
		$this->tpl->assign_by_ref('sources', $this->sources);
	}

	public function indexAction()
	{
		$this->reflect('Sources', 'report');
	}

	public function reportAction()
	{
		$this->tpl->breadcrumb->add('Line/Bar Chart');
		$this->display();
	}

	public function reportChartAction()
	{
		/**
		 * @var App_Db
		 */
		$db = App_Db::getInstance();

		//groupby, $labels
		$graphby = $this->tpl->graphby;
		switch ($graphby) {
			case 'weekly':
				$groupby = 'YEARWEEK(customers_info_date_account_created, 3)';
				$labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'monthly':
				$groupby = 'EXTRACT(YEAR_MONTH FROM customers_info_date_account_created)';
				$labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'yearly':
				$groupby = 'EXTRACT(YEAR FROM customers_info_date_account_created)';
				$labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
				$chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
				break;
			case 'daily':
			default:
				$groupby = 'DATE(customers_info_date_account_created)';
				$labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
				$chartLabels = $labels;
				break;
		}

		//SQL
		$sql = sprintf("SELECT $groupby groupby, customers_info_date_account_created, COUNT(*) total
				FROM customers c
				LEFT JOIN customers_info i
				ON c.customers_id = i.customers_info_id
				WHERE customers_info_date_account_created <= '%s 23:59:59' AND customers_info_date_account_created >= '%s 00:00:00'
				AND FIND_IN_SET(hear_from, '%s')
				GROUP BY %s
				ORDER BY c.customers_id ASC",
				$this->tpl->to, $this->tpl->from, addslashes(implode(',', $this->tpl->source)), $groupby);

        if(!empty($_GET['export'])) {
            $rows = $db->getAll($sql, null,PDO::FETCH_OBJ);
            $csv = new App_Csv();
			$csv->setHeader(array('Time', 'Total'));
			$csv->setData($rows, array('groupby', 'total'));
			$csv->setDataRange($this->tpl->from, $this->tpl->to);$csv->output();
			exit;
        } else {
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        }

		// chart
		$chart = new App_Chart();

		// fix rows
		$rows = $chart->fixRows($rows, $labels);

		$line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
		$line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
		$line->setTip('#x_label#<br>Total: #val#');
		$line->appendTo($chart);

		$chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
		$chart->output();
	}

	public function pieAction()
	{
		$this->tpl->breadcrumb->add('Pie Chart');
		$this->display();
	}

	public function pieChartAction()
	{
		//SQL
		$sql = sprintf("SELECT hear_from, COUNT(*) total
				FROM customers c
				LEFT JOIN customers_info i
				ON c.customers_id = i.customers_info_id
				WHERE customers_info_date_account_created <= '%s 23:59:59' AND customers_info_date_account_created >= '%s 00:00:00'
				AND FIND_IN_SET(hear_from, '%s')
				GROUP BY hear_from
				ORDER BY c.customers_id ASC",
				$this->tpl->to, $this->tpl->from, addslashes(implode(',', $this->tpl->source)));
		$rows = App_Db::getInstance()->getAll($sql, PDO::FETCH_KEY_PAIR);
		asort($rows);

		//draw graph
		$title = new title('');

		$pie = new pie();
		$pie->set_start_angle(35);
		$tmp = array();
		foreach ($rows as $k => $v) {
			$num = intval($v);
			$tmp[] = new pie_value($num, $this->sources[$k]);
		}

		$pie->values = $tmp;
		$pie->tip = '#label#<br>#val# of #total# (#percent#)';

		$chart = new open_flash_chart();
		$chart->set_bg_colour('#ffffff');
		$chart->set_title($title);
		$chart->add_element($pie);
		echo $chart->toPrettyString();
	}
}