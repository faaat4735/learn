<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Giftcard extends App_Module {

    public function __construct($tpl) {
        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $localeId = & $_GET['localeId'];
        $graphby = & $_GET['graphby'];
        $stat = & $_GET['stat'];
        $chart = & $_GET['chart'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month'));
        }
        if (!$to) {
            $to = date('Y-m-d');
        }
        if (!$localeId) {
            $localeId = 0;
        }
        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$stat) {
            $stat = 'volume';
        }
        if (!$chart) {
            $chart = 'line';
        }

        //sortby
        $sortby = & $_GET['sortby'];
        if (!$sortby) {
            $sortby = 'number';
        }
        
        $this->tpl->assign('localeId', $localeId);
        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('sortby', $sortby);
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('chart', $chart);
    }

    public function indexAction() {
        $this->reflect('Giftcard', 'report');
    }

    public function reportChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }
        $colors = array('#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa');
        $types = $db->getAll("SELECT * FROM t_giftcard_type", null, PDO::FETCH_ASSOC);
        // chart
        $chart = new App_Chart();
        
        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        
        // settings
        $settings = array(
            'total' => array('Total', '#0033cc'),
        );

        //SQL
        $sqlTotal = sprintf("SELECT $groupby,o.date_purchased, %s total
				FROM t_giftcard_order o
                LEFT JOIN t_giftcard_order_detail od ON o.gc_order_id = od.gc_order_id
				LEFT JOIN t_giftcard_type t ON od.gc_type_id = t.gc_type_id
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND o.order_status = 1
                $localeWhere
				GROUP BY $groupby
				ORDER BY o.gc_order_id ASC", $this->tpl->stat == 'value' ? "SUM(gc_quantity * amount)" : "SUM(gc_quantity)", $this->tpl->from, $this->tpl->to);

        foreach ($types as $key => $type) {
            ${'sql' . $type['gc_type_id']} = sprintf("SELECT $groupby,o.date_purchased, %s total
                    FROM t_giftcard_order o
                    LEFT JOIN t_giftcard_order_detail od ON o.gc_order_id = od.gc_order_id
                    LEFT JOIN t_giftcard_type t ON od.gc_type_id = t.gc_type_id
                    WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                    AND order_status = 1 AND od.gc_type_id =" . $type['gc_type_id'] .$localeWhere.
                    " GROUP BY $groupby
                    ORDER BY o.gc_order_id ASC", $this->tpl->stat == 'value' ? "SUM(gc_quantity * amount)" : "SUM(gc_quantity)", $this->tpl->from, $this->tpl->to);
            $settings[$type['gc_type_id']] = array($type['amount'], isset($colors[$key]) ? $colors[$key] : $colors[0]);
        }

        if (!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvData = array();
            $csvTitles = array('Time');
        }
        // append to chart
        foreach ($settings as $_name => $_arr) {
            $rows = $db->getAll(${'sql' . ucfirst($_name)}, null, PDO::FETCH_NUM);
            if (!empty($_GET['export'])) {
                $csvData[$_arr[0]] = $rows;
                if (!in_array($_arr[0], $csvTitles)) {
                    $csvTitles[] = $_arr[0];
                }
                continue;
            }

            $rows = $chart->fixRows($rows, $labels);

            $line = $chart->getShape($this->tpl->chart, count($labels), $_arr[1]);
            $line->setValues($chart->fetchColumn($rows, 1, $this->tpl->stat == 'value' ? '%.2f' : 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>#key#: $#val#' : '#x_label#<br>#key#: #val#');
            $line->setTitle($_arr[0]);
            $line->appendTo($chart);
        }
        if (!empty($_GET['export'])) {
            $rows = $csv->prepareCsvData($csvData);
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function reportAction() {
        $this->tpl->breadcrumb->add('Giftcard Orders');
        $this->display();
    }

    public function applyAction() {
        $this->tpl->breadcrumb->add('Applied Gift Card');
        $this->display();
    }

    public function applyChartAction() {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(o.date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM o.date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM o.date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(o.date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }
        
        //locale
        if ($this->tpl->localeId) {
            $localeWhere = " AND o.locale_id = {$this->tpl->localeId} ";
        } else {
            $localeWhere = "";
        }
        
        //SQL
        $sql = sprintf("SELECT $groupby,o.date_purchased, %s total
                FROM orders o FORCE INDEX (date2status)
                LEFT JOIN orders_total ot
                ON (o.orders_id = ot.orders_id)
                LEFT JOIN orders_ext oe
                ON (o.orders_id = oe.orders_id)
                WHERE o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                AND o.orders_status IN (1, 14, 16, 9, 4, 10, 20, 18, 12, 2, 8, 3)
                AND ot.class = 'giftcard'
                $localeWhere
                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                GROUP BY $groupby
                ORDER BY o.orders_id ASC", $this->tpl->stat == 'value' ? "-SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ")" : "COUNT(*)", $this->tpl->from, $this->tpl->to);
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if (!empty($_GET['export'])) {
            $csv = new App_Csv();
            $csvRows = $csv->prepareCsvData(array('Total' => $rows));
            $csvTitles = array('Time', 'Total');

            $csv->setHeader($csvTitles);
            $csv->setData($csvRows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        // chart
        $chart = new App_Chart();

        // fix rows
        $rows = $chart->fixRows($rows, $labels);

        $line = $chart->getShape($this->tpl->chart, count($labels), '#0033cc');
        $line->setValues($chart->fetchColumn($rows, 1, $this->tpl->stat == 'value' ? '%.2f' : 'intval'), $chart->fetchColumn($rows, 0));
        $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>$#val#' : '#x_label#<br>#val# orders');
        $line->appendTo($chart);
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    /**
     * prepare data for exporting csv file
     *
     * @param array $datas
     * @return array
     */
    private function getCsvData($datas) {
        $result = array();
        $titles = array('Time');
        foreach ($datas as $data) {
            if ($data[0]) {
                $title = $data[0];
                if (!in_array($title, $titles)) {
                    $titles[] = $title;
                }
                foreach ($data[1] as $v) {
                    if (!isset($result[$v[0]])) {
                        $result[$v[0]]['Time'] = $v[0];
                    }
                    $result[$v[0]][$title] = number_format($v[2], 2);
                }
            }
        }

        return array('results' => $result, 'titles' => $titles);
    }

}
