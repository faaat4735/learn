<?php

require_once INC_DIR . "OFC2/open-flash-chart.php";

class App_Module_Price extends App_Module
{

    const addGiftVoucher = true;

    protected $price = array(
        '0.00-10.00' => '6.00, 8.00, 9.00',
        '10.00-20.00' => '12.00, 15.00, 19.00',
        '20.00-30.00' => '22.00, 25.00, 29.00',
        '30.00-40.00' => '32.00, 35.00, 39.00',
        '40.00-50.00' => '42.00, 45.00, 49.00',
        '50.00' => '52.00, 55.00, 59.00, 62.00, 65.00, 69.00, 75.00, 85.00',
    );

    public function __construct($tpl)
    {
        parent::__construct($tpl);

        $statusList = App_Model_Orders::getStatusList();
        $this->tpl->assign_by_ref('statusList', $statusList);

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }

        //from date & end date
        $from = & $_GET['from'];
        $to = & $_GET['to'];
        $graphby = & $_GET['graphby'];
        $stat = & $_GET['stat'];
        $chart = & $_GET['chart'];
        if (!$from) {
            $from = date('Y-m-d', strtotime('-2 month'));
        }
        if (!$to) {
            $to = date('Y-m-d');
        }
        if (!$graphby) {
            $graphby = 'daily';
        }
        if (!$stat) {
            $stat = 'volume';
        }
        if (!$chart) {
            $chart = 'line';
        }

        //sortby
        $sortby = & $_GET['sortby'];
        if (!$sortby) {
            $sortby = 'number';
        }

        $this->tpl->assign('from', addslashes($from));
        $this->tpl->assign('to', addslashes($to));
        $this->tpl->assign_by_ref('graphby', $graphby);
        $this->tpl->assign_by_ref('sortby', $sortby);
        $this->tpl->assign_by_ref('stat', $stat);
        $this->tpl->assign_by_ref('chart', $chart);
    }

    public function indexAction()
    {
        $this->reflect('Price', 'range');
    }

    public function rangeAction()
    {
        $prices = $this->getPriceRange();
        $this->tpl->priceRanges = $prices;
        $this->tpl->breadcrumb->add('Price Range');
        $this->display();
    }

    public function rangepieAction()
    {
        $prices = $this->getPricePieRange();
        $this->tpl->priceRanges = $prices;
        $this->tpl->breadcrumb->add('Price Range');
        $this->display();
    }

    public function avgordersAction()
    {
        $prices = $this->getPricePieRange();
        $this->tpl->priceRanges = $prices;
        $this->tpl->breadcrumb->add('Jobs');
        $this->display();
    }

    public function rangepieChartAction()
    {

        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();
        if ((isset($_GET['rprice']) && $_GET['rprice'][0] != '6.00') || (isset($_GET['rprice']) && count($_GET['rprice'] > 1))) {
            $prices = &$_GET['rprice'];
        } else {
            $prices = array('0.00-10.00', '10.00-20.00', '20.00-30.00', '30.00-40.00', '40.00-50.00', '50.00');
        }
        foreach ($prices as $price) {
            if (!isset($this->price[$price])) {
                continue;
            }
            $priceSql = ' price IN (' . $this->price[$price] . ')';
            $sql = sprintf("SELECT %s total
                            FROM g_products_price_cnt
                            WHERE day >= '%s 00:00:00' AND day <= '%s 23:59:59'
                            AND $priceSql", $this->tpl->stat == 'value' ? "SUM(price * cnt)" : "SUM(cnt)", $this->tpl->from, $this->tpl->to);
            $$price = $db->getOne($sql, null, PDO::FETCH_NUM);
            //echo $sql."<br>";
            $retval['$' . $price] = $$price;
        }

        // draw graph
        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        asort($retval);

        $total = array_sum($retval);
        foreach ($retval as $k => $v) {
            if ($v) {
                $num = round($v, 2);
                $tmp[] = new pie_value($num, $k . ' (' . sprintf('%.2f%%', 100 * $num / $total) . ')');
            }
        }

        $pie->values = $tmp;
        $pie->tip = '#label#<br> #percent#';

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function rangeChartAction()
    {

        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(day, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM day)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM day)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'day';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // prices
        //$prices = $this->_getRencentPrices();
        // prices
        if (isset($_GET['rprice'])) {
            $prices = &$_GET['rprice'];
        } else {
            $prices = array('6.00');
        }
        // get array
        $xRows = array();
        foreach ($prices as $price) {
            if (isset($this->price[$price]) && $this->price[$price]) {
                $priceSql = ' price IN (' . $this->price[$price] . ')';
            } else {
                $priceSql = " price = '$price' ";
            }
            if ($price != 'On sale')
                $sql = sprintf("SELECT $groupby, day, %s total
                                FROM g_products_price_cnt
                                WHERE day >= '%s 00:00:00' AND day <= '%s 23:59:59'
                                AND $priceSql
                                GROUP BY %s
                                ORDER BY id ASC", $this->tpl->stat == 'value' ? "SUM(price * cnt)" : "SUM(cnt)", $this->tpl->from, $this->tpl->to, $groupby);
//			else
//				$sql = sprintf("SELECT $groupby, day, %s/COUNT(distinct(day)) total
//					FROM g_products_price_cnt
//					WHERE day >= '%s 00:00:00' AND day <= '%s 23:59:59'
//					AND price not in('6.95', '8.95', '14.95', '19.95', '22.95', '29.95', '32.95', '39.95', '45.95', '49.95')
//					GROUP BY $groupby
//					ORDER BY id ASC",
//					$this->tpl->stat == 'value' ? "SUM(cnt * price)" : "SUM(cnt)", $this->tpl->from, $this->tpl->to, $groupby);
            //echo $sql."<br>";
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
            $xRows[] = array($price, $rows);
        }

        if (!empty($_GET['export'])) {
            $rows = $this->getCsvData($xRows);
            $csvTitles = $prices;
            array_unshift($csvTitles, 'Time');
            $csv = new App_Csv();
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }



        // chart
        $chart = new App_Chart();

        // colors
        $colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#522a06', '#0bb8ea', '#999900', '#FF0000', '#990088', '#6666aa', '#00EE00');
        foreach ($xRows as $key => $v) {
            $title = ($v[0] == 'On sale' ? '' : '$') . $v[0];
            $rows = $v[1];
            $color = $colors[$key];

            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, true, $color);
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val# (#key#)' : '#x_label#<br>Total: #val# (#key#)');
            $line->setTitle($title);
            $line->appendTo($chart);
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function avgordersChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        // get recent prices
        //$prices = $this->_getRencentPrices();
        if ((isset($_GET['rprice']) && $_GET['rprice'][0] != '6.00') || (isset($_GET['rprice']) && count($_GET['rprice'] > 1))) {
            $prices = &$_GET['rprice'];
        } else {
            $prices = array('0.00-10.00', '10.00-20.00', '20.00-30.00', '30.00-40.00', '40.00-50.00', '50.00');
        }

        // get array
        $xRows = array();
        $priceString = '';
        $totalNumber = count($prices);
        foreach ($prices as $key => $price) {
            if (isset($this->price[$price]) && $this->price[$price]) {
                $priceString .= $this->price[$price];
                if ($key + 1 != $totalNumber) {
                    $priceString .= ', ';
                }
            } else {
                $priceString .= $price;
                if ($key + 1 != $totalNumber) {
                    $priceString .= ', ';
                }
            }
        }
        $price = explode(',', $priceString);
        $priceSql = ' op.products_price IN (' . implode(',', $price) . ')';

        //SQL
        if ($price != 'On sale')
            $sql = sprintf("SELECT $groupby, date_purchased, %s total
                            FROM orders o FORCE INDEX (date2status)
                            LEFT JOIN orders_products op
                            ON o.orders_id = op.orders_id
                            LEFT JOIN orders_ext oe
                            ON (o.orders_id = oe.orders_id)
                            WHERE o.orders_status IN (%s)
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND $priceSql
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            GROUP BY %s
                            ORDER BY o.orders_id ASC", "ROUND(SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.products_price', 'tax_rate') . ") / SUM(op.products_quantity), 2)", $_states, $this->tpl->from, $this->tpl->to, $groupby);
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
        //echo $sql;
        $xRows[] = array('AVG', $rows);

        if (!empty($_GET['export'])) {
            $rows = $this->getCsvData($xRows);
            $csvTitles = array('Time', 'AVG');
            $csv = new App_Csv();
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        // chart
        $chart = new App_Chart();

        // colors
        $colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#522a06', '#0bb8ea', '#999900', '#FF0000', '#990088', '#6666aa', '#00EE00');
        foreach ($xRows as $key => $v) {
            $title = $v[0];
            $rows = $v[1];
            $color = $colors[$key];

            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, true, $color);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Total: $#val# (#key#)');
            $line->setTitle($title);
            $line->appendTo($chart);
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function ordersAction()
    {
        $prices = $this->getPriceRange();
        $this->tpl->priceRanges = $prices;
        $this->tpl->breadcrumb->add('Jobs');
        $this->display();
    }

    public function orderspieAction()
    {
        $prices = $this->getPricePieRange();
        $this->tpl->priceRanges = $prices;
        $this->tpl->breadcrumb->add('Jobs');
        $this->display();
    }

    public function orderspieChartAction()
    {

        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();
        if ((isset($_GET['rprice']) && $_GET['rprice'][0] != '6.00') || (isset($_GET['rprice']) && count($_GET['rprice'] > 1))) {
            $prices = &$_GET['rprice'];
        } else {
            $prices = array('0.00-10.00', '10.00-20.00', '20.00-30.00', '30.00-40.00', '40.00-50.00', '50.00');
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        
        foreach ($prices as $price) {
            if (!isset($this->price[$price])) {
                continue;
            }
            $priceSql = ' op.products_price IN (' . $this->price[$price] . ')';

            $sql = sprintf("SELECT %s total
                            FROM orders o FORCE INDEX (date2status)
                            LEFT JOIN orders_products op
                            ON o.orders_id = op.orders_id
                            LEFT JOIN orders_ext oe
                            ON (o.orders_id = oe.orders_id)
                            WHERE o.orders_status IN (%s)
                            AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                            AND $priceSql
                            AND op.bundling_id = 0
                            AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                            ORDER BY o.orders_id ASC", $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.products_price', 'tax_rate') . ")" : "SUM(op.products_quantity)", $_states, $this->tpl->from, $this->tpl->to);
            $$price = $db->getOne($sql, null, PDO::FETCH_NUM);
            //echo $sql."<br>";
            $retval['$' . $price] = $$price;
        }
        // draw graph
        $pie = new pie();
        $pie->set_start_angle(35);
        $tmp = array();
        asort($retval);

        $total = array_sum($retval);
        foreach ($retval as $k => $v) {
            if ($v) {
                $num = round($v, 2);
                $tmp[] = new pie_value($num, $k . ' (' . sprintf('%.2f%%', 100 * $num / $total) . ')');
            }
        }

        $pie->values = $tmp;
        $pie->tip = '#label#<br> #percent#';

        $chart = new open_flash_chart();
        $chart->set_bg_colour('#ffffff');
        $chart->add_element($pie);
        echo $chart->toPrettyString();
    }

    public function ordersChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(date_purchased, 3)';
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM date_purchased)';
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'DATE(date_purchased)';
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);

        // get recent prices
        //$prices = $this->_getRencentPrices();
        if (isset($_GET['rprice'])) {
            $prices = &$_GET['rprice'];
        } else {
            $prices = array('6.00');
        }
        
        // get array
        $xRows = array();
        foreach ($prices as $price) {
            if (isset($this->price[$price]) && $this->price[$price]) {
                $priceSql = ' op.products_price IN (' . $this->price[$price] . ')';
            } else {
                $priceSql = " op.products_price  = '$price' ";
            }
            //SQL
            if ($price != 'On sale')
                $sql = sprintf("SELECT $groupby, date_purchased, %s total
                                FROM orders o FORCE INDEX (date2status)
                                LEFT JOIN orders_products op
                                ON o.orders_id = op.orders_id
                                LEFT JOIN orders_ext oe
                                ON (o.orders_id = oe.orders_id)
                                WHERE o.orders_status IN (%s)
                                AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                                AND $priceSql
                                AND op.bundling_id = 0
                                AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                                GROUP BY %s
                                ORDER BY o.orders_id ASC", $this->tpl->stat == 'value' ? "SUM(" . App_Model_Orders::excludeTax('op.products_quantity * op.products_price', 'tax_rate') . ")" : "SUM(op.products_quantity)", $_states, $this->tpl->from, $this->tpl->to, $groupby);
//			else
//				$sql = sprintf("SELECT $groupby, date_purchased, %s total
//					FROM orders o
//					LEFT JOIN orders_products op
//					ON o.orders_id = op.orders_id
//                    LEFT JOIN orders_ext oe
//                    ON (o.orders_id = oe.orders_id)
//					WHERE o.orders_status IN (%s)
//					AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
//					AND op.products_price not in('6.95', '8.95', '14.95', '19.95', '22.95', '29.95', '32.95', '39.95', '45.95', '49.95')
//                                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
//					GROUP BY %s
//					ORDER BY o.orders_id ASC",
//					$this->tpl->stat == 'value' ? 'SUM(op.products_price)' : 'COUNT(*)',
//					$_states, $this->tpl->from, $this->tpl->to, $groupby);
            //echo $sql.'<br>';
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
            $xRows[] = array($price, $rows);
        }

        // chart
        $chart = new App_Chart();

        if (!empty($_GET['export'])) {
            $rows = $this->getCsvData($xRows);
            $csvTitles = $prices;
            array_unshift($csvTitles, 'Time');
            $csv = new App_Csv();
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }
        // colors
        $colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#522a06', '#0bb8ea', '#999900', '#FF0000', '#990088', '#6666aa', '#00EE00');
        foreach ($xRows as $key => $v) {
            $title = ($v[0] == 'On sale' ? '' : '$') . $v[0];
            $rows = $v[1];
            $color = $colors[$key];

            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, true, $color);
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val# (#key#)' : '#x_label#<br>Total: #val# (#key#)');
            $line->setTitle($title);
            $line->appendTo($chart);
        }
        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function skuandaovAction()
    {
        //$this->tpl->prices = $this->_getRencentPrices();
        $prices = $this->getPrice($this->tpl->from, $this->tpl->to);
        $this->tpl->prices = $prices;
        $this->tpl->breadcrumb->add('Price SKU&AOV');
        $this->display();
    }

    public function skuandaovChartAction()
    {
        /**
         * @var App_Db
         */
        $db = App_Db::getInstance();

        //groupby, $labels
        $graphby = $this->tpl->graphby;
        switch ($graphby) {
            case 'weekly':
                $groupby = 'YEARWEEK(day, 3)';
                $groupby_aov = 'YEARWEEK(date_purchased, 3)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'YEARWEEK(go.date_purchased, 3)';
                }
                $labels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getWeeks($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'monthly':
                $groupby = 'EXTRACT(YEAR_MONTH FROM day)';
                $groupby_aov = 'EXTRACT(YEAR_MONTH FROM date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'EXTRACT(YEAR_MONTH FROM go.date_purchased)';
                }
                $labels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getMonths($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'yearly':
                $groupby = 'EXTRACT(YEAR FROM day)';
                $groupby_aov = 'EXTRACT(YEAR FROM date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'EXTRACT(YEAR FROM go.date_purchased)';
                }
                $labels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to);
                $chartLabels = Jcan_Date::getYears($this->tpl->from, $this->tpl->to, 'Y-m-d');
                break;
            case 'daily':
            default:
                $groupby = 'day';
                $groupby_aov = 'DATE(date_purchased)';
                if (true == self::addGiftVoucher) {
                    $vcgroupby = 'DATE(go.date_purchased)';
                }
                $labels = Jcan_Date::getDates($this->tpl->from, $this->tpl->to);
                $chartLabels = $labels;
                break;
        }

        // prices
        if (isset($_GET['price'])) {
            $prices = &$_GET['price'];
        } else {
            $prices = array('6.95');
        }
        // get array
        $xRows = array();
        foreach ($prices as $price) {
            //SQL
            if ($price != 'On sale')
                $sql = sprintf("SELECT $groupby, day, %s/COUNT(day) total
                                FROM g_products_price_cnt
                                WHERE day >= '%s 00:00:00' AND day <= '%s 23:59:59'
                                AND price = %s
                                GROUP BY $groupby
                                ORDER BY id ASC", $this->tpl->stat == 'value' ? "SUM(cnt) * $price" : "SUM(cnt)", $this->tpl->from, $this->tpl->to, $price, $groupby);
//			else
//				$sql = sprintf("SELECT $groupby, day, %s/COUNT(distinct(day)) total
//					FROM g_products_price_cnt
//					WHERE day >= '%s 00:00:00' AND day <= '%s 23:59:59'
//					AND price not in('6.95', '8.95', '14.95', '19.95', '22.95', '29.95', '32.95', '39.95', '45.95', '49.95')
//					GROUP BY $groupby
//					ORDER BY id ASC",
//					$this->tpl->stat == 'value' ? "SUM(cnt * price)" : "SUM(cnt)", $this->tpl->from, $this->tpl->to, $groupby);
            //echo $sql;
            $rows = $db->getAll($sql, null, PDO::FETCH_NUM);
            $xRows[] = array($price, $rows);
        }
        //-----------AOV-----------
        //status
        $states = & $_GET['states'];
        if (empty($states)) {
            $states = App_Model_Orders::getCommonStatusList();
        }
        $_states = array_map('intval', $states);
        $_states = implode(', ', $_states);
        $statusWhere = "AND o.orders_status IN ({$_states})";

        //SQL
        $sql = sprintf("SELECT $groupby_aov, date_purchased, IF(COUNT(*), SUM(" . App_Model_Orders::excludeTax('value_usd', 'tax_rate') . ") / COUNT(*), 0) total, SUM(value_usd) total2, COUNT(*) cnt
                        FROM orders o FORCE INDEX (date2status)
                        LEFT JOIN orders_total ot
                        ON (o.orders_id = ot.orders_id)
                        LEFT JOIN orders_ext oe
                        ON (o.orders_id = oe.orders_id)
                        WHERE 1 = 1
                        %s
                        AND ot.class = 'total'
                        AND o.date_purchased >= '%s 00:00:00' AND o.date_purchased <= '%s 23:59:59'
                        AND (oe.original_order_id = '' OR oe.original_order_id IS NULL)
                        GROUP BY %s
                        ORDER BY o.orders_id ASC", $statusWhere, $this->tpl->from, $this->tpl->to, $groupby_aov);
        $rows = $db->getAll($sql, null, PDO::FETCH_NUM);

        if (true == self::addGiftVoucher) {
            // add voucher price
            $sqlPurchased = sprintf("
                    SELECT $vcgroupby, go.date_purchased, SUM(go.amount_usd) total
                    FROM customers_gv_orders go
                    LEFT JOIN customers_gv_orders_detail god
                    ON go.gv_orders_id = god.gv_orders_id
                    WHERE god.coupon_code IS NOT NULL
                    AND go.date_purchased >= '%s 00:00:00' AND go.date_purchased <= '%s 23:59:59'
                    GROUP BY $vcgroupby
                    ORDER BY go.gv_orders_id ASC
                    ", $this->tpl->from, $this->tpl->to);
            $vcRows = $db->getAll($sqlPurchased, null, PDO::FETCH_NUM);
            $voucherRows = array();
            foreach ($vcRows as $value) {
                $voucherRows[$value[0]] = $value[2];
            }

            foreach ($rows as $k => $row) {
                if (isset($voucherRows[$row[0]])) {
                    $rows[$k][3] += $voucherRows[$row[0]];
                    $rows[$k][2] = round($rows[$k][3] / $rows[$k][4], 2);
                }
                $rowsAov[$k] = array($row[0], $row[1], $rows[$k][2]);
                $rowsRevenue[$k] = array($row[0], $row[1], sprintf('%01.2f', $rows[$k][3] / 1000));
            }
        } else {
            foreach ($rows as $k => $row) {
                $rowsAov[$k] = array($row[0], $row[1], $row[2]);
                $rowsRevenue[$k] = array($row[0], $row[1], sprintf('%01.2f', $row[3] / 1000));
            }
        }

        if (!empty($_GET['export'])) {
            $rows = $this->getCsvData($xRows);
            foreach ($rowsAov as $aov) {
                if (!isset($row[$aov[0]])) {
                    $rows[$aov[0]]['Time'] = $aov[0];
                }
                $rows[$aov[0]]['AOV'] = number_format($aov[2], 2);
            }

            if ($this->tpl->stat != 'value') {
                foreach ($rowsRevenue as $revenue) {
                    if (!isset($row[$revenue[0]])) {
                        $rows[$revenue[0]]['Time'] = $revenue[0];
                    }
                    $rows[$revenue[0]]['$1K Revenue'] = number_format($revenue[2], 2);
                }
            }

            $csvTitles = $prices;
            array_unshift($csvTitles, 'Time');
            $csvTitles[] = 'AOV';
            $csvTitles[] = '$1K Revenue';

            $csv = new App_Csv();
            $csv->setHeader($csvTitles);
            $csv->setData($rows, $csvTitles);
            $csv->setDataRange($this->tpl->from, $this->tpl->to);
            $csv->output();
            exit;
        }

        // chart
        $chart = new App_Chart();

        // colors
        $colors = array('#0033cc', '#009922', '#ff6600', '#ff00ff', '#00aaaa', '#999900', '#990000', '#6666aa', '#00EE00');
        foreach ($xRows as $key => $v) {
            $title = ($v[0] == 'On sale' ? '' : '$') . $v[0];
            $rows = $v[1];
            $color = $colors[$key];

            $rows = $chart->fixRows($rows, $labels);
            $line = $chart->getShape($this->tpl->chart, true, $color, 2);
            $line->setValues($chart->fetchColumn($rows, 1, 'intval'), $chart->fetchColumn($rows, 0));
            $line->setTip($this->tpl->stat == 'value' ? '#x_label#<br>Total: $#val# (#key#)' : '#x_label#<br>Total: #val# (#key#)');
            $line->setTitle($title);
            $line->appendTo($chart);
        }
        // fix rows AOV
        $rows = $chart->fixRows($rowsAov, $labels);
        $line = $chart->getShape($this->tpl->chart, count($labels), '#999999', 2);
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        $line->setTip('#x_label#<br>Total: $#val#(AOV)');
        $line->setTitle("AOV");
        $line->appendTo($chart);
        if ($this->tpl->stat != 'value') {
            $rows = $chart->fixRows($rowsRevenue, $labels);
            $line = $chart->getShape($this->tpl->chart, count($labels), '#000000', 2);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            $line->setTip('#x_label#<br>Total(k): $#val#($1K Revenue)');
            $line->setTitle("$1K Revenue");
            $line->appendTo($chart);

            foreach ($labels as $a) {
                $linearry[] = array($a, null, 27);
            }
            $rows = $chart->fixRows($linearry, $labels);
            $line = $chart->getShape('line', true, $color = '#00aaaa', 1);
            $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
            //$line->setTitle("line");
            $line->appendTo($chart);
        }
        // fix rows 60line
        foreach ($labels as $a) {
            $linearry[] = array($a, null, 60);
        }
        $rows = $chart->fixRows($linearry, $labels);
        $line = $chart->getShape('line', true, $color = '#ff0000', 1);
        $line->setValues($chart->fetchColumn($rows, 1, '%.2f'), $chart->fetchColumn($rows, 0));
        //$line->setTitle("line");
        $line->appendTo($chart);


        $chart->setLabels($chartLabels)->formatDate($this->tpl->graphby, $this->tpl->from, $this->tpl->to);
        $chart->output();
    }

    public function _getRencentPrices()
    {
        return array('6.95', '8.95', '14.95', '19.95', '22.95', '29.95', '32.95', '39.95', '45.95', '49.95', 'On sale');
        $db = App_Db::getInstance();

        // get recent 7 prices
        $sql = "SELECT price
                FROM g_products_price_cnt
                WHERE day = (
                    SELECT day FROM g_products_price_cnt
                    ORDER BY id DESC LIMIT 1
                )
                ORDER BY cnt DESC LIMIT 7";
        $prices = $db->getAll($sql, PDO::FETCH_COLUMN);
        return $prices;
    }

    protected function getPrice($from, $to)
    {
        $sql = "SELECT price
                FROM g_products_price_cnt
                WHERE day >= '%s' AND  day <= '%s'
                GROUP BY price
                ORDER BY SUM(cnt) DESC
                LIMIT 10";
        $db = App_Db::getInstance();
        $sql = sprintf($sql, $from, $to);
        $prices = $db->getAll($sql, PDO::FETCH_COLUMN);
        sort($prices, SORT_NUMERIC);
        return $prices;
    }

    protected function getPriceRange()
    {
        $priceRange = array('6.00',
            '0.00-10.00',
            '10.00-20.00',
            '20.00-30.00',
            '30.00-40.00',
            '40.00-50.00',
            '50.00');
        return $priceRange;
    }

    protected function getPricePieRange()
    {
        $pricePieRange = array('0.00-10.00',
            '10.00-20.00',
            '20.00-30.00',
            '30.00-40.00',
            '40.00-50.00',
            '50.00');
        return $pricePieRange;
    }

    /**
     * prepare data for exporting csv file
     *
     * @param array $datas
     * @return array
     */
    private function getCsvData($datas)
    {
        $result = array();
        foreach ($datas as $data) {
            $title = $data[0];
            foreach ($data[1] as $v) {
                if (!isset($result[$v[0]])) {
                    $result[$v[0]]['Time'] = $v[0];
                }
                $result[$v[0]][$title] = number_format($v[2], 2);
            }
        }

        return $result;
    }

}
