<?php

class App_Db extends Jcan_Db
{
        static private $_instance;

        /**
         * @param String $scheme
         */
        public function __construct()
        {
                parent::__construct(DB_DSN, DB_USERNAME, DB_PASSWORD, DB_CHARSET, array(PDO::ATTR_PERSISTENT => DB_PCONNECT));
                # $this->query("SET time_zone = '+00:00'");
        }

        /**
         * @return object DB resource
         */
        public static function getInstance($force = false)
        {
        	if ($force) {
        		self::$_instance = null;
        		self::$_instance = new self();
        	} else {
	                if (self::$_instance instanceof self === false) {
	                        self::$_instance = new self();
	                }
        	}
                return self::$_instance;
        }
}