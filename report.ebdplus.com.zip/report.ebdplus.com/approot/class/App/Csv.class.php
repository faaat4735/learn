<?php

class App_Csv
{
	protected $_separator = ',';
	protected $_eol = "\n";
	protected $_header;
	protected $_data = array();
	protected $_encoding = 'gbk';
    protected $_extra = '';

    public function setHeader($header)
	{
		$this->_header = $header;
	}

    /**
     * Set Extra Info Of CSV
     * @param array $extra
     */
    public function setExtra($extra)
	{
		$this->_extra = $extra;
	}

	public function setData($data, $fields = null)
	{
		if (!is_null($fields)) {
            if (is_array($data)) {
                $data = $this->arrayToObject($data);
            }
			$_data = array();
			foreach ($data as $row) {
				$o = new stdClass();
				foreach ($fields as $_field) {
					$o->$_field =& $row->$_field;
				}
				$_data[] = $o;
			}
			$this->_data = $_data;
		} else {
			$this->_data = $data;
		}
	}

	public function toString()
	{
		if ($this->_header) {
			array_unshift($this->_data, $this->_header);
		}
        if ($this->_extra) {
			array_unshift($this->_data, $this->_extra);
		}

		$retval = array();
		foreach ($this->_data as $row) {
			$retval[] = $this->_format($row);
		}
		return implode($this->_eol, $retval);
	}

	public function output($filename = null)
	{
		if (!$filename) {
			$filename = date('Y.m.d-Hi') . '.csv';
		}
		header("Content-Type: text/csv");
		header("Content-Disposition: filename=" . $filename);
		$content = $this->toString();
		echo mb_convert_encoding($content, 'gbk', 'utf-8');
	}

	protected function _format($arr)
	{
		$arr = (array)$arr;
		array_walk($arr, create_function('&$v', '$v = str_replace("\"", "\"\"", $v);'));
		return '"' . implode('"' . $this->_separator . '"', $arr) . '"';
	}

    public function arrayToObject($array)
    {
        if (is_array($array)) {
            return (object) array_map(array(__CLASS__, __FUNCTION__), $array);
        } else {
            return $array;
        }
    }

    /**
     * prepare data for exporting csv file from bar/ char
     *
     * @param array $datas
     * @param int $timeIndex
     * @param int $valueIndex
     * @return array
     */
    public function prepareCsvData ($datas, $timeIndex = 0, $valueIndex = 2) {
        $result = array();
        $sortResult = array();
        foreach ($datas as $title => $data) {
            foreach ($data as $v) {
                if (!isset( $result[$v[$timeIndex]])){
                    $result[$v[$timeIndex]]['Time'] = $v[$timeIndex];
                }
                $result[$v[$timeIndex]][$title] = number_format($v[$valueIndex], 2);
            }
        }

        //sort by time asc
        $times = array_keys($result);
        asort($times);
        foreach ($times as $t) {
            $sortResult[$t] = $result[$t];
        }
        return $sortResult;
    }

    /**
     * prepare data for exporting csv file from Pie
     *
     * @param array $rows
     * @return array
     */
    public function prepareCsvPieData($rows) {
        $datas = array();
        $total = (int) array_sum($rows);;
        foreach ($rows as $k => $v) {
            $datas[] = array($k, $v, ($total ? number_format($v*100/$total, 2) : 0) . '%');
        }
        return $datas;
    }

    /**
     * Set Date Range For CSV
     * @param string $from
     * @param string $to
     */
    public function setDataRange($from, $to) {
        $dateRange = 'Date Range: ' . $from . ' To ' . $to;
        $this->setExtra(array($dateRange));
    }
}