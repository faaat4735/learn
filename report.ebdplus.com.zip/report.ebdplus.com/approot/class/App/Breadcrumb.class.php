<?php

class App_Breadcrumb
{
	public $label;
	public $separator = ' ';
	public $crumbs = array();

	public function add($name, $link = null)
	{
		$this->crumbs[] = array($name, $link);
	}

	public function __toString()
	{
		$str = '';

		if ($this->label) {
			$str .= "<label>{$this->label}</label> ";
		}

		$arr = array();
		foreach ($this->crumbs as $crumb) {
			$arr[] = ($crumb[1] ? "<a href=\"{$crumb[1]}\">" : '') . $crumb[0] . ($crumb[1] ? '</a>' : '');
		}
		$str .= implode($this->separator, $arr);

		$str = '<span>' . $str . '</span>';
		return $str;
	}
}