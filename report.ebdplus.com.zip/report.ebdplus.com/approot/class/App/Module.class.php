<?php

class App_Module extends Jcan_Module
{
	public $title = 'EBD reports';

	public function __construct($tpl)
	{
		parent::__construct($tpl);

		$breadcrumb = new App_Breadcrumb();
		$breadcrumb->label = 'Current Location:';
		$breadcrumb->separator = ' - ';
		$breadcrumb->add('Admin Home', ROOT_URL);
		$this->tpl->assign_by_ref('breadcrumb', $breadcrumb);

		if (($this->tpl->module != 'Index' || $this->tpl->action != 'login') && $this->tpl->action != 'syncOrderComplete') {
			$this->checkLogin();
		}
	}

	public function display($file = null, $cache_id = null, $compile_id = null)
	{
		if (empty($file)) {
			$file = 'wrapper.tpl';
		}
		$this->tpl->display($file);
	}

	public function checkLogin()
	{
		if (empty($_SESSION['member_id'])) {
			Jcan_Http::redirect(ROOT_URL . 'login/');
		}else{
                    $sql = "SELECT * FROM t_member
                            WHERE member_id = ?";
                    $member = App_Db::getInstance()->getRow($sql, \PDO::FETCH_ASSOC, $_SESSION['member_id']);
                }
                
        // check report_login permission
        $sql = "SELECT COUNT(*) FROM t_member
                WHERE member_id = ? AND FIND_IN_SET('report_login', member_perms)";
        $has = App_Db::getInstance()->getOne($sql, $_SESSION['member_id']);
        if (!$has) {
            Jcan_Http::headerStatus(403);
            exit;
        }
        
        $sql = "SELECT COUNT(*)
                    FROM t_member_password_log 
                    WHERE member_id = ?";
        $count = App_Db::getInstance()->getOne($sql, $_SESSION['member_id']);
        if (!$count) {
            Jcan_Http::redirect('/easy/account/change-password?redirect=' . $_SERVER['REQUEST_URI']);
        }
        if(empty($_SESSION['FA_Login']) && empty($_COOKIE['FA_REM']) && $member['2fa_status'] == 1) Jcan_Http::redirect('/easy/account/google-check?redirect=' . $_SERVER['REQUEST_URI']);
	}
}